package dymsg

import (
	"bytes"
	"encoding/json"
)

// schemaFile mirrors the top-level JSON configuration layout.
type schemaFile struct {
	Types []typeDef `json:"types"`
}

// typeDef mirrors a top-level type entry in the JSON configuration.
type typeDef struct {
	TypeID uint16     `json:"typeId"`
	Fields []fieldDef `json:"fields"`
}

// fieldDef mirrors a field entry in the JSON configuration.
type fieldDef struct {
	Name     string     `json:"name"`
	Num      int        `json:"num"`
	Type     string     `json:"type"`
	Repeated bool       `json:"repeated"`
	Schema   *schemaDef `json:"schema"`
}

// schemaDef mirrors an inline nested message definition.
type schemaDef struct {
	Fields []fieldDef `json:"fields"`
}

// ParseSchema parses a JSON configuration file describing one or more top-level
// message types.  The returned schemas must be registered (via Register)
// before they can be instantiated with New.
func ParseSchema(data []byte) ([]MessageSchema, error) {
	trimmed := bytes.TrimSpace(data)
	if len(trimmed) == 0 {
		return nil, ErrMalformedData
	}
	if trimmed[0] != '{' {
		return nil, ErrMalformedData
	}
	var file schemaFile
	if err := json.Unmarshal(trimmed, &file); err != nil {
		return nil, ErrMalformedData
	}
	if file.Types == nil {
		return []MessageSchema{}, nil
	}
	seen := make(map[uint16]bool, len(file.Types))
	out := make([]MessageSchema, 0, len(file.Types))
	for _, t := range file.Types {
		if t.TypeID == 0 {
			return nil, ErrMalformedData
		}
		if seen[t.TypeID] {
			return nil, ErrMalformedData
		}
		seen[t.TypeID] = true
		s, err := buildMessageSchema(t.TypeID, t.Fields)
		if err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, nil
}

// buildMessageSchema recursively builds a MessageSchema from field definitions.
func buildMessageSchema(typeID uint16, fields []fieldDef) (MessageSchema, error) {
	s := MessageSchema{
		TypeID: typeID,
		Fields: make([]FieldSchema, 0, len(fields)),
		byName: make(map[string]int, len(fields)),
		byNum:  make(map[int]int, len(fields)),
	}
	for i, fd := range fields {
		if !nameValidForField(fd.Name) {
			return MessageSchema{}, ErrMalformedData
		}
		if _, dup := s.byName[fd.Name]; dup {
			return MessageSchema{}, ErrMalformedData
		}
		if fd.Num < 1 || fd.Num > 65535 {
			return MessageSchema{}, ErrMalformedData
		}
		if _, dup := s.byNum[fd.Num]; dup {
			return MessageSchema{}, ErrMalformedData
		}
		ft := FieldType(fd.Type)
		if !validFieldType(ft) {
			return MessageSchema{}, ErrMalformedData
		}
		if ft == FieldMessage {
			if fd.Schema == nil {
				return MessageSchema{}, ErrMalformedData
			}
			nested, err := buildMessageSchema(0, fd.Schema.Fields)
			if err != nil {
				return MessageSchema{}, err
			}
			s.Fields = append(s.Fields, FieldSchema{
				Name:     fd.Name,
				Num:      fd.Num,
				Type:     ft,
				Repeated: fd.Repeated,
				Schema:   nested,
			})
		} else {
			if fd.Schema != nil {
				return MessageSchema{}, ErrMalformedData
			}
			s.Fields = append(s.Fields, FieldSchema{
				Name:     fd.Name,
				Num:      fd.Num,
				Type:     ft,
				Repeated: fd.Repeated,
			})
		}
		s.byName[fd.Name] = i
		s.byNum[fd.Num] = i
	}
	return s, nil
}
