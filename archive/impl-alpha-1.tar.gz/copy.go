package dymsg

import "reflect"

// deepCopyValue returns a deep copy of a stored field value.  Scalars are
// immutable and returned as-is; slices and messages are copied.
func deepCopyValue(val any) any {
	switch v := val.(type) {
	case *Message:
		if v == nil {
			return nil
		}
		return v.deepCopy()
	case []byte:
		b := make([]byte, len(v))
		copy(b, v)
		return b
	case [][]byte:
		out := make([][]byte, len(v))
		for i, b := range v {
			if b != nil {
				nb := make([]byte, len(b))
				copy(nb, b)
				out[i] = nb
			}
		}
		return out
	case []*Message:
		out := make([]*Message, len(v))
		for i, m := range v {
			if m != nil {
				out[i] = m.deepCopy()
			}
		}
		return out
	default:
		rv := reflect.ValueOf(val)
		if rv.Kind() == reflect.Slice {
			out := reflect.MakeSlice(rv.Type(), rv.Len(), rv.Len())
			reflect.Copy(out, rv)
			return out.Interface()
		}
		return val
	}
}

// deepCopy returns a deep copy of the message: the schema pointer is shared
// (schemas are immutable), while all field values are copied.
func (m *Message) deepCopy() *Message {
	if m == nil {
		return nil
	}
	nm := &Message{
		schema: m.schema,
		fields: make(map[string]any, len(m.fields)),
	}
	for k, v := range m.fields {
		nm.fields[k] = deepCopyValue(v)
	}
	return nm
}
