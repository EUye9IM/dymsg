package dymsg

import (
	"strconv"
	"strings"
)

// pathSeg is a single parsed path segment: an optional field name followed by
// an optional repeated index.
type pathSeg struct {
	name     string
	index    int
	hasIndex bool
}

// parsePath parses a field path expression into segments.  An empty path
// returns no segments (referring to the message itself).
//
// Grammar: segments are separated by '.'.  A segment is "name" or "name[n]"
// where n is a non-negative decimal integer.  Invalid syntax returns the
// appropriate sentinel error.
func parsePath(path string) ([]pathSeg, error) {
	if path == "" {
		return nil, nil
	}
	parts := strings.Split(path, ".")
	segs := make([]pathSeg, 0, len(parts))
	for _, part := range parts {
		if part == "" {
			return nil, ErrFieldNotFound
		}
		seg, err := parseSegment(part)
		if err != nil {
			return nil, err
		}
		segs = append(segs, seg)
	}
	return segs, nil
}

// parseSegment parses a single path segment.
func parseSegment(part string) (pathSeg, error) {
	idx := strings.IndexByte(part, '[')
	if idx < 0 {
		return pathSeg{name: part}, nil
	}
	name := part[:idx]
	if name == "" {
		return pathSeg{}, ErrFieldNotFound
	}
	rest := part[idx+1:]
	if rest == "" {
		return pathSeg{}, ErrFieldNotFound
	}
	// Negative index.
	if rest[0] == '-' {
		return pathSeg{}, ErrIndexOutOfRange
	}
	closeIdx := strings.IndexByte(rest, ']')
	if closeIdx < 0 {
		// "tags[0" style: no closing bracket.
		return pathSeg{}, ErrFieldNotFound
	}
	if closeIdx != len(rest)-1 {
		// "tags[0]x" or "tags[0][1]" style: trailing content after ']'.
		return pathSeg{}, ErrFieldNotFound
	}
	digits := rest[:closeIdx]
	if digits == "" {
		// "tags[]" style.
		return pathSeg{}, ErrIndexOutOfRange
	}
	// Must be a non-negative decimal integer with no sign characters.
	for i := 0; i < len(digits); i++ {
		if digits[i] < '0' || digits[i] > '9' {
			return pathSeg{}, ErrIndexOutOfRange
		}
	}
	u, err := strconv.ParseUint(digits, 10, 31)
	if err != nil {
		return pathSeg{}, ErrIndexOutOfRange
	}
	return pathSeg{name: name, index: int(u), hasIndex: true}, nil
}
