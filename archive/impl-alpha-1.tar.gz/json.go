package dymsg

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"math"
	"reflect"
	"strconv"
)

// EncodeJSON encodes the message as a JSON object.  Unset fields are omitted;
// set fields (including zero values) are output in schema declaration order.
func (m *Message) EncodeJSON() ([]byte, error) {
	var buf bytes.Buffer
	if err := m.writeJSONObject(&buf); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func (m *Message) writeJSONObject(buf *bytes.Buffer) error {
	buf.WriteByte('{')
	first := true
	for i := range m.schema.Fields {
		fs := &m.schema.Fields[i]
		val, ok := m.fields[fs.Name]
		if !ok {
			continue
		}
		if fs.Type == FieldMessage && !fs.Repeated && val == nil {
			continue
		}
		if !first {
			buf.WriteByte(',')
		}
		first = false
		key, _ := json.Marshal(fs.Name)
		buf.Write(key)
		buf.WriteByte(':')
		if err := writeJSONValue(buf, fs, val); err != nil {
			return err
		}
	}
	buf.WriteByte('}')
	return nil
}

func writeJSONValue(buf *bytes.Buffer, fs *FieldSchema, val any) error {
	if fs.Repeated {
		rv := reflect.ValueOf(val)
		buf.WriteByte('[')
		n := rv.Len()
		for i := 0; i < n; i++ {
			if i > 0 {
				buf.WriteByte(',')
			}
			ev := rv.Index(i).Interface()
			if fs.Type == FieldMessage {
				msg, _ := ev.(*Message)
				if msg == nil {
					buf.WriteString("null")
					continue
				}
				if err := msg.writeJSONObject(buf); err != nil {
					return err
				}
			} else {
				if err := writeJSONScalar(buf, fs.Type, ev); err != nil {
					return err
				}
			}
		}
		buf.WriteByte(']')
		return nil
	}
	if fs.Type == FieldMessage {
		msg, _ := val.(*Message)
		if msg == nil {
			buf.WriteString("null")
			return nil
		}
		return msg.writeJSONObject(buf)
	}
	return writeJSONScalar(buf, fs.Type, val)
}

func writeJSONScalar(buf *bytes.Buffer, t FieldType, val any) error {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64:
		switch v := val.(type) {
		case int32:
			buf.WriteString(strconv.FormatInt(int64(v), 10))
		case int64:
			buf.WriteString(strconv.FormatInt(v, 10))
		case uint32:
			buf.WriteString(strconv.FormatUint(uint64(v), 10))
		case uint64:
			buf.WriteString(strconv.FormatUint(v, 10))
		default:
			return ErrMalformedData
		}
	case FieldFloat:
		f, ok := val.(float32)
		if !ok {
			return ErrMalformedData
		}
		if math.IsNaN(float64(f)) || math.IsInf(float64(f), 0) {
			return ErrMalformedData
		}
		buf.WriteString(strconv.FormatFloat(float64(f), 'g', -1, 32))
	case FieldDouble:
		f, ok := val.(float64)
		if !ok {
			return ErrMalformedData
		}
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return ErrMalformedData
		}
		buf.WriteString(strconv.FormatFloat(f, 'g', -1, 64))
	case FieldBool:
		b, ok := val.(bool)
		if !ok {
			return ErrMalformedData
		}
		if b {
			buf.WriteString("true")
		} else {
			buf.WriteString("false")
		}
	case FieldString:
		s, ok := val.(string)
		if !ok {
			return ErrMalformedData
		}
		eb, _ := json.Marshal(s)
		buf.Write(eb)
	case FieldBytes:
		b, ok := val.([]byte)
		if !ok {
			return ErrMalformedData
		}
		eb, _ := json.Marshal(base64.StdEncoding.EncodeToString(b))
		buf.Write(eb)
	default:
		return ErrMalformedData
	}
	return nil
}

// DecodeJSON decodes a JSON object into the message, replacing all existing
// field values.  Unknown JSON keys are ignored.
func (m *Message) DecodeJSON(data []byte) error {
	trimmed := bytes.TrimSpace(data)
	if len(trimmed) == 0 {
		return ErrTruncated
	}
	if string(trimmed) == "null" {
		// Top-level null clears the whole message.
		m.fields = make(map[string]any)
		return nil
	}
	var raw map[string]json.RawMessage
	if err := json.Unmarshal(trimmed, &raw); err != nil {
		return ErrMalformedData
	}
	m.fields = make(map[string]any)
	for key, rawVal := range raw {
		idx, ok := m.schema.byName[key]
		if !ok {
			continue
		}
		fs := &m.schema.Fields[idx]
		val, err := decodeJSONField(fs, rawVal)
		if err != nil {
			return err
		}
		if val == nil {
			delete(m.fields, fs.Name)
		} else {
			m.fields[fs.Name] = val
		}
	}
	return nil
}

func decodeJSONField(fs *FieldSchema, raw json.RawMessage) (any, error) {
	trimmed := bytes.TrimSpace(raw)
	if len(trimmed) == 0 {
		return nil, ErrMalformedData
	}
	if trimmed[0] == 'n' {
		// A field-level null clears the field (unset), for any type.
		return nil, nil
	}
	if fs.Repeated {
		if trimmed[0] != '[' {
			return nil, ErrMalformedData
		}
		return decodeJSONArray(fs, trimmed)
	}
	if trimmed[0] == '[' {
		return nil, ErrMalformedData
	}
	if fs.Type == FieldMessage {
		if trimmed[0] != '{' {
			return nil, ErrMalformedData
		}
		msg := &Message{schema: &fs.Schema, fields: make(map[string]any)}
		if err := msg.decodeJSONObject(trimmed); err != nil {
			return nil, err
		}
		return msg, nil
	}
	return decodeJSONScalar(fs.Type, trimmed)
}

func (m *Message) decodeJSONObject(raw json.RawMessage) error {
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		return ErrMalformedData
	}
	m.fields = make(map[string]any)
	for key, rawVal := range obj {
		idx, ok := m.schema.byName[key]
		if !ok {
			continue
		}
		fs := &m.schema.Fields[idx]
		val, err := decodeJSONField(fs, rawVal)
		if err != nil {
			return err
		}
		if val == nil {
			delete(m.fields, fs.Name)
		} else {
			m.fields[fs.Name] = val
		}
	}
	return nil
}

func decodeJSONArray(fs *FieldSchema, raw json.RawMessage) (any, error) {
	var items []json.RawMessage
	if err := json.Unmarshal(raw, &items); err != nil {
		return nil, ErrMalformedData
	}
	switch fs.Type {
	case FieldMessage:
		out := []*Message{}
		for _, item := range items {
			item = bytes.TrimSpace(item)
			if len(item) > 0 && item[0] == 'n' {
				out = append(out, nil)
				continue
			}
			msg := &Message{schema: &fs.Schema, fields: make(map[string]any)}
			if err := msg.decodeJSONObject(item); err != nil {
				return nil, err
			}
			out = append(out, msg)
		}
		return out, nil
	case FieldBytes:
		out := [][]byte{}
		for _, item := range items {
			item = bytes.TrimSpace(item)
			if len(item) > 0 && item[0] == 'n' {
				return nil, ErrMalformedData
			}
			v, err := decodeJSONScalar(FieldBytes, item)
			if err != nil {
				return nil, err
			}
			out = append(out, v.([]byte))
		}
		return out, nil
	default:
		out := reflect.MakeSlice(reflect.SliceOf(targetGoType(fs.Type)), 0, 0)
		for _, item := range items {
			item = bytes.TrimSpace(item)
			if len(item) > 0 && item[0] == 'n' {
				return nil, ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, item)
			if err != nil {
				return nil, err
			}
			out = reflect.Append(out, reflect.ValueOf(v))
		}
		return out.Interface(), nil
	}
}

func decodeJSONScalar(t FieldType, raw json.RawMessage) (any, error) {
	trimmed := bytes.TrimSpace(raw)
	if len(trimmed) == 0 {
		return nil, ErrMalformedData
	}
	first := trimmed[0]
	switch t {
	case FieldString:
		if first != '"' {
			return nil, ErrMalformedData
		}
		var s string
		if err := json.Unmarshal(trimmed, &s); err != nil {
			return nil, ErrMalformedData
		}
		return s, nil
	case FieldBytes:
		if first != '"' {
			return nil, ErrMalformedData
		}
		var s string
		if err := json.Unmarshal(trimmed, &s); err != nil {
			return nil, ErrMalformedData
		}
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldBool:
		if first != 't' && first != 'f' {
			return nil, ErrMalformedData
		}
		var b bool
		if err := json.Unmarshal(trimmed, &b); err != nil {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat, FieldDouble:
		if first != '-' && (first < '0' || first > '9') {
			return nil, ErrMalformedData
		}
		dec := json.NewDecoder(bytes.NewReader(trimmed))
		dec.UseNumber()
		var num json.Number
		if err := dec.Decode(&num); err != nil {
			return nil, ErrMalformedData
		}
		return convertFromNumber(t, num)
	default:
		return nil, ErrMalformedData
	}
}

func convertFromNumber(t FieldType, num json.Number) (any, error) {
	s := num.String()
	switch t {
	case FieldInt32:
		n, err := strconv.ParseInt(s, 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return int32(n), nil
	case FieldInt64:
		n, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldUint32:
		n, err := strconv.ParseUint(s, 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return uint32(n), nil
	case FieldUint64:
		n, err := strconv.ParseUint(s, 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldFloat:
		f, err := strconv.ParseFloat(s, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return float32(f), nil
	case FieldDouble:
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return f, nil
	}
	return nil, ErrMalformedData
}
