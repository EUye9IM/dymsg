package dymsg

import (
	"math"
	"reflect"
	"strconv"
)

// convertScalar converts a value to the target scalar field type using the
// lenient conversion rules of the spec (section 7).
func convertScalar(target FieldType, value any) (any, error) {
	if value == nil {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)
	switch target {
	case FieldInt32:
		return toInt32(rv)
	case FieldInt64:
		return toInt64(rv)
	case FieldUint32:
		return toUint32(rv)
	case FieldUint64:
		return toUint64(rv)
	case FieldFloat:
		return toFloat32(rv)
	case FieldDouble:
		return toFloat64(rv)
	case FieldBool:
		return toBool(rv)
	case FieldString:
		return toString(rv)
	case FieldBytes:
		return toBytes(rv)
	default:
		return nil, ErrTypeMismatch
	}
}

func kindInt(k reflect.Kind) bool {
	switch k {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return true
	}
	return false
}

func kindUint(k reflect.Kind) bool {
	switch k {
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return true
	}
	return false
}

func kindFloat(k reflect.Kind) bool {
	switch k {
	case reflect.Float32, reflect.Float64:
		return true
	}
	return false
}

func toInt32(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		n := rv.Int()
		if n < math.MinInt32 || n > math.MaxInt32 {
			return nil, ErrTypeMismatch
		}
		return int32(n), nil
	case kindUint(k):
		n := rv.Uint()
		if n > math.MaxInt32 {
			return nil, ErrTypeMismatch
		}
		return int32(n), nil
	case kindFloat(k):
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		if f >= 0 {
			if f >= float64(math.MaxInt32)+1 {
				return nil, ErrTypeMismatch
			}
		} else {
			if f <= float64(math.MinInt32)-1 {
				return nil, ErrTypeMismatch
			}
		}
		return int32(f), nil
	case k == reflect.String:
		n, err := strconv.ParseInt(rv.String(), 10, 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return int32(n), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toInt64(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		return rv.Int(), nil
	case kindUint(k):
		n := rv.Uint()
		if n > math.MaxInt64 {
			return nil, ErrTypeMismatch
		}
		return int64(n), nil
	case kindFloat(k):
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		if f >= 0 {
			if f >= 9223372036854775808.0 { // 2^63
				return nil, ErrTypeMismatch
			}
		} else {
			if f <= -9223372036854775809.0 { // -2^63 - 1
				return nil, ErrTypeMismatch
			}
		}
		return int64(f), nil
	case k == reflect.String:
		n, err := strconv.ParseInt(rv.String(), 10, 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return n, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toUint32(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		n := rv.Int()
		if n < 0 || n > math.MaxUint32 {
			return nil, ErrTypeMismatch
		}
		return uint32(n), nil
	case kindUint(k):
		n := rv.Uint()
		if n > math.MaxUint32 {
			return nil, ErrTypeMismatch
		}
		return uint32(n), nil
	case kindFloat(k):
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		if f < 0 || f >= float64(math.MaxUint32)+1 {
			return nil, ErrTypeMismatch
		}
		return uint32(f), nil
	case k == reflect.String:
		n, err := strconv.ParseUint(rv.String(), 10, 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return uint32(n), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toUint64(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		n := rv.Int()
		if n < 0 {
			return nil, ErrTypeMismatch
		}
		return uint64(n), nil
	case kindUint(k):
		return rv.Uint(), nil
	case kindFloat(k):
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		if f < 0 || f >= 18446744073709551616.0 { // 2^64
			return nil, ErrTypeMismatch
		}
		return uint64(f), nil
	case k == reflect.String:
		n, err := strconv.ParseUint(rv.String(), 10, 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return n, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toFloat32(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		return float32(rv.Int()), nil
	case kindUint(k):
		return float32(rv.Uint()), nil
	case kindFloat(k):
		f := rv.Float()
		f32 := float32(f)
		if math.IsInf(float64(f32), 0) && !math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		return f32, nil
	case k == reflect.String:
		f, err := strconv.ParseFloat(rv.String(), 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return float32(f), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toFloat64(rv reflect.Value) (any, error) {
	switch k := rv.Kind(); {
	case kindInt(k):
		return float64(rv.Int()), nil
	case kindUint(k):
		return float64(rv.Uint()), nil
	case kindFloat(k):
		return rv.Float(), nil
	case k == reflect.String:
		f, err := strconv.ParseFloat(rv.String(), 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return f, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toBool(rv reflect.Value) (any, error) {
	if rv.Kind() == reflect.Bool {
		return rv.Bool(), nil
	}
	return nil, ErrTypeMismatch
}

func toString(rv reflect.Value) (any, error) {
	switch rv.Kind() {
	case reflect.String:
		return rv.String(), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return string(rv.Bytes()), nil
		}
		return nil, ErrTypeMismatch
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(rv.Int(), 10), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return strconv.FormatUint(rv.Uint(), 10), nil
	case reflect.Float32, reflect.Float64:
		return strconv.FormatFloat(rv.Float(), 'g', -1, rv.Type().Bits()), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toBytes(rv reflect.Value) (any, error) {
	switch rv.Kind() {
	case reflect.Slice:
		if rv.Type().Elem().Kind() != reflect.Uint8 {
			return nil, ErrTypeMismatch
		}
		b := make([]byte, rv.Len())
		copy(b, rv.Bytes())
		return b, nil
	case reflect.String:
		return []byte(rv.String()), nil
	default:
		return nil, ErrTypeMismatch
	}
}

// convertFieldValue converts a value for an entire field (either a scalar or a
// repeated slice), deep-copying message values.
func convertFieldValue(fs *FieldSchema, value any) (any, error) {
	if value == nil {
		return nil, nil
	}
	if fs.Repeated {
		return convertRepeated(fs, value)
	}
	if fs.Type == FieldMessage {
		msg, ok := value.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if msg == nil {
			return nil, nil
		}
		if !schemaEqual(&fs.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		return msg.deepCopy(), nil
	}
	return convertScalar(fs.Type, value)
}

// convertRepeated converts a slice value for a repeated field.
func convertRepeated(fs *FieldSchema, value any) (any, error) {
	rv := reflect.ValueOf(value)
	if rv.Kind() != reflect.Slice {
		return nil, ErrTypeMismatch
	}
	n := rv.Len()
	switch fs.Type {
	case FieldMessage:
		out := make([]*Message, n)
		for i := 0; i < n; i++ {
			ev := rv.Index(i)
			if ev.Kind() == reflect.Ptr && ev.IsNil() {
				out[i] = nil
				continue
			}
			msg, ok := ev.Interface().(*Message)
			if !ok {
				return nil, ErrTypeMismatch
			}
			if !schemaEqual(&fs.Schema, msg.schema) {
				return nil, ErrTypeMismatch
			}
			out[i] = msg.deepCopy()
		}
		return out, nil
	case FieldBytes:
		out := make([][]byte, n)
		for i := 0; i < n; i++ {
			ev := rv.Index(i)
			switch ev.Kind() {
			case reflect.Slice:
				if ev.Type().Elem().Kind() != reflect.Uint8 {
					return nil, ErrTypeMismatch
				}
				b := make([]byte, ev.Len())
				copy(b, ev.Bytes())
				out[i] = b
			case reflect.String:
				out[i] = []byte(ev.String())
			default:
				return nil, ErrTypeMismatch
			}
		}
		return out, nil
	default:
		out := reflect.MakeSlice(reflect.SliceOf(targetGoType(fs.Type)), n, n)
		for i := 0; i < n; i++ {
			conv, err := convertScalar(fs.Type, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out.Index(i).Set(reflect.ValueOf(conv))
		}
		return out.Interface(), nil
	}
}

// convertElement converts a single element for a repeated field.
func convertElement(fs *FieldSchema, value any) (any, error) {
	switch fs.Type {
	case FieldMessage:
		if value == nil {
			return (*Message)(nil), nil
		}
		msg, ok := value.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if msg == nil {
			return (*Message)(nil), nil
		}
		if !schemaEqual(&fs.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		return msg.deepCopy(), nil
	default:
		if value == nil {
			return nil, ErrTypeMismatch
		}
		return convertScalar(fs.Type, value)
	}
}

// targetGoType returns the native Go slice element type for a field type.
func targetGoType(t FieldType) reflect.Type {
	switch t {
	case FieldInt32:
		return reflect.TypeOf(int32(0))
	case FieldInt64:
		return reflect.TypeOf(int64(0))
	case FieldUint32:
		return reflect.TypeOf(uint32(0))
	case FieldUint64:
		return reflect.TypeOf(uint64(0))
	case FieldFloat:
		return reflect.TypeOf(float32(0))
	case FieldDouble:
		return reflect.TypeOf(float64(0))
	case FieldBool:
		return reflect.TypeOf(false)
	case FieldString:
		return reflect.TypeOf("")
	}
	return nil
}

// zeroValueForType returns the zero value for a field type.
func zeroValueForType(t FieldType) any {
	switch t {
	case FieldInt32:
		return int32(0)
	case FieldInt64:
		return int64(0)
	case FieldUint32:
		return uint32(0)
	case FieldUint64:
		return uint64(0)
	case FieldFloat:
		return float32(0)
	case FieldDouble:
		return float64(0)
	case FieldBool:
		return false
	case FieldString:
		return ""
	case FieldBytes:
		return []byte(nil)
	case FieldMessage:
		return (*Message)(nil)
	}
	return nil
}

// makeEmptySlice creates an empty slice for a repeated field.
func makeEmptySlice(fs *FieldSchema) any {
	switch fs.Type {
	case FieldInt32:
		return []int32{}
	case FieldInt64:
		return []int64{}
	case FieldUint32:
		return []uint32{}
	case FieldUint64:
		return []uint64{}
	case FieldFloat:
		return []float32{}
	case FieldDouble:
		return []float64{}
	case FieldBool:
		return []bool{}
	case FieldString:
		return []string{}
	case FieldBytes:
		return [][]byte{}
	case FieldMessage:
		return []*Message{}
	}
	return nil
}

// appendToSlice appends elem to a slice and returns the new slice.
func appendToSlice(arr any, elem any) any {
	rv := reflect.ValueOf(arr)
	ev := reflect.ValueOf(elem)
	return reflect.Append(rv, ev).Interface()
}

// setSliceIndex sets the i-th element of a slice.
func setSliceIndex(arr any, i int, v any) {
	reflect.ValueOf(arr).Index(i).Set(reflect.ValueOf(v))
}
