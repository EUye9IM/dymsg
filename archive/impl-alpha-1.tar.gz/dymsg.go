// Package dymsg implements a dynamic message encoding/decoding library.
//
// Message structures are defined at runtime from JSON configuration files
// rather than being hard-coded Go structs.  The library supports field-level
// get/set operations, deep copying, and dual JSON / Protobuf wire-format
// encoding and decoding.
package dymsg

import (
	"errors"
	"reflect"
	"strings"
	"sync"
)

// FieldType is the type of a message field.
type FieldType string

// Supported field types.  The string values match the JSON configuration
// "type" attribute.
const (
	FieldInt32   FieldType = "int32"
	FieldInt64   FieldType = "int64"
	FieldUint32  FieldType = "uint32"
	FieldUint64  FieldType = "uint64"
	FieldFloat   FieldType = "float"
	FieldDouble  FieldType = "double"
	FieldBool    FieldType = "bool"
	FieldString  FieldType = "string"
	FieldBytes   FieldType = "bytes"
	FieldMessage FieldType = "message"
)

// Sentinel errors returned by the package.
var (
	// ErrDuplicateID is returned when registering a different schema under an
	// already-registered type ID.
	ErrDuplicateID = errors.New("dymsg: duplicate type id")
	// ErrUnknownTypeID is returned by New when the type ID is not registered.
	ErrUnknownTypeID = errors.New("dymsg: unknown type id")
	// ErrFieldNotFound is returned when a path references an unknown field or
	// uses an index on a non-repeated field, or drills into a non-message field.
	ErrFieldNotFound = errors.New("dymsg: field not found")
	// ErrIndexOutOfRange is returned when a repeated index is invalid.
	ErrIndexOutOfRange = errors.New("dymsg: index out of range")
	// ErrTypeMismatch is returned when a value cannot be converted to the target
	// field type (including numeric overflow or schema mismatch).
	ErrTypeMismatch = errors.New("dymsg: type mismatch")
	// ErrMalformedData is returned when input data is malformed or does not
	// match the schema.
	ErrMalformedData = errors.New("dymsg: malformed data")
	// ErrTruncated is returned when input data is truncated.
	ErrTruncated = errors.New("dymsg: truncated data")
)

// FieldSchema describes a single field within a message schema.
type FieldSchema struct {
	// Name is the field name and also the JSON key.
	Name string
	// Num is the Protobuf field number in [1, 65535].
	Num int
	// Type is the field type.
	Type FieldType
	// Repeated indicates whether the field is an array.
	Repeated bool
	// Schema is the inline nested schema for message-typed fields.
	Schema MessageSchema
}

// MessageSchema describes the structure of a message.
//
// Top-level schemas returned by ParseSchema carry a non-zero TypeID.  Nested
// schemas (for message-typed fields) have TypeID zero.
type MessageSchema struct {
	// TypeID is the registered type ID for top-level messages (0 for nested).
	TypeID uint16
	// Fields lists the fields in declaration order.
	Fields []FieldSchema
	// byName maps field name to index into Fields.
	byName map[string]int
	// byNum maps field number to index into Fields.
	byNum map[int]int
}

// ensureIndexes builds the byName/byNum lookup maps if they are missing.  It is
// idempotent and also recurses into nested message schemas.
func (s *MessageSchema) ensureIndexes() {
	if s == nil {
		return
	}
	if s.byName == nil {
		s.byName = make(map[string]int, len(s.Fields))
		s.byNum = make(map[int]int, len(s.Fields))
	}
	for i := range s.Fields {
		f := &s.Fields[i]
		if _, ok := s.byName[f.Name]; !ok {
			s.byName[f.Name] = i
		}
		if _, ok := s.byNum[f.Num]; !ok {
			s.byNum[f.Num] = i
		}
		if f.Type == FieldMessage {
			f.Schema.ensureIndexes()
		}
	}
}

// schemaEqual reports whether two schemas are structurally identical: the same
// set of fields (matched by name) with equal numbers, types, repeated flags,
// and recursively equal nested schemas.  Field declaration order is not part of
// the comparison.
func schemaEqual(a, b *MessageSchema) bool {
	if a == nil || b == nil {
		return a == b
	}
	if len(a.Fields) != len(b.Fields) {
		return false
	}
	am := make(map[string]*FieldSchema, len(a.Fields))
	bm := make(map[string]*FieldSchema, len(b.Fields))
	for i := range a.Fields {
		am[a.Fields[i].Name] = &a.Fields[i]
	}
	for i := range b.Fields {
		bm[b.Fields[i].Name] = &b.Fields[i]
	}
	if len(am) != len(bm) {
		return false
	}
	for name, fa := range am {
		fb, ok := bm[name]
		if !ok {
			return false
		}
		if fa.Num != fb.Num || fa.Type != fb.Type || fa.Repeated != fb.Repeated {
			return false
		}
		if fa.Type == FieldMessage {
			if !schemaEqual(&fa.Schema, &fb.Schema) {
				return false
			}
		}
	}
	return true
}

// Message is a structured message instance holding a schema and field values.
//
// A Message is not safe for concurrent use; callers must synchronize access.
type Message struct {
	schema *MessageSchema
	fields map[string]any
}

// Value is the result of a Get operation.  It carries three orthogonal pieces
// of state: existence of the path, presence (whether the value is set), and any
// error encountered while resolving the path.
type Value struct {
	err    error
	val    any
	exists bool
	isSet  bool
}

// Exists reports whether the path is valid and the referenced field/element
// exists in the schema.
func (v Value) Exists() bool { return v.exists }

// IsSet reports whether the referenced field/element is set (presence).
func (v Value) IsSet() bool { return v.isSet }

// Err returns the resolution error, or nil on success.
func (v Value) Err() error { return v.err }

// Any returns the native Go value.  It returns nil when the path is invalid or
// the field is unset.
func (v Value) Any() any {
	if !v.exists || !v.isSet {
		return nil
	}
	return v.val
}

// String returns the field value as a string (zero value on type mismatch or
// when unset).
func (v Value) String() string {
	if !v.exists || !v.isSet {
		return ""
	}
	if s, ok := v.val.(string); ok {
		return s
	}
	return ""
}

// Int32 returns the field value as an int32.
func (v Value) Int32() int32 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(int32); ok {
		return n
	}
	return 0
}

// Int64 returns the field value as an int64.
func (v Value) Int64() int64 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(int64); ok {
		return n
	}
	return 0
}

// Uint32 returns the field value as a uint32.
func (v Value) Uint32() uint32 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(uint32); ok {
		return n
	}
	return 0
}

// Uint64 returns the field value as a uint64.
func (v Value) Uint64() uint64 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(uint64); ok {
		return n
	}
	return 0
}

// Float32 returns the field value as a float32.
func (v Value) Float32() float32 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(float32); ok {
		return n
	}
	return 0
}

// Float64 returns the field value as a float64.
func (v Value) Float64() float64 {
	if !v.exists || !v.isSet {
		return 0
	}
	if n, ok := v.val.(float64); ok {
		return n
	}
	return 0
}

// Bool returns the field value as a bool.
func (v Value) Bool() bool {
	if !v.exists || !v.isSet {
		return false
	}
	if b, ok := v.val.(bool); ok {
		return b
	}
	return false
}

// Bytes returns the field value as []byte.
func (v Value) Bytes() []byte {
	if !v.exists || !v.isSet {
		return nil
	}
	if b, ok := v.val.([]byte); ok {
		return b
	}
	return nil
}

// Message returns the field value as a nested *Message, or nil if the field is
// not a message or is unset.
func (v Value) Message() *Message {
	if !v.exists || !v.isSet {
		return nil
	}
	if m, ok := v.val.(*Message); ok {
		return m
	}
	return nil
}

// Len returns the length of a repeated field; 0 for non-repeated, unset, or
// non-existent fields.
func (v Value) Len() int {
	if !v.exists || !v.isSet {
		return 0
	}
	rv := reflect.ValueOf(v.val)
	if rv.Kind() != reflect.Slice {
		return 0
	}
	return rv.Len()
}

// Index returns a Value for the i-th element of a repeated field.  An out-of
// range index yields a Value with Err() == ErrIndexOutOfRange.
func (v Value) Index(i int) Value {
	if !v.exists || !v.isSet {
		return Value{err: ErrIndexOutOfRange}
	}
	rv := reflect.ValueOf(v.val)
	if rv.Kind() != reflect.Slice {
		return Value{err: ErrIndexOutOfRange}
	}
	if i < 0 || i >= rv.Len() {
		return Value{err: ErrIndexOutOfRange}
	}
	elem := rv.Index(i).Interface()
	set := true
	if m, ok := elem.(*Message); ok && m == nil {
		set = false
	}
	return Value{exists: true, isSet: set, val: elem}
}

// Strings returns the value of a repeated string field as []string.
func (v Value) Strings() []string {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]string); ok {
		return s
	}
	return nil
}

// Int32s returns the value of a repeated int32 field.
func (v Value) Int32s() []int32 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]int32); ok {
		return s
	}
	return nil
}

// Int64s returns the value of a repeated int64 field.
func (v Value) Int64s() []int64 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]int64); ok {
		return s
	}
	return nil
}

// Uint32s returns the value of a repeated uint32 field.
func (v Value) Uint32s() []uint32 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]uint32); ok {
		return s
	}
	return nil
}

// Uint64s returns the value of a repeated uint64 field.
func (v Value) Uint64s() []uint64 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]uint64); ok {
		return s
	}
	return nil
}

// Float32s returns the value of a repeated float field.
func (v Value) Float32s() []float32 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]float32); ok {
		return s
	}
	return nil
}

// Float64s returns the value of a repeated double field.
func (v Value) Float64s() []float64 {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]float64); ok {
		return s
	}
	return nil
}

// Bools returns the value of a repeated bool field.
func (v Value) Bools() []bool {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]bool); ok {
		return s
	}
	return nil
}

// BytesSlice returns the value of a repeated bytes field.
func (v Value) BytesSlice() [][]byte {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([][]byte); ok {
		return s
	}
	return nil
}

// Messages returns the value of a repeated message field.
func (v Value) Messages() []*Message {
	if !v.exists || !v.isSet {
		return nil
	}
	if s, ok := v.val.([]*Message); ok {
		return s
	}
	return nil
}

// Global registry of schemas by type ID.
var (
	regMu    sync.RWMutex
	registry = make(map[uint16]*MessageSchema)
)

// Register registers a message schema under its type ID.
//
// Registering an identical schema (same type ID and equal field definitions)
// is idempotent and returns nil.  Registering a different schema for an
// already-used type ID returns ErrDuplicateID.
func Register(s MessageSchema) error {
	if s.TypeID == 0 {
		return ErrMalformedData
	}
	s.ensureIndexes()
	regMu.Lock()
	defer regMu.Unlock()
	if existing, ok := registry[s.TypeID]; ok {
		if schemaEqual(existing, &s) {
			return nil
		}
		return ErrDuplicateID
	}
	cp := s
	registry[s.TypeID] = &cp
	return nil
}

// New constructs an empty Message for the given registered type ID.
func New(typeID uint16) (*Message, error) {
	regMu.RLock()
	s, ok := registry[typeID]
	regMu.RUnlock()
	if !ok {
		return nil, ErrUnknownTypeID
	}
	return &Message{schema: s, fields: make(map[string]any)}, nil
}

// validFieldType reports whether t is one of the supported field types.
func validFieldType(t FieldType) bool {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64,
		FieldFloat, FieldDouble, FieldBool, FieldString, FieldBytes, FieldMessage:
		return true
	}
	return false
}

// nameValidForField reports whether a field name is acceptable (non-empty and
// free of the path metacharacters '.', '[', ']').
func nameValidForField(name string) bool {
	if name == "" {
		return false
	}
	return !strings.ContainsAny(name, ".[]")
}
