package dymsg

import (
	"bytes"
	"errors"
	"math"
	"reflect"
	"sync"
	"testing"
)

func TestParseSchemaErrors(t *testing.T) {
	cases := []string{
		``,                                     // empty
		`{`,                                    // bad JSON
		`{"types":[{"typeId":0,"fields":[]}]}`, // typeId 0
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"bad","num":1}]}]}`,                                         // bad type
		`{"types":[{"typeId":1,"fields":[{"name":"a.b","type":"string","num":1}]}]}`,                                    // name with dot
		`{"types":[{"typeId":1,"fields":[{"name":"a[0]","type":"string","num":1}]}]}`,                                   // name with bracket
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":0}]}]}`,                                      // num 0
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":65536}]}]}`,                                  // num too big
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1},{"name":"a","type":"string","num":2}]}]}`, // dup name
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1},{"name":"b","type":"string","num":1}]}]}`, // dup num
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1,"schema":{"fields":[]}}]}]}`,               // non-message with schema
		`{"types":[{"name":"a","type":"string","num":1}]}`,                                                              // missing typeId field? Actually field without typeId -> typeId 0
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"message","num":1}]}]}`,                                     // message missing schema
		`{"types":[{"typeId":1,"fields":[]},{"typeId":1,"fields":[]}]}`,                                                 // dup typeId in file
	}
	for i, tc := range cases {
		if _, err := ParseSchema([]byte(tc)); !errors.Is(err, ErrMalformedData) {
			t.Fatalf("case %d: expected ErrMalformedData, got %v for input %q", i, err, tc)
		}
	}
}

func TestParseSchemaRepeatedMessage(t *testing.T) {
	cfg := `{"types":[{"typeId":3001,"fields":[
		{"name":"items","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"v","type":"int32","num":1}
		]}}
	]}]}`
	schemas, err := ParseSchema([]byte(cfg))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, err := New(3001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if err := m.Append("items", nil); err != nil {
		t.Fatalf("Append nil: %v", err)
	}
	// Create a sub message via Set on a fresh message.
	m2, _ := New(3001)
	// Build a proper sub message.
	sub := &Message{schema: &schemas[0].Fields[0].Schema, fields: map[string]any{"v": int32(7)}}
	if err := m2.Set("items", []*Message{nil, sub}); err != nil {
		t.Fatalf("Set items: %v", err)
	}
	v := m2.Get("items")
	if v.Len() != 2 {
		t.Fatalf("items len = %d", v.Len())
	}
	if v.Index(0).IsSet() {
		t.Fatal("items[0] should be unset")
	}
	if got := v.Index(1).Message().Get("v").Int32(); got != 7 {
		t.Fatalf("items[1].v = %d, want 7", got)
	}
	// messages getter
	msgs := v.Messages()
	if len(msgs) != 2 || msgs[0] != nil || msgs[1] == nil {
		t.Fatalf("Messages = %v", msgs)
	}
}

func TestGetEmptyPath(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	v := m.Get("")
	if !v.Exists() || !v.IsSet() {
		t.Fatalf("Get empty: exists=%v isSet=%v", v.Exists(), v.IsSet())
	}
	if v.Err() != nil {
		t.Fatalf("Get empty Err = %v", v.Err())
	}
	if v.Message() != m {
		t.Fatal("Get empty Message should be self")
	}
	if v.Any() != m {
		t.Fatal("Get empty Any should be self")
	}
}

func TestSetWholeMessageTypeMismatch(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// A different schema.
	cfg := `{"types":[{"typeId":4001,"fields":[{"name":"x","type":"string","num":1}]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	other, _ := New(4001)
	if err := m.Set("", other); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set whole different schema: %v", err)
	}
}

func TestValueIndexOutOfRange(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Append("tags", "a")
	v := m.Get("tags")
	iv := v.Index(1)
	if iv.Exists() || !errors.Is(iv.Err(), ErrIndexOutOfRange) {
		t.Fatalf("Index(1) exists=%v err=%v", iv.Exists(), iv.Err())
	}
	iv = v.Index(-1)
	if iv.Exists() || !errors.Is(iv.Err(), ErrIndexOutOfRange) {
		t.Fatalf("Index(-1) exists=%v err=%v", iv.Exists(), iv.Err())
	}
}

func TestAppendMessageRepeated(t *testing.T) {
	cfg := `{"types":[{"typeId":5001,"fields":[
		{"name":"contacts","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"name","type":"string","num":1}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(5001)
	sub := &Message{schema: &schemas[0].Fields[0].Schema, fields: map[string]any{"name": "alice"}}
	if err := m.Append("contacts", sub); err != nil {
		t.Fatalf("Append contacts: %v", err)
	}
	// Modifying sub after append should not affect m (deep copy).
	sub.fields["name"] = "bob"
	if got := m.Get("contacts").Index(0).Message().Get("name").String(); got != "alice" {
		t.Fatalf("contacts[0].name = %q, want alice", got)
	}
}

func TestClearWithIndex(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Append("tags", "a")
	m.Append("tags", "b")
	if err := m.Clear("tags[0]"); err != nil {
		t.Fatalf("Clear tags[0]: %v", err)
	}
	if got := m.Get("tags").Strings(); !reflect.DeepEqual(got, []string{"", "b"}) {
		t.Fatalf("tags = %v, want [ b]", got)
	}
}

func TestJSONEncodeNaNError(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("scores", []float64{math.NaN()})
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("EncodeJSON NaN: %v", err)
	}
	m.Set("scores", []float64{math.Inf(1)})
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("EncodeJSON Inf: %v", err)
	}
}

func TestProtoPackedVarint(t *testing.T) {
	cfg := `{"types":[{"typeId":6001,"fields":[
		{"name":"nums","type":"int32","num":1,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(6001)
	m.Set("nums", []int32{1, -2, 3})
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(6001)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if got := m2.Get("nums").Int32s(); !reflect.DeepEqual(got, []int32{1, -2, 3}) {
		t.Fatalf("nums = %v", got)
	}
}

func TestProtoMixedPackedUnpacked(t *testing.T) {
	cfg := `{"types":[{"typeId":6002,"fields":[
		{"name":"nums","type":"int32","num":1,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	// Unpacked element 1.
	var buf []byte
	buf = appendVarint(buf, uint64(1<<3)|0)
	buf = appendVarint(buf, 1)
	// Packed [2, 3].
	buf = appendVarint(buf, uint64(1<<3)|2)
	packed := appendVarint(nil, 2)
	packed = appendVarint(packed, 3)
	buf = appendVarint(buf, uint64(len(packed)))
	buf = append(buf, packed...)
	// Unpacked element 4.
	buf = appendVarint(buf, uint64(1<<3)|0)
	buf = appendVarint(buf, 4)

	m, _ := New(6002)
	if err := m.DecodeProto(buf); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if got := m.Get("nums").Int32s(); !reflect.DeepEqual(got, []int32{1, 2, 3, 4}) {
		t.Fatalf("nums = %v", got)
	}
}

func TestProtoWireTypeMismatchRepeated(t *testing.T) {
	cfg := `{"types":[{"typeId":6003,"fields":[
		{"name":"nums","type":"int32","num":1,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	// Field 1 with wire type 5 (float) for an int32 repeated -> mismatch.
	m, _ := New(6003)
	if err := m.DecodeProto([]byte{0x0d}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire mismatch err = %v", err)
	}
}

func TestJSONTrailingContent(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.DecodeJSON([]byte(`{"name":"x"} extra`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("trailing content err = %v", err)
	}
}

func TestProtoTruncatedVarint(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Field 1 (string) key with a length varint that is truncated.
	if err := m.DecodeProto([]byte{0x0a, 0x05, 'a', 'b'}); !errors.Is(err, ErrTruncated) {
		t.Fatalf("truncated err = %v", err)
	}
}

func TestClearDoesNotCreateIntermediate(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Clearing a nested field under an unset message should be a no-op,
	// not auto-create the intermediate message.
	if err := m.Clear("addr.city"); err != nil {
		t.Fatalf("Clear addr.city: %v", err)
	}
	if m.Has("addr") {
		t.Fatal("Clear should not create addr")
	}
	// Set addr, then clear a child.
	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatalf("Set: %v", err)
	}
	if err := m.Clear("addr.zip"); err != nil {
		t.Fatalf("Clear addr.zip: %v", err)
	}
	if !m.Has("addr") {
		t.Fatal("addr should still be set")
	}
	if m.Has("addr.zip") {
		t.Fatal("addr.zip should be cleared")
	}
}

func TestParseSchemaNullRoot(t *testing.T) {
	if _, err := ParseSchema([]byte(`null`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("null root err = %v, want ErrMalformedData", err)
	}
	if _, err := ParseSchema([]byte(`[]`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("array root err = %v, want ErrMalformedData", err)
	}
}

func TestSetTypedNilMessage(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("addr.city", "beijing")
	if err := m.Set("addr", (*Message)(nil)); err != nil {
		t.Fatalf("Set typed nil addr: %v", err)
	}
	if m.Has("addr") {
		t.Fatal("addr should be cleared by typed nil")
	}
	// Set whole message to typed nil clears.
	m.Set("name", "alice")
	if err := m.Set("", (*Message)(nil)); err != nil {
		t.Fatalf("Set typed nil whole: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields = %v, want empty", m.SetFields())
	}
}

func TestSetWholeSelfCopy(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("addr.city", "beijing")
	// Copy m onto itself; it should retain its fields.
	if err := m.Set("", m); err != nil {
		t.Fatalf("Set self: %v", err)
	}
	if got := m.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q, want alice", got)
	}
	if got := m.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("addr.city = %q, want beijing", got)
	}
}

func TestRegisterInvalidTypeID(t *testing.T) {
	var s MessageSchema // TypeID 0
	if err := Register(s); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("Register typeID 0: %v", err)
	}
}

func TestConcurrentRegisterNew(t *testing.T) {
	// Register several schemas concurrently and construct messages.
	cfg := `{"types":[{"typeId":7001,"fields":[{"name":"a","type":"int32","num":1}]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := Register(schemas[0]); err != nil {
				t.Errorf("Register: %v", err)
			}
			m, err := New(7001)
			if err != nil {
				t.Errorf("New: %v", err)
			}
			if err := m.Set("a", int32(i)); err != nil {
				t.Errorf("Set: %v", err)
			}
		}()
	}
	wg.Wait()
}

func TestProtoBytesRoundTrip(t *testing.T) {
	cfg := `{"types":[{"typeId":8001,"fields":[
		{"name":"blobs","type":"bytes","num":1,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(8001)
	m.Set("blobs", [][]byte{[]byte("a"), nil, []byte("c")})
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(8001)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	got := m2.Get("blobs").BytesSlice()
	if len(got) != 3 || string(got[0]) != "a" || len(got[1]) != 0 || string(got[2]) != "c" {
		t.Fatalf("blobs = %v", got)
	}
}

func TestJSONRepeatedBytesRoundTrip(t *testing.T) {
	cfg := `{"types":[{"typeId":8002,"fields":[
		{"name":"blobs","type":"bytes","num":1,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(8002)
	m.Set("blobs", [][]byte{[]byte("a"), []byte("c")})
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	m2, _ := New(8002)
	if err := m2.DecodeJSON(data); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	got := m2.Get("blobs").BytesSlice()
	if len(got) != 2 || string(got[0]) != "a" || string(got[1]) != "c" {
		t.Fatalf("blobs = %v", got)
	}
}

func TestAnyReturnsNativeValues(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", int32(30))
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")
	m.Set("data", []byte{1, 2})

	if v := m.Get("name").Any(); v != "alice" {
		t.Fatalf("Any name = %v", v)
	}
	if v := m.Get("age").Any(); v != int32(30) {
		t.Fatalf("Any age = %v", v)
	}
	if v := m.Get("addr").Any(); v == nil {
		t.Fatal("Any addr should be non-nil")
	}
	if v := m.Get("tags").Any(); !reflect.DeepEqual(v, []string{"a"}) {
		t.Fatalf("Any tags = %v", v)
	}
	if v := m.Get("data").Any(); !bytes.Equal(v.([]byte), []byte{1, 2}) {
		t.Fatalf("Any data = %v", v)
	}
}

func TestHasUnknownField(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if m.Has("unknown") {
		t.Fatal("Has unknown should be false")
	}
}

func TestSetNestedScalarError(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// name is scalar, cannot drill into it.
	if err := m.Set("name.x", "v"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set name.x: %v", err)
	}
}

func TestProtoFloat32RoundTrip(t *testing.T) {
	cfg := `{"types":[{"typeId":9001,"fields":[
		{"name":"f","type":"float","num":1},
		{"name":"fs","type":"float","num":2,"repeated":true}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9001)
	m.Set("f", float32(1.5))
	m.Set("fs", []float32{2.5, -3.5})
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(9001)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if got := m2.Get("f").Float32(); got != 1.5 {
		t.Fatalf("f = %v", got)
	}
	if got := m2.Get("fs").Float32s(); !reflect.DeepEqual(got, []float32{2.5, -3.5}) {
		t.Fatalf("fs = %v", got)
	}
}

func TestProtoEmptyPackedField(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("scores", []float64{})
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2 := mustNew(t)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if !m2.Has("scores") {
		t.Fatal("scores should be set after round-trip of empty packed field")
	}
	if m2.Get("scores").Len() != 0 {
		t.Fatalf("scores len = %d, want 0", m2.Get("scores").Len())
	}
}

func TestJSONRepeatedMessageRoundTripWithNil(t *testing.T) {
	cfg := `{"types":[{"typeId":9501,"fields":[
		{"name":"contacts","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"name","type":"string","num":1}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9501)
	if err := m.DecodeJSON([]byte(`{"contacts":[null,{"name":"bob"}]}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	if !bytes.Contains(data, []byte(`null`)) {
		t.Fatalf("expected null in encoded JSON, got %s", data)
	}
}

func TestSetWrongTypeForMessageField(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("addr", "not-a-message"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set addr wrong type: %v", err)
	}
}

func TestAppendWrongSchemaMessage(t *testing.T) {
	cfg := `{"types":[{"typeId":9502,"fields":[
		{"name":"contacts","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"name","type":"string","num":1}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	// A message with a different schema.
	cfg2 := `{"types":[{"typeId":9503,"fields":[{"name":"x","type":"string","num":1}]}]}`
	schemas2, _ := ParseSchema([]byte(cfg2))
	if err := Register(schemas2[0]); err != nil {
		t.Fatalf("Register 2: %v", err)
	}
	other, _ := New(9503)
	m, _ := New(9502)
	if err := m.Append("contacts", other); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append wrong schema: %v", err)
	}
}

func TestGetDrillIntoNonExistentSubfield(t *testing.T) {
	cfg := `{"types":[{"typeId":9504,"fields":[
		{"name":"addr","type":"message","num":1,"schema":{"fields":[
			{"name":"city","type":"string","num":1}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9504)
	m.Set("addr.city", "beijing")
	v := m.Get("addr.nope")
	if v.Exists() || !errors.Is(v.Err(), ErrFieldNotFound) {
		t.Fatalf("addr.nope exists=%v err=%v", v.Exists(), v.Err())
	}
}

func TestAllScalarTypesRoundTrip(t *testing.T) {
	cfg := `{"types":[{"typeId":9701,"fields":[
		{"name":"i32","type":"int32","num":1},
		{"name":"i64","type":"int64","num":2},
		{"name":"u32","type":"uint32","num":3},
		{"name":"u64","type":"uint64","num":4},
		{"name":"f","type":"float","num":5},
		{"name":"d","type":"double","num":6},
		{"name":"b","type":"bool","num":7},
		{"name":"s","type":"string","num":8},
		{"name":"by","type":"bytes","num":9}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9701)
	m.Set("i32", int32(-123))
	m.Set("i64", int64(-456))
	m.Set("u32", uint32(123))
	m.Set("u64", uint64(456))
	m.Set("f", float32(1.25))
	m.Set("d", float64(2.5))
	m.Set("b", true)
	m.Set("s", "hello")
	m.Set("by", []byte{1, 2, 3})

	// JSON round-trip.
	js, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	m2, _ := New(9701)
	if err := m2.DecodeJSON(js); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m2.Get("i32").Int32() != -123 || m2.Get("i64").Int64() != -456 ||
		m2.Get("u32").Uint32() != 123 || m2.Get("u64").Uint64() != 456 ||
		m2.Get("f").Float32() != 1.25 || m2.Get("d").Float64() != 2.5 ||
		!m2.Get("b").Bool() || m2.Get("s").String() != "hello" ||
		!bytes.Equal(m2.Get("by").Bytes(), []byte{1, 2, 3}) {
		t.Fatal("JSON round-trip mismatch")
	}

	// Proto round-trip.
	pr, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m3, _ := New(9701)
	if err := m3.DecodeProto(pr); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m3.Get("i32").Int32() != -123 || m3.Get("i64").Int64() != -456 ||
		m3.Get("u32").Uint32() != 123 || m3.Get("u64").Uint64() != 456 ||
		m3.Get("f").Float32() != 1.25 || m3.Get("d").Float64() != 2.5 ||
		!m3.Get("b").Bool() || m3.Get("s").String() != "hello" ||
		!bytes.Equal(m3.Get("by").Bytes(), []byte{1, 2, 3}) {
		t.Fatal("Proto round-trip mismatch")
	}
}

func TestClearIndexOutOfRange(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Append("tags", "a")
	if err := m.Clear("tags[5]"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Clear tags[5]: %v", err)
	}
	if err := m.Clear("tags[-1]"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Clear tags[-1]: %v", err)
	}
}

func TestNestedAppendAutoCreate(t *testing.T) {
	cfg := `{"types":[{"typeId":9601,"fields":[
		{"name":"grp","type":"message","num":1,"schema":{"fields":[
			{"name":"tags","type":"string","num":1,"repeated":true}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9601)
	if err := m.Append("grp.tags", "a"); err != nil {
		t.Fatalf("Append grp.tags: %v", err)
	}
	if !m.Has("grp") {
		t.Fatal("grp should be auto-created")
	}
	if got := m.Get("grp.tags").Strings(); !reflect.DeepEqual(got, []string{"a"}) {
		t.Fatalf("grp.tags = %v", got)
	}
}

func TestProtoBoolUintRoundTrip(t *testing.T) {
	cfg := `{"types":[{"typeId":9002,"fields":[
		{"name":"b","type":"bool","num":1},
		{"name":"u32","type":"uint32","num":2},
		{"name":"u64","type":"uint64","num":3}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(9002)
	m.Set("b", true)
	m.Set("u32", uint32(4000000000))
	m.Set("u64", uint64(18000000000000000000))
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(9002)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if !m2.Get("b").Bool() {
		t.Fatal("b should be true")
	}
	if got := m2.Get("u32").Uint32(); got != 4000000000 {
		t.Fatalf("u32 = %d", got)
	}
	if got := m2.Get("u64").Uint64(); got != 18000000000000000000 {
		t.Fatalf("u64 = %d", got)
	}
}
