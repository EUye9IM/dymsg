package dymsg

import (
	"math"
	"reflect"
)

// protoReader reads Protobuf wire-format primitives from a byte slice.
type protoReader struct {
	data []byte
	pos  int
}

func (r *protoReader) remaining() int { return len(r.data) - r.pos }

func (r *protoReader) readVarint() (uint64, error) {
	var v uint64
	var shift uint
	for {
		if r.pos >= len(r.data) {
			return 0, ErrTruncated
		}
		b := r.data[r.pos]
		r.pos++
		v |= uint64(b&0x7f) << shift
		if b&0x80 == 0 {
			return v, nil
		}
		shift += 7
		if shift >= 64 {
			return 0, ErrMalformedData
		}
	}
}

func (r *protoReader) readBytes(n int) ([]byte, error) {
	if n < 0 {
		return nil, ErrMalformedData
	}
	if r.pos+n > len(r.data) {
		return nil, ErrTruncated
	}
	b := r.data[r.pos : r.pos+n]
	r.pos += n
	return b, nil
}

func (r *protoReader) skip(wireType int) error {
	switch wireType {
	case 0:
		_, err := r.readVarint()
		return err
	case 1:
		_, err := r.readBytes(8)
		return err
	case 2:
		n, err := r.readVarint()
		if err != nil {
			return err
		}
		_, err = r.readBytes(int(n))
		return err
	case 5:
		_, err := r.readBytes(4)
		return err
	default:
		return ErrMalformedData
	}
}

// appendVarint appends a varint-encoded uint64 to buf.
func appendVarint(buf []byte, v uint64) []byte {
	for v >= 0x80 {
		buf = append(buf, byte(v)|0x80)
		v >>= 7
	}
	buf = append(buf, byte(v))
	return buf
}

// protoWireType returns the non-packed wire type for a field type.
func protoWireType(t FieldType) int {
	switch t {
	case FieldFloat:
		return 5
	case FieldDouble:
		return 1
	case FieldString, FieldBytes, FieldMessage:
		return 2
	default:
		return 0
	}
}

// EncodeProto encodes the message into Protobuf wire format.
func (m *Message) EncodeProto() ([]byte, error) {
	var buf []byte
	for i := range m.schema.Fields {
		fs := &m.schema.Fields[i]
		val, ok := m.fields[fs.Name]
		if !ok {
			continue
		}
		if fs.Type == FieldMessage && !fs.Repeated && val == nil {
			continue
		}
		var err error
		buf, err = encodeProtoField(buf, fs, val)
		if err != nil {
			return nil, err
		}
	}
	return buf, nil
}

func encodeProtoField(buf []byte, fs *FieldSchema, val any) ([]byte, error) {
	if fs.Repeated {
		return encodeProtoRepeated(buf, fs, val)
	}
	key := uint64(fs.Num<<3) | uint64(protoWireType(fs.Type))
	switch fs.Type {
	case FieldMessage:
		msg, _ := val.(*Message)
		if msg == nil {
			return buf, nil
		}
		inner, err := msg.EncodeProto()
		if err != nil {
			return nil, err
		}
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(len(inner)))
		buf = append(buf, inner...)
	case FieldInt32:
		n, _ := val.(int32)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(int64(n)))
	case FieldInt64:
		n, _ := val.(int64)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(n))
	case FieldUint32:
		n, _ := val.(uint32)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(n))
	case FieldUint64:
		n, _ := val.(uint64)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, n)
	case FieldBool:
		b, _ := val.(bool)
		buf = appendVarint(buf, key)
		if b {
			buf = appendVarint(buf, 1)
		} else {
			buf = appendVarint(buf, 0)
		}
	case FieldFloat:
		f, _ := val.(float32)
		buf = appendVarint(buf, key)
		bits := math.Float32bits(f)
		buf = append(buf, byte(bits), byte(bits>>8), byte(bits>>16), byte(bits>>24))
	case FieldDouble:
		f, _ := val.(float64)
		buf = appendVarint(buf, key)
		bits := math.Float64bits(f)
		for i := 0; i < 8; i++ {
			buf = append(buf, byte(bits>>(8*i)))
		}
	case FieldString:
		s, _ := val.(string)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(len(s)))
		buf = append(buf, s...)
	case FieldBytes:
		b, _ := val.([]byte)
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(len(b)))
		buf = append(buf, b...)
	}
	return buf, nil
}

func encodeProtoRepeated(buf []byte, fs *FieldSchema, val any) ([]byte, error) {
	rv := reflect.ValueOf(val)
	if rv.Kind() != reflect.Slice {
		return nil, ErrTypeMismatch
	}
	n := rv.Len()
	key := uint64(fs.Num<<3) | 2

	switch fs.Type {
	case FieldString, FieldBytes, FieldMessage:
		for i := 0; i < n; i++ {
			ev := rv.Index(i).Interface()
			var elemBuf []byte
			switch fs.Type {
			case FieldMessage:
				msg, _ := ev.(*Message)
				if msg == nil {
					continue // nil message elements are skipped
				}
				inner, err := msg.EncodeProto()
				if err != nil {
					return nil, err
				}
				elemBuf = appendVarint(nil, key)
				elemBuf = appendVarint(elemBuf, uint64(len(inner)))
				elemBuf = append(elemBuf, inner...)
			case FieldString:
				s, _ := ev.(string)
				elemBuf = appendVarint(nil, key)
				elemBuf = appendVarint(elemBuf, uint64(len(s)))
				elemBuf = append(elemBuf, s...)
			case FieldBytes:
				b, _ := ev.([]byte)
				elemBuf = appendVarint(nil, key)
				elemBuf = appendVarint(elemBuf, uint64(len(b)))
				elemBuf = append(elemBuf, b...)
			}
			buf = append(buf, elemBuf...)
		}
	default:
		// Packed encoding for scalar repeated fields.
		var payload []byte
		for i := 0; i < n; i++ {
			ev := rv.Index(i).Interface()
			switch fs.Type {
			case FieldInt32:
				v, _ := ev.(int32)
				payload = appendVarint(payload, uint64(int64(v)))
			case FieldInt64:
				v, _ := ev.(int64)
				payload = appendVarint(payload, uint64(v))
			case FieldUint32:
				v, _ := ev.(uint32)
				payload = appendVarint(payload, uint64(v))
			case FieldUint64:
				v, _ := ev.(uint64)
				payload = appendVarint(payload, v)
			case FieldBool:
				v, _ := ev.(bool)
				if v {
					payload = appendVarint(payload, 1)
				} else {
					payload = appendVarint(payload, 0)
				}
			case FieldFloat:
				v, _ := ev.(float32)
				bits := math.Float32bits(v)
				payload = append(payload, byte(bits), byte(bits>>8), byte(bits>>16), byte(bits>>24))
			case FieldDouble:
				v, _ := ev.(float64)
				bits := math.Float64bits(v)
				for i := 0; i < 8; i++ {
					payload = append(payload, byte(bits>>(8*i)))
				}
			}
		}
		buf = appendVarint(buf, key)
		buf = appendVarint(buf, uint64(len(payload)))
		buf = append(buf, payload...)
	}
	return buf, nil
}

// DecodeProto decodes Protobuf wire-format data into the message, replacing all
// existing field values.  A zero-byte input decodes to an empty (all-unset)
// message.
func (m *Message) DecodeProto(data []byte) error {
	m.fields = make(map[string]any)
	r := &protoReader{data: data}
	for r.pos < len(r.data) {
		key, err := r.readVarint()
		if err != nil {
			return err
		}
		fieldNum := key >> 3
		wireType := int(key & 7)
		if fieldNum == 0 {
			return ErrMalformedData
		}
		if wireType == 6 || wireType == 7 {
			return ErrMalformedData
		}
		idx, ok := m.schema.byNum[int(fieldNum)]
		if !ok {
			if err := r.skip(wireType); err != nil {
				return err
			}
			continue
		}
		fs := &m.schema.Fields[idx]
		if err := m.decodeKnownField(r, fs, wireType); err != nil {
			return err
		}
	}
	return nil
}

func (m *Message) decodeKnownField(r *protoReader, fs *FieldSchema, wireType int) error {
	if !fs.Repeated {
		val, err := r.decodeElement(fs, wireType)
		if err != nil {
			return err
		}
		m.fields[fs.Name] = val
		return nil
	}
	switch fs.Type {
	case FieldString, FieldBytes, FieldMessage:
		if wireType != 2 {
			return ErrMalformedData
		}
		val, err := r.decodeElement(fs, wireType)
		if err != nil {
			return err
		}
		m.appendRepeated(fs, val)
		return nil
	default:
		// Scalar repeated: wire type 2 is packed, otherwise unpacked element.
		elemWire := protoWireType(fs.Type)
		if wireType == 2 {
			n, err := r.readVarint()
			if err != nil {
				return err
			}
			if n > uint64(r.remaining()) {
				return ErrTruncated
			}
			packed, err := r.decodePacked(fs, int(n))
			if err != nil {
				return err
			}
			m.mergeRepeated(fs, packed)
			return nil
		}
		if wireType != elemWire {
			return ErrMalformedData
		}
		val, err := r.decodeElement(fs, wireType)
		if err != nil {
			return err
		}
		m.appendRepeated(fs, val)
		return nil
	}
}

func (r *protoReader) decodeElement(fs *FieldSchema, wireType int) (any, error) {
	switch fs.Type {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		if wireType != 0 {
			return nil, ErrMalformedData
		}
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		switch fs.Type {
		case FieldInt32:
			return int32(v), nil
		case FieldInt64:
			return int64(v), nil
		case FieldUint32:
			return uint32(v), nil
		case FieldUint64:
			return v, nil
		case FieldBool:
			return v != 0, nil
		}
	case FieldFloat:
		if wireType != 5 {
			return nil, ErrMalformedData
		}
		b, err := r.readBytes(4)
		if err != nil {
			return nil, err
		}
		bits := uint32(b[0]) | uint32(b[1])<<8 | uint32(b[2])<<16 | uint32(b[3])<<24
		return math.Float32frombits(bits), nil
	case FieldDouble:
		if wireType != 1 {
			return nil, ErrMalformedData
		}
		b, err := r.readBytes(8)
		if err != nil {
			return nil, err
		}
		var bits uint64
		for i := 0; i < 8; i++ {
			bits |= uint64(b[i]) << (8 * i)
		}
		return math.Float64frombits(bits), nil
	case FieldString:
		if wireType != 2 {
			return nil, ErrMalformedData
		}
		n, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		b, err := r.readBytes(int(n))
		if err != nil {
			return nil, err
		}
		return string(b), nil
	case FieldBytes:
		if wireType != 2 {
			return nil, ErrMalformedData
		}
		n, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		b, err := r.readBytes(int(n))
		if err != nil {
			return nil, err
		}
		out := make([]byte, len(b))
		copy(out, b)
		return out, nil
	case FieldMessage:
		if wireType != 2 {
			return nil, ErrMalformedData
		}
		n, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		b, err := r.readBytes(int(n))
		if err != nil {
			return nil, err
		}
		msg := &Message{schema: &fs.Schema, fields: make(map[string]any)}
		if err := msg.DecodeProto(b); err != nil {
			return nil, err
		}
		return msg, nil
	}
	return nil, ErrMalformedData
}

func (r *protoReader) decodePacked(fs *FieldSchema, length int) (any, error) {
	b, err := r.readBytes(length)
	if err != nil {
		return nil, err
	}
	sub := &protoReader{data: b}
	out := reflect.MakeSlice(reflect.SliceOf(targetGoType(fs.Type)), 0, 0)
	for sub.pos < len(sub.data) {
		var elem any
		switch fs.Type {
		case FieldInt32:
			v, err := sub.readVarint()
			if err != nil {
				return nil, err
			}
			elem = int32(v)
		case FieldInt64:
			v, err := sub.readVarint()
			if err != nil {
				return nil, err
			}
			elem = int64(v)
		case FieldUint32:
			v, err := sub.readVarint()
			if err != nil {
				return nil, err
			}
			elem = uint32(v)
		case FieldUint64:
			v, err := sub.readVarint()
			if err != nil {
				return nil, err
			}
			elem = v
		case FieldBool:
			v, err := sub.readVarint()
			if err != nil {
				return nil, err
			}
			elem = v != 0
		case FieldFloat:
			fb, err := sub.readBytes(4)
			if err != nil {
				return nil, err
			}
			bits := uint32(fb[0]) | uint32(fb[1])<<8 | uint32(fb[2])<<16 | uint32(fb[3])<<24
			elem = math.Float32frombits(bits)
		case FieldDouble:
			db, err := sub.readBytes(8)
			if err != nil {
				return nil, err
			}
			var bits uint64
			for i := 0; i < 8; i++ {
				bits |= uint64(db[i]) << (8 * i)
			}
			elem = math.Float64frombits(bits)
		default:
			return nil, ErrMalformedData
		}
		out = reflect.Append(out, reflect.ValueOf(elem))
	}
	return out.Interface(), nil
}

func (m *Message) appendRepeated(fs *FieldSchema, val any) {
	arr, ok := m.fields[fs.Name]
	if !ok {
		arr = makeEmptySlice(fs)
	}
	m.fields[fs.Name] = appendToSlice(arr, val)
}

func (m *Message) mergeRepeated(fs *FieldSchema, packed any) {
	rv := reflect.ValueOf(packed)
	if rv.Len() == 0 {
		if _, ok := m.fields[fs.Name]; !ok {
			m.fields[fs.Name] = makeEmptySlice(fs)
		}
		return
	}
	for i := 0; i < rv.Len(); i++ {
		m.appendRepeated(fs, rv.Index(i).Interface())
	}
}
