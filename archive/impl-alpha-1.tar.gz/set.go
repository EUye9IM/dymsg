package dymsg

import "reflect"

// Set assigns a value to the field/element addressed by path.
//
// Set("", m) overwrites the whole message with a deep copy of m.  Set(path,
// nil) clears the referenced field (equivalent to Clear).  Intermediate
// message fields are auto-created when they are unset.
func (m *Message) Set(path string, value any) error {
	if path == "" {
		if isClearValue(value) {
			m.fields = make(map[string]any)
			return nil
		}
		src, ok := value.(*Message)
		if !ok {
			return ErrTypeMismatch
		}
		if !schemaEqual(m.schema, src.schema) {
			return ErrTypeMismatch
		}
		// Build the new field map before replacing, so that Set("", m) where
		// m is the receiver itself works correctly.
		nf := make(map[string]any, len(src.fields))
		for name, val := range src.fields {
			nf[name] = deepCopyValue(val)
		}
		m.fields = nf
		return nil
	}
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return ErrFieldNotFound
	}
	parent, lastSeg, err := m.navigate(segs)
	if err != nil {
		return err
	}
	return setFieldValue(parent, *lastSeg, value)
}

// navigate walks all path segments except the last, creating intermediate
// message values as needed.  It returns the message containing the target
// field and the final segment.
func (m *Message) navigate(segs []pathSeg) (*Message, *pathSeg, error) {
	if len(segs) == 0 {
		return nil, nil, ErrFieldNotFound
	}
	cur := m
	for i := 0; i < len(segs)-1; i++ {
		seg := segs[i]
		idx, ok := cur.schema.byName[seg.name]
		if !ok {
			return nil, nil, ErrFieldNotFound
		}
		fs := &cur.schema.Fields[idx]
		if seg.hasIndex {
			if !fs.Repeated {
				return nil, nil, ErrFieldNotFound
			}
			arr, ok := cur.fields[fs.Name]
			if !ok {
				return nil, nil, ErrIndexOutOfRange
			}
			if seg.index < 0 || seg.index >= sliceLen(arr) {
				return nil, nil, ErrIndexOutOfRange
			}
			if fs.Type != FieldMessage {
				return nil, nil, ErrFieldNotFound
			}
			msg, _ := sliceIndex(arr, seg.index).(*Message)
			if msg == nil {
				msg = &Message{schema: &fs.Schema, fields: make(map[string]any)}
				setSliceIndex(arr, seg.index, msg)
			}
			cur = msg
		} else {
			if fs.Type != FieldMessage || fs.Repeated {
				return nil, nil, ErrFieldNotFound
			}
			val, ok := cur.fields[fs.Name]
			var child *Message
			if ok && val != nil {
				child = val.(*Message)
			} else {
				child = &Message{schema: &fs.Schema, fields: make(map[string]any)}
				cur.fields[fs.Name] = child
			}
			cur = child
		}
	}
	return cur, &segs[len(segs)-1], nil
}

// isClearValue reports whether value should be treated as "nil" for clearing
// purposes.  The untyped nil and typed nil pointers (such as a nil *Message)
// clear a field; a nil slice does not (it represents an empty repeated value).
func isClearValue(value any) bool {
	if value == nil {
		return true
	}
	rv := reflect.ValueOf(value)
	switch rv.Kind() {
	case reflect.Ptr, reflect.Interface, reflect.Map, reflect.Func, reflect.Chan:
		return rv.IsNil()
	}
	return false
}

// setFieldValue assigns a value to the field described by seg within m.
func setFieldValue(m *Message, seg pathSeg, value any) error {
	idx, ok := m.schema.byName[seg.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := &m.schema.Fields[idx]
	if seg.hasIndex {
		if !fs.Repeated {
			return ErrFieldNotFound
		}
		arr, ok := m.fields[fs.Name]
		if !ok {
			return ErrIndexOutOfRange
		}
		if seg.index < 0 || seg.index >= sliceLen(arr) {
			return ErrIndexOutOfRange
		}
		if isClearValue(value) {
			if fs.Type == FieldMessage {
				setSliceIndex(arr, seg.index, (*Message)(nil))
			} else {
				setSliceIndex(arr, seg.index, zeroValueForType(fs.Type))
			}
			return nil
		}
		elemVal, err := convertElement(fs, value)
		if err != nil {
			return err
		}
		setSliceIndex(arr, seg.index, elemVal)
		return nil
	}
	if isClearValue(value) {
		delete(m.fields, fs.Name)
		return nil
	}
	val, err := convertFieldValue(fs, value)
	if err != nil {
		return err
	}
	m.fields[fs.Name] = val
	return nil
}

// Append appends a single element to the repeated field addressed by path.
// If the repeated field is unset, an empty array is created first.
func (m *Message) Append(path string, value any) error {
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return ErrTypeMismatch
	}
	parent, lastSeg, err := m.navigate(segs)
	if err != nil {
		return err
	}
	if lastSeg.hasIndex {
		return ErrFieldNotFound
	}
	idx, ok := parent.schema.byName[lastSeg.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := &parent.schema.Fields[idx]
	if !fs.Repeated {
		return ErrTypeMismatch
	}
	elemVal, err := convertElement(fs, value)
	if err != nil {
		return err
	}
	arr, ok := parent.fields[fs.Name]
	if !ok {
		arr = makeEmptySlice(fs)
		parent.fields[fs.Name] = arr
	}
	parent.fields[fs.Name] = appendToSlice(arr, elemVal)
	return nil
}

// navigateNoCreate walks to the parent of the target field without creating
// intermediate messages.  It reports ok=false (with nil error) when the target
// is already unset, in which case a Clear is a no-op.
func (m *Message) navigateNoCreate(segs []pathSeg) (parent *Message, last *pathSeg, ok bool, err error) {
	cur := m
	for i := 0; i < len(segs)-1; i++ {
		seg := segs[i]
		idx, found := cur.schema.byName[seg.name]
		if !found {
			return nil, nil, false, ErrFieldNotFound
		}
		fs := &cur.schema.Fields[idx]
		if seg.hasIndex {
			if !fs.Repeated {
				return nil, nil, false, ErrFieldNotFound
			}
			arr, exists := cur.fields[fs.Name]
			if !exists {
				return nil, nil, false, nil
			}
			if seg.index < 0 || seg.index >= sliceLen(arr) {
				return nil, nil, false, ErrIndexOutOfRange
			}
			if fs.Type != FieldMessage {
				return nil, nil, false, ErrFieldNotFound
			}
			msg, _ := sliceIndex(arr, seg.index).(*Message)
			if msg == nil {
				return nil, nil, false, nil
			}
			cur = msg
		} else {
			if fs.Type != FieldMessage || fs.Repeated {
				return nil, nil, false, ErrFieldNotFound
			}
			val, exists := cur.fields[fs.Name]
			if !exists || val == nil {
				return nil, nil, false, nil
			}
			cur = val.(*Message)
		}
	}
	return cur, &segs[len(segs)-1], true, nil
}

// Clear sets the field addressed by path to unset.  Clear("") clears every
// field of the message.  Clearing an already-unset field is idempotent.
func (m *Message) Clear(path string) error {
	if path == "" {
		m.fields = make(map[string]any)
		return nil
	}
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return ErrFieldNotFound
	}
	parent, lastSeg, ok, err := m.navigateNoCreate(segs)
	if err != nil {
		return err
	}
	if !ok {
		// Target is already unset; clearing is a no-op.
		return nil
	}
	idx, ok := parent.schema.byName[lastSeg.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := &parent.schema.Fields[idx]
	if lastSeg.hasIndex {
		if !fs.Repeated {
			return ErrFieldNotFound
		}
		arr, ok := parent.fields[fs.Name]
		if !ok {
			// Field already unset; clearing an element is a no-op.
			return nil
		}
		if lastSeg.index < 0 || lastSeg.index >= sliceLen(arr) {
			return ErrIndexOutOfRange
		}
		if fs.Type == FieldMessage {
			setSliceIndex(arr, lastSeg.index, (*Message)(nil))
		} else {
			setSliceIndex(arr, lastSeg.index, zeroValueForType(fs.Type))
		}
		return nil
	}
	delete(parent.fields, fs.Name)
	return nil
}

// Has reports whether the field addressed by path exists and is set.
func (m *Message) Has(path string) bool {
	v := m.Get(path)
	return v.Exists() && v.IsSet()
}

// SetFields returns the names of all currently-set fields, in schema
// declaration order.
func (m *Message) SetFields() []string {
	out := make([]string, 0, len(m.schema.Fields))
	for i := range m.schema.Fields {
		fs := &m.schema.Fields[i]
		v, ok := m.fields[fs.Name]
		if !ok {
			continue
		}
		if fs.Type == FieldMessage && !fs.Repeated && v == nil {
			continue
		}
		out = append(out, fs.Name)
	}
	return out
}
