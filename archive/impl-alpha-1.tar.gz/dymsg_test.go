package dymsg

import (
	"bytes"
	"errors"
	"math"
	"reflect"
	"testing"
)

const testConfig = `{
  "types": [
    {
      "typeId": 1001,
      "fields": [
        { "name": "name", "type": "string", "num": 1 },
        { "name": "age", "type": "int32", "num": 2 },
        {
          "name": "addr",
          "type": "message",
          "num": 3,
          "schema": {
            "fields": [
              { "name": "city", "type": "string", "num": 1 },
              { "name": "zip", "type": "string", "num": 2 }
            ]
          }
        },
        { "name": "tags", "type": "string", "num": 4, "repeated": true },
        { "name": "scores", "type": "double", "num": 5, "repeated": true },
        { "name": "data", "type": "bytes", "num": 6 }
      ]
    }
  ]
}`

func mustRegister(t *testing.T) {
	t.Helper()
	schemas, err := ParseSchema([]byte(testConfig))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	for _, s := range schemas {
		if err := Register(s); err != nil {
			t.Fatalf("Register: %v", err)
		}
	}
}

func mustNew(t *testing.T) *Message {
	t.Helper()
	m, err := New(1001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	return m
}

func TestParseRegisterNew(t *testing.T) {
	mustRegister(t)
	m, err := New(1001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if m == nil {
		t.Fatal("nil message")
	}
}

func TestDuplicateRegisterIdempotent(t *testing.T) {
	schemas, err := ParseSchema([]byte(testConfig))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	// First register.
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register first: %v", err)
	}
	// Same content again: idempotent.
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register second (idempotent): %v", err)
	}
	// Different content for same typeID.
	diff := `{"types":[{"typeId":1001,"fields":[{"name":"other","type":"string","num":1}]}]}`
	schemas2, err := ParseSchema([]byte(diff))
	if err != nil {
		t.Fatalf("ParseSchema diff: %v", err)
	}
	if err := Register(schemas2[0]); !errors.Is(err, ErrDuplicateID) {
		t.Fatalf("expected ErrDuplicateID, got %v", err)
	}
}

func TestUnknownTypeID(t *testing.T) {
	if _, err := New(999); !errors.Is(err, ErrUnknownTypeID) {
		t.Fatalf("expected ErrUnknownTypeID, got %v", err)
	}
}

func TestSetGetScalar(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatalf("Set name: %v", err)
	}
	if got := m.Get("name").String(); got != "alice" {
		t.Fatalf("Get name = %q, want alice", got)
	}
	if err := m.Set("age", int32(30)); err != nil {
		t.Fatalf("Set age: %v", err)
	}
	if got := m.Get("age").Int32(); got != 30 {
		t.Fatalf("Get age = %d, want 30", got)
	}
	if !m.Has("name") || !m.Has("age") {
		t.Fatal("Has should be true")
	}
	if m.Has("addr") {
		t.Fatal("Has addr should be false")
	}
}

func TestSetGetNested(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatalf("Set addr.city: %v", err)
	}
	if got := m.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("Get addr.city = %q, want beijing", got)
	}
	if !m.Has("addr.city") {
		t.Fatal("Has addr.city should be true")
	}
	// addr itself should now be set.
	if !m.Has("addr") {
		t.Fatal("Has addr should be true after setting child")
	}
	if v := m.Get("addr"); v.Message() == nil {
		t.Fatal("Get addr should return a message")
	}
}

func TestAutoCreateNested(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("addr.zip", "100000"); err != nil {
		t.Fatalf("Set addr.zip: %v", err)
	}
	if got := m.Get("addr.zip").String(); got != "100000" {
		t.Fatalf("Get addr.zip = %q", got)
	}
	// city should be unset but exist.
	v := m.Get("addr.city")
	if !v.Exists() {
		t.Fatal("addr.city should exist")
	}
	if v.IsSet() {
		t.Fatal("addr.city should not be set")
	}
}

func TestUnsetNestedGet(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	v := m.Get("addr.city")
	if !v.Exists() {
		t.Fatal("addr.city should exist in schema")
	}
	if v.IsSet() {
		t.Fatal("addr.city should be unset")
	}
	if v.Err() != nil {
		t.Fatalf("addr.city Err should be nil, got %v", v.Err())
	}
}

func TestRepeatedAppendGet(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Append("tags", "a"); err != nil {
		t.Fatalf("Append a: %v", err)
	}
	if err := m.Append("tags", "b"); err != nil {
		t.Fatalf("Append b: %v", err)
	}
	v := m.Get("tags")
	if v.Len() != 2 {
		t.Fatalf("tags Len = %d, want 2", v.Len())
	}
	if got := v.Index(0).String(); got != "a" {
		t.Fatalf("tags[0] = %q, want a", got)
	}
	if got := v.Index(1).String(); got != "b" {
		t.Fatalf("tags[1] = %q, want b", got)
	}
	if got := v.Strings(); !reflect.DeepEqual(got, []string{"a", "b"}) {
		t.Fatalf("Strings = %v, want [a b]", got)
	}
}

func TestRepeatedSetSlice(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("tags", []string{"x", "y"}); err != nil {
		t.Fatalf("Set tags: %v", err)
	}
	if got := m.Get("tags").Strings(); !reflect.DeepEqual(got, []string{"x", "y"}) {
		t.Fatalf("tags = %v", got)
	}
}

func TestRepeatedIndexSet(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Append("tags", "a"); err != nil {
		t.Fatalf("Append: %v", err)
	}
	if err := m.Set("tags[0]", "z"); err != nil {
		t.Fatalf("Set tags[0]: %v", err)
	}
	if got := m.Get("tags").Index(0).String(); got != "z" {
		t.Fatalf("tags[0] = %q, want z", got)
	}
}

func TestAppendToUnsetField(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Append("tags", "first"); err != nil {
		t.Fatalf("Append: %v", err)
	}
	if v := m.Get("tags"); !v.IsSet() || v.Len() != 1 {
		t.Fatalf("tags set=%v len=%d, want true 1", v.IsSet(), v.Len())
	}
}

func TestClear(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatalf("Set: %v", err)
	}
	if err := m.Clear("name"); err != nil {
		t.Fatalf("Clear name: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared")
	}
	// Idempotent clear.
	if err := m.Clear("name"); err != nil {
		t.Fatalf("Clear name again: %v", err)
	}
	// Clear unknown.
	if err := m.Clear("unknown"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("expected ErrFieldNotFound, got %v", err)
	}
	// Clear all.
	if err := m.Set("name", "bob"); err != nil {
		t.Fatalf("Set: %v", err)
	}
	if err := m.Clear(""); err != nil {
		t.Fatalf("Clear all: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields after clear = %v, want empty", m.SetFields())
	}
}

func TestSetNilClears(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatalf("Set: %v", err)
	}
	if err := m.Set("name", nil); err != nil {
		t.Fatalf("Set nil: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared by Set nil")
	}
}

func TestSetFieldsOrder(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("age", int32(1))
	m.Set("name", "x")
	m.Append("tags", "a")
	got := m.SetFields()
	want := []string{"name", "age", "tags"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("SetFields = %v, want %v", got, want)
	}
}

func TestValueStates(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Unset field.
	v := m.Get("name")
	if !v.Exists() || v.IsSet() || v.Err() != nil {
		t.Fatalf("unset name: exists=%v isSet=%v err=%v", v.Exists(), v.IsSet(), v.Err())
	}
	if v.String() != "" {
		t.Fatalf("unset name String = %q", v.String())
	}
	// Non-existent field.
	v = m.Get("unknown")
	if v.Exists() || !errors.Is(v.Err(), ErrFieldNotFound) {
		t.Fatalf("unknown: exists=%v err=%v", v.Exists(), v.Err())
	}
	// Type mismatch getter returns zero.
	m.Set("age", int32(5))
	v = m.Get("age")
	if v.String() != "" {
		t.Fatalf("age as String should be zero, got %q", v.String())
	}
}

func TestIndexErrors(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Negative index.
	v := m.Get("tags[-1]")
	if !errors.Is(v.Err(), ErrIndexOutOfRange) {
		t.Fatalf("tags[-1] err = %v, want ErrIndexOutOfRange", v.Err())
	}
	// Non-numeric.
	v = m.Get("tags[abc]")
	if !errors.Is(v.Err(), ErrIndexOutOfRange) {
		t.Fatalf("tags[abc] err = %v", v.Err())
	}
	// Empty.
	v = m.Get("tags[]")
	if !errors.Is(v.Err(), ErrIndexOutOfRange) {
		t.Fatalf("tags[] err = %v", v.Err())
	}
	// Index on non-repeated.
	v = m.Get("name[0]")
	if !errors.Is(v.Err(), ErrFieldNotFound) {
		t.Fatalf("name[0] err = %v, want ErrFieldNotFound", v.Err())
	}
	// Drill into scalar.
	v = m.Get("name.x")
	if !errors.Is(v.Err(), ErrFieldNotFound) {
		t.Fatalf("name.x err = %v", v.Err())
	}
	// Out of range.
	m.Append("tags", "a")
	v = m.Get("tags[5]")
	if !errors.Is(v.Err(), ErrIndexOutOfRange) {
		t.Fatalf("tags[5] err = %v", v.Err())
	}
}

func TestSetIndexErrors(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Set index on unset array.
	if err := m.Set("tags[0]", "x"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Set tags[0] unset: %v", err)
	}
	// Set index on non-repeated.
	if err := m.Set("name[0]", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set name[0]: %v", err)
	}
	// Append to non-repeated.
	if err := m.Append("name", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append name: %v", err)
	}
	// Append to unknown.
	if err := m.Append("unknown", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Append unknown: %v", err)
	}
	// Set unknown.
	if err := m.Set("unknown", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set unknown: %v", err)
	}
}

func TestTypeConversion(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// string -> int32
	if err := m.Set("age", "42"); err != nil {
		t.Fatalf("Set age string: %v", err)
	}
	if got := m.Get("age").Int32(); got != 42 {
		t.Fatalf("age = %d, want 42", got)
	}
	// float -> int32 (truncation)
	if err := m.Set("age", 3.99); err != nil {
		t.Fatalf("Set age float: %v", err)
	}
	if got := m.Get("age").Int32(); got != 3 {
		t.Fatalf("age = %d, want 3", got)
	}
	// overflow
	if err := m.Set("age", int64(1<<40)); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set age overflow: %v", err)
	}
	// int -> string
	if err := m.Set("name", 123); err != nil {
		t.Fatalf("Set name int: %v", err)
	}
	if got := m.Get("name").String(); got != "123" {
		t.Fatalf("name = %q, want 123", got)
	}
	// []byte -> string
	if err := m.Set("name", []byte("hello")); err != nil {
		t.Fatalf("Set name bytes: %v", err)
	}
	if got := m.Get("name").String(); got != "hello" {
		t.Fatalf("name = %q, want hello", got)
	}
	// string -> bytes
	if err := m.Set("data", "raw"); err != nil {
		t.Fatalf("Set data string: %v", err)
	}
	if got := string(m.Get("data").Bytes()); got != "raw" {
		t.Fatalf("data = %q, want raw", got)
	}
}

func TestDeepCopyWhole(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")

	m2 := mustNew(t)
	if err := m2.Set("", m); err != nil {
		t.Fatalf("Set whole: %v", err)
	}
	// Modify source.
	m.Set("name", "bob")
	m.Get("addr").Message().Set("city", "shanghai")
	m.Append("tags", "b")

	if got := m2.Get("name").String(); got != "alice" {
		t.Fatalf("m2 name = %q, want alice (deep copy)", got)
	}
	if got := m2.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("m2 addr.city = %q, want beijing", got)
	}
	if got := m2.Get("tags").Len(); got != 1 {
		t.Fatalf("m2 tags len = %d, want 1", got)
	}
}

func TestDeepCopyNested(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("addr.city", "beijing")
	addr := m.Get("addr").Message()

	m2 := mustNew(t)
	if err := m2.Set("addr", addr); err != nil {
		t.Fatalf("Set addr: %v", err)
	}
	addr.Set("city", "shanghai")
	if got := m2.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("m2 addr.city = %q, want beijing (deep copy)", got)
	}
}

func TestJSONRoundTrip(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", int32(30))
	m.Set("addr.city", "beijing")
	m.Set("addr.zip", "100000")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Set("scores", []float64{1.5, 2.5})
	m.Set("data", []byte{0x01, 0x02})

	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}

	m2 := mustNew(t)
	if err := m2.DecodeJSON(data); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}

	if got := m2.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q", got)
	}
	if got := m2.Get("age").Int32(); got != 30 {
		t.Fatalf("age = %d", got)
	}
	if got := m2.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("addr.city = %q", got)
	}
	if got := m2.Get("tags").Strings(); !reflect.DeepEqual(got, []string{"a", "b"}) {
		t.Fatalf("tags = %v", got)
	}
	if got := m2.Get("scores").Float64s(); !reflect.DeepEqual(got, []float64{1.5, 2.5}) {
		t.Fatalf("scores = %v", got)
	}
	if got := m2.Get("data").Bytes(); !bytes.Equal(got, []byte{0x01, 0x02}) {
		t.Fatalf("data = %v", got)
	}
}

func TestJSONFieldOrder(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("age", int32(1))
	m.Set("name", "x")
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	// Check ordering manually: "name" must appear before "age".
	idxName := bytes.Index(data, []byte(`"name"`))
	idxAge := bytes.Index(data, []byte(`"age"`))
	if idxName < 0 || idxAge < 0 || idxName > idxAge {
		t.Fatalf("unexpected key order in %s", data)
	}
}

func TestJSONNullHandling(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	if err := m.DecodeJSON([]byte(`{"name":null}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be unset after null")
	}
	// Top-level null clears.
	m.Set("name", "bob")
	if err := m.DecodeJSON([]byte(`null`)); err != nil {
		t.Fatalf("DecodeJSON null: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields = %v, want empty", m.SetFields())
	}
}

func TestJSONErrors(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.DecodeJSON([]byte(``)); !errors.Is(err, ErrTruncated) {
		t.Fatalf("empty input err = %v, want ErrTruncated", err)
	}
	if err := m.DecodeJSON([]byte(`[]`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("array top-level err = %v", err)
	}
	if err := m.DecodeJSON([]byte(`"x"`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("string top-level err = %v", err)
	}
	if err := m.DecodeJSON([]byte(`123`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("number top-level err = %v", err)
	}
	// Wrong type.
	if err := m.DecodeJSON([]byte(`{"age":"18"}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("age string err = %v", err)
	}
	// Overflow.
	if err := m.DecodeJSON([]byte(`{"age":2147483648}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("age overflow err = %v", err)
	}
	// Null in scalar repeated.
	if err := m.DecodeJSON([]byte(`{"scores":[1,null]}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("scores null err = %v", err)
	}
}

func TestJSONUnknownKeys(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.DecodeJSON([]byte(`{"unknown":1,"name":"x"}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if got := m.Get("name").String(); got != "x" {
		t.Fatalf("name = %q", got)
	}
}

func TestProtoRoundTrip(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", int32(-30)) // negative int32
	m.Set("addr.city", "beijing")
	m.Set("addr.zip", "100000")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Set("scores", []float64{1.5, 2.5})
	m.Set("data", []byte{0x01, 0x02})

	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}

	m2 := mustNew(t)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}

	if got := m2.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q", got)
	}
	if got := m2.Get("age").Int32(); got != -30 {
		t.Fatalf("age = %d, want -30", got)
	}
	if got := m2.Get("addr.city").String(); got != "beijing" {
		t.Fatalf("addr.city = %q", got)
	}
	if got := m2.Get("tags").Strings(); !reflect.DeepEqual(got, []string{"a", "b"}) {
		t.Fatalf("tags = %v", got)
	}
	if got := m2.Get("scores").Float64s(); !reflect.DeepEqual(got, []float64{1.5, 2.5}) {
		t.Fatalf("scores = %v", got)
	}
	if got := m2.Get("data").Bytes(); !bytes.Equal(got, []byte{0x01, 0x02}) {
		t.Fatalf("data = %v", got)
	}
}

func TestProtoEmptyInput(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	if err := m.DecodeProto([]byte{}); err != nil {
		t.Fatalf("DecodeProto empty: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields = %v, want empty", m.SetFields())
	}
}

func TestProtoPackedAndUnpacked(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Packed encoding.
	if err := m.Set("scores", []float64{1.0, 2.0}); err != nil {
		t.Fatalf("Set scores: %v", err)
	}
	data, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2 := mustNew(t)
	if err := m2.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto packed: %v", err)
	}
	if got := m2.Get("scores").Float64s(); !reflect.DeepEqual(got, []float64{1.0, 2.0}) {
		t.Fatalf("scores = %v", got)
	}

	// Manually build unpacked encoding: field 5, wire type 1 (fixed64) for each.
	var buf []byte
	for _, v := range []float64{3.0, 4.0} {
		buf = appendVarint(buf, uint64(5<<3)|1)
		bits := math.Float64bits(v)
		for i := 0; i < 8; i++ {
			buf = append(buf, byte(bits>>(8*i)))
		}
	}
	m3 := mustNew(t)
	if err := m3.DecodeProto(buf); err != nil {
		t.Fatalf("DecodeProto unpacked: %v", err)
	}
	if got := m3.Get("scores").Float64s(); !reflect.DeepEqual(got, []float64{3.0, 4.0}) {
		t.Fatalf("unpacked scores = %v", got)
	}
}

func TestProtoUnknownFieldSkip(t *testing.T) {
	mustRegister(t)
	// Encode with an unknown field 99 (varint), then known field 1.
	var buf []byte
	buf = appendVarint(buf, uint64(99<<3)|0)
	buf = appendVarint(buf, 123)
	buf = appendVarint(buf, uint64(1<<3)|2)
	buf = appendVarint(buf, uint64(5))
	buf = append(buf, "alice"...)
	m := mustNew(t)
	if err := m.DecodeProto(buf); err != nil {
		t.Fatalf("DecodeProto with unknown field: %v", err)
	}
	if got := m.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q, want alice", got)
	}
}

func TestProtoErrors(t *testing.T) {
	mustRegister(t)
	m := mustNew(t)
	// Field number 0.
	if err := m.DecodeProto([]byte{0x00}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("field 0 err = %v", err)
	}
	// Invalid wire type 6.
	if err := m.DecodeProto([]byte{0x3e}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire type 6 err = %v", err)
	}
	// Wire type mismatch for known field: field 1 is string (wire 2), but use varint.
	if err := m.DecodeProto([]byte{0x08}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire mismatch err = %v", err)
	}
	// Truncated.
	if err := m.DecodeProto([]byte{0x0a, 0x05, 'a'}); !errors.Is(err, ErrTruncated) {
		t.Fatalf("truncated err = %v", err)
	}
}

func TestJSONRepeatedMessageNilElements(t *testing.T) {
	cfg := `{"types":[{"typeId":2001,"fields":[
		{"name":"contacts","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"name","type":"string","num":1}
		]}}
	]}]}`
	schemas, err := ParseSchema([]byte(cfg))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, err := New(2001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if err := m.DecodeJSON([]byte(`{"contacts":[null,{"name":"bob"}]}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 2 {
		t.Fatalf("contacts len = %d, want 2", v.Len())
	}
	if v.Index(0).IsSet() {
		t.Fatal("contacts[0] should be unset (nil)")
	}
	if v.Index(0).Message() != nil {
		t.Fatal("contacts[0] Message should be nil")
	}
	if got := v.Index(1).Message().Get("name").String(); got != "bob" {
		t.Fatalf("contacts[1].name = %q", got)
	}
}

func TestProtoRepeatedMessageNilElements(t *testing.T) {
	cfg := `{"types":[{"typeId":2002,"fields":[
		{"name":"contacts","type":"message","num":1,"repeated":true,"schema":{"fields":[
			{"name":"name","type":"string","num":1}
		]}}
	]}]}`
	schemas, err := ParseSchema([]byte(cfg))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, err := New(2002)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	// Append nil and one real message.
	if err := m.Append("contacts", nil); err != nil {
		t.Fatalf("Append nil: %v", err)
	}
	// Use a fresh message and set the contacts field directly.
	m2, _ := New(2002)
	msg := mustNewForSchema(t, &schemas[0].Fields[0].Schema)
	msg.Set("name", "alice")
	if err := m2.Set("contacts", []*Message{nil, msg}); err != nil {
		t.Fatalf("Set contacts: %v", err)
	}
	data, err := m2.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m3, _ := New(2002)
	if err := m3.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	v := m3.Get("contacts")
	if v.Len() != 1 {
		t.Fatalf("contacts len = %d, want 1 (nil element skipped)", v.Len())
	}
	if got := v.Index(0).Message().Get("name").String(); got != "alice" {
		t.Fatalf("contacts[0].name = %q", got)
	}
}

// mustNewForSchema creates an empty Message referencing the given schema.
func mustNewForSchema(t *testing.T, s *MessageSchema) *Message {
	t.Helper()
	return &Message{schema: s, fields: make(map[string]any)}
}
