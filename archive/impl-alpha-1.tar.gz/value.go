package dymsg

import "reflect"

// Get resolves the field path and returns a Value.  It never returns an error
// directly; errors are carried by Value.Err().
func (m *Message) Get(path string) Value {
	if path == "" {
		return Value{exists: true, isSet: true, val: m}
	}
	segs, err := parsePath(path)
	if err != nil {
		return Value{err: err}
	}
	res, err := m.resolve(segs)
	if err != nil {
		return Value{err: err}
	}
	return Value{exists: true, isSet: res.set, val: res.val}
}

// resolvedValue is the outcome of resolving a path against a message.
type resolvedValue struct {
	val any
	set bool
}

// resolve walks the parsed path segments and returns the final value along
// with its presence state.
func (m *Message) resolve(segs []pathSeg) (resolvedValue, error) {
	if len(segs) == 0 {
		return resolvedValue{val: m, set: true}, nil
	}
	var curSchema *MessageSchema = m.schema
	var curFields map[string]any = m.fields

	for i, seg := range segs {
		if curSchema == nil {
			return resolvedValue{}, ErrFieldNotFound
		}
		idx, ok := curSchema.byName[seg.name]
		if !ok {
			return resolvedValue{}, ErrFieldNotFound
		}
		fs := &curSchema.Fields[idx]
		last := i == len(segs)-1

		if seg.hasIndex {
			if !fs.Repeated {
				return resolvedValue{}, ErrFieldNotFound
			}
			if curFields == nil {
				return resolvedValue{}, ErrIndexOutOfRange
			}
			arr, ok := curFields[fs.Name]
			if !ok {
				return resolvedValue{}, ErrIndexOutOfRange
			}
			if seg.index < 0 || seg.index >= sliceLen(arr) {
				return resolvedValue{}, ErrIndexOutOfRange
			}
			elem := sliceIndex(arr, seg.index)
			if last {
				set := true
				if fs.Type == FieldMessage {
					if msg, ok := elem.(*Message); !ok || msg == nil {
						set = false
					}
				}
				return resolvedValue{val: elem, set: set}, nil
			}
			// Drill into the element: it must be a message.
			if fs.Type != FieldMessage {
				return resolvedValue{}, ErrFieldNotFound
			}
			msg, ok := elem.(*Message)
			if !ok {
				return resolvedValue{}, ErrFieldNotFound
			}
			if msg == nil {
				curSchema = &fs.Schema
				curFields = nil
			} else {
				curSchema = msg.schema
				curFields = msg.fields
			}
		} else {
			if last {
				var val any
				set := false
				if curFields != nil {
					if v, ok := curFields[fs.Name]; ok {
						val = v
						set = true
						if fs.Type == FieldMessage && !fs.Repeated && v == nil {
							set = false
							val = nil
						}
					}
				}
				return resolvedValue{val: val, set: set}, nil
			}
			// Drill into a message field.
			if fs.Type != FieldMessage || fs.Repeated {
				return resolvedValue{}, ErrFieldNotFound
			}
			var child *Message
			if curFields != nil {
				if v, ok := curFields[fs.Name]; ok && v != nil {
					child = v.(*Message)
				}
			}
			if child == nil {
				curSchema = &fs.Schema
				curFields = nil
			} else {
				curSchema = child.schema
				curFields = child.fields
			}
		}
	}
	return resolvedValue{}, ErrFieldNotFound
}

// sliceLen returns the length of a slice value.
func sliceLen(arr any) int {
	return reflect.ValueOf(arr).Len()
}

// sliceIndex returns the i-th element of a slice value.
func sliceIndex(arr any, i int) any {
	return reflect.ValueOf(arr).Index(i).Interface()
}
