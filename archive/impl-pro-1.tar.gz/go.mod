module dymsg

go 1.24.4
