package dymsg

import (
	"encoding/binary"
	"math"
)

const (
	wireVarint  = 0
	wireFixed64 = 1
	wireBytes   = 2
	wireFixed32 = 5
)

func appendVarint(buf []byte, v uint64) []byte {
	for v >= 0x80 {
		buf = append(buf, byte(v)|0x80)
		v >>= 7
	}
	return append(buf, byte(v))
}

func appendTag(buf []byte, num int, wire int) []byte {
	return appendVarint(buf, uint64(num)<<3|uint64(wire))
}

func appendFixed32(buf []byte, v uint32) []byte {
	var tmp [4]byte
	binary.LittleEndian.PutUint32(tmp[:], v)
	return append(buf, tmp[:]...)
}

func appendFixed64(buf []byte, v uint64) []byte {
	var tmp [8]byte
	binary.LittleEndian.PutUint64(tmp[:], v)
	return append(buf, tmp[:]...)
}

// EncodeProto encodes the message using a self-contained Protobuf wire-format
// subset.
func (m *Message) EncodeProto() ([]byte, error) {
	buf := make([]byte, 0, 64)
	return encodeProtoMessage(buf, m), nil
}

func encodeProtoMessage(buf []byte, m *Message) []byte {
	for i := range m.fields {
		if !m.fields[i].set {
			continue
		}
		fs := &m.schema.Fields[i]
		val := m.fields[i].val
		if fs.Repeated {
			buf = encodeProtoRepeated(buf, fs, val)
		} else {
			buf = encodeProtoSingle(buf, fs, val)
		}
	}
	return buf
}

func encodeProtoRepeated(buf []byte, fs *FieldSchema, val any) []byte {
	if isPackedScalar(fs.Type) {
		payload := encodePackedPayload(fs.Type, val)
		buf = appendTag(buf, fs.Num, wireBytes)
		buf = appendVarint(buf, uint64(len(payload)))
		return append(buf, payload...)
	}

	switch fs.Type {
	case FieldString:
		arr := val.([]string)
		for _, s := range arr {
			buf = appendTag(buf, fs.Num, wireBytes)
			buf = appendVarint(buf, uint64(len(s)))
			buf = append(buf, s...)
		}
	case FieldBytes:
		arr := val.([][]byte)
		for _, b := range arr {
			buf = appendTag(buf, fs.Num, wireBytes)
			buf = appendVarint(buf, uint64(len(b)))
			buf = append(buf, b...)
		}
	case FieldMessage:
		arr := val.([]*Message)
		for _, msg := range arr {
			if msg == nil {
				continue
			}
			inner := encodeProtoMessage(nil, msg)
			buf = appendTag(buf, fs.Num, wireBytes)
			buf = appendVarint(buf, uint64(len(inner)))
			buf = append(buf, inner...)
		}
	}
	return buf
}

func encodeProtoSingle(buf []byte, fs *FieldSchema, val any) []byte {
	switch fs.Type {
	case FieldInt32:
		buf = appendTag(buf, fs.Num, wireVarint)
		buf = appendVarint(buf, uint64(int64(val.(int32))))
	case FieldInt64:
		buf = appendTag(buf, fs.Num, wireVarint)
		buf = appendVarint(buf, uint64(val.(int64)))
	case FieldUint32:
		buf = appendTag(buf, fs.Num, wireVarint)
		buf = appendVarint(buf, uint64(val.(uint32)))
	case FieldUint64:
		buf = appendTag(buf, fs.Num, wireVarint)
		buf = appendVarint(buf, val.(uint64))
	case FieldBool:
		buf = appendTag(buf, fs.Num, wireVarint)
		if val.(bool) {
			buf = appendVarint(buf, 1)
		} else {
			buf = appendVarint(buf, 0)
		}
	case FieldFloat:
		buf = appendTag(buf, fs.Num, wireFixed32)
		buf = appendFixed32(buf, math.Float32bits(val.(float32)))
	case FieldDouble:
		buf = appendTag(buf, fs.Num, wireFixed64)
		buf = appendFixed64(buf, math.Float64bits(val.(float64)))
	case FieldString:
		s := val.(string)
		buf = appendTag(buf, fs.Num, wireBytes)
		buf = appendVarint(buf, uint64(len(s)))
		buf = append(buf, s...)
	case FieldBytes:
		b := val.([]byte)
		buf = appendTag(buf, fs.Num, wireBytes)
		buf = appendVarint(buf, uint64(len(b)))
		buf = append(buf, b...)
	case FieldMessage:
		msg := val.(*Message)
		if msg == nil {
			return buf
		}
		inner := encodeProtoMessage(nil, msg)
		buf = appendTag(buf, fs.Num, wireBytes)
		buf = appendVarint(buf, uint64(len(inner)))
		buf = append(buf, inner...)
	}
	return buf
}

func encodePackedPayload(t FieldType, val any) []byte {
	buf := make([]byte, 0, 16)
	switch t {
	case FieldInt32:
		for _, v := range val.([]int32) {
			buf = appendVarint(buf, uint64(int64(v)))
		}
	case FieldInt64:
		for _, v := range val.([]int64) {
			buf = appendVarint(buf, uint64(v))
		}
	case FieldUint32:
		for _, v := range val.([]uint32) {
			buf = appendVarint(buf, uint64(v))
		}
	case FieldUint64:
		for _, v := range val.([]uint64) {
			buf = appendVarint(buf, v)
		}
	case FieldBool:
		for _, v := range val.([]bool) {
			if v {
				buf = appendVarint(buf, 1)
			} else {
				buf = appendVarint(buf, 0)
			}
		}
	case FieldFloat:
		for _, v := range val.([]float32) {
			buf = appendFixed32(buf, math.Float32bits(v))
		}
	case FieldDouble:
		for _, v := range val.([]float64) {
			buf = appendFixed64(buf, math.Float64bits(v))
		}
	}
	return buf
}

func isPackedScalar(t FieldType) bool {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool, FieldFloat, FieldDouble:
		return true
	default:
		return false
	}
}

func expectedWire(t FieldType) int {
	switch t {
	case FieldFloat:
		return wireFixed32
	case FieldDouble:
		return wireFixed64
	case FieldString, FieldBytes, FieldMessage:
		return wireBytes
	default:
		return wireVarint
	}
}

// DecodeProto replaces the message contents with values decoded from the
// Protobuf wire format. Unknown field numbers are skipped for compatibility.
// A zero-length input is a valid empty message.
func (m *Message) DecodeProto(data []byte) error {
	m.clearAll()
	if len(data) == 0 {
		return nil
	}

	pos := 0
	for pos < len(data) {
		tag, np, err := consumeVarint(data, pos)
		if err != nil {
			return err
		}
		pos = np
		num := int(tag >> 3)
		wire := int(tag & 7)
		if num == 0 {
			return ErrMalformedData
		}
		if wire != wireVarint && wire != wireFixed64 && wire != wireBytes && wire != wireFixed32 {
			return ErrMalformedData
		}

		idx, ok := m.schema.lookupNum(num)
		if !ok {
			np, err = skipProtoField(data, pos, wire)
			if err != nil {
				return err
			}
			pos = np
			continue
		}
		fs := &m.schema.Fields[idx]
		np, err = decodeKnownField(m, idx, fs, data, pos, wire)
		if err != nil {
			return err
		}
		pos = np
	}
	return nil
}

func decodeKnownField(m *Message, idx int, fs *FieldSchema, data []byte, pos int, wire int) (int, error) {
	if fs.Repeated && isPackedScalar(fs.Type) {
		if wire == wireBytes {
			length, np, err := consumeVarint(data, pos)
			if err != nil {
				return 0, err
			}
			if length > uint64(len(data)-np) {
				return 0, ErrTruncated
			}
			payload := data[np : np+int(length)]
			vals, err := parsePackedScalars(fs.Type, payload)
			if err != nil {
				return 0, err
			}
			protoAppendScalars(m, idx, fs, vals)
			return np + int(length), nil
		}
		if wire == expectedWire(fs.Type) {
			val, np, err := parseProtoScalar(fs.Type, data, pos, wire)
			if err != nil {
				return 0, err
			}
			protoAppendScalar(m, idx, fs, val)
			return np, nil
		}
		return 0, ErrMalformedData
	}

	if wire != expectedWire(fs.Type) {
		return 0, ErrMalformedData
	}
	if fs.Repeated {
		switch fs.Type {
		case FieldString:
			val, np, err := parseProtoString(data, pos)
			if err != nil {
				return 0, err
			}
			protoAppendString(m, idx, val)
			return np, nil
		case FieldBytes:
			val, np, err := parseProtoBytes(data, pos)
			if err != nil {
				return 0, err
			}
			protoAppendBytes(m, idx, val)
			return np, nil
		case FieldMessage:
			val, np, err := parseProtoMessage(&fs.Schema, data, pos)
			if err != nil {
				return 0, err
			}
			protoAppendMessage(m, idx, val)
			return np, nil
		}
		return 0, ErrMalformedData
	}

	switch fs.Type {
	case FieldMessage:
		val, np, err := parseProtoMessage(&fs.Schema, data, pos)
		if err != nil {
			return 0, err
		}
		m.fields[idx] = fieldVal{set: true, val: val}
		return np, nil
	case FieldString:
		val, np, err := parseProtoString(data, pos)
		if err != nil {
			return 0, err
		}
		m.fields[idx] = fieldVal{set: true, val: val}
		return np, nil
	case FieldBytes:
		val, np, err := parseProtoBytes(data, pos)
		if err != nil {
			return 0, err
		}
		m.fields[idx] = fieldVal{set: true, val: val}
		return np, nil
	default:
		val, np, err := parseProtoScalar(fs.Type, data, pos, wire)
		if err != nil {
			return 0, err
		}
		m.fields[idx] = fieldVal{set: true, val: val}
		return np, nil
	}
}

func parsePackedScalars(t FieldType, payload []byte) ([]any, error) {
	var vals []any
	pos := 0
	for pos < len(payload) {
		switch t {
		case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
			v, np, err := consumeVarint(payload, pos)
			if err != nil {
				if err == ErrTruncated {
					return nil, ErrTruncated
				}
				return nil, err
			}
			pos = np
			switch t {
			case FieldInt32:
				vals = append(vals, int32(v))
			case FieldInt64:
				vals = append(vals, int64(v))
			case FieldUint32:
				vals = append(vals, uint32(v))
			case FieldUint64:
				vals = append(vals, v)
			case FieldBool:
				vals = append(vals, v != 0)
			}
		case FieldFloat:
			if len(payload)-pos < 4 {
				return nil, ErrTruncated
			}
			vals = append(vals, math.Float32frombits(binary.LittleEndian.Uint32(payload[pos:pos+4])))
			pos += 4
		case FieldDouble:
			if len(payload)-pos < 8 {
				return nil, ErrTruncated
			}
			vals = append(vals, math.Float64frombits(binary.LittleEndian.Uint64(payload[pos:pos+8])))
			pos += 8
		default:
			return nil, ErrMalformedData
		}
	}
	return vals, nil
}

func protoAppendScalars(m *Message, idx int, fs *FieldSchema, vals []any) {
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: emptySliceFor(fs.Type)}
	}
	switch fs.Type {
	case FieldInt32:
		arr := m.fields[idx].val.([]int32)
		for _, v := range vals {
			arr = append(arr, v.(int32))
		}
		m.fields[idx].val = arr
	case FieldInt64:
		arr := m.fields[idx].val.([]int64)
		for _, v := range vals {
			arr = append(arr, v.(int64))
		}
		m.fields[idx].val = arr
	case FieldUint32:
		arr := m.fields[idx].val.([]uint32)
		for _, v := range vals {
			arr = append(arr, v.(uint32))
		}
		m.fields[idx].val = arr
	case FieldUint64:
		arr := m.fields[idx].val.([]uint64)
		for _, v := range vals {
			arr = append(arr, v.(uint64))
		}
		m.fields[idx].val = arr
	case FieldBool:
		arr := m.fields[idx].val.([]bool)
		for _, v := range vals {
			arr = append(arr, v.(bool))
		}
		m.fields[idx].val = arr
	case FieldFloat:
		arr := m.fields[idx].val.([]float32)
		for _, v := range vals {
			arr = append(arr, v.(float32))
		}
		m.fields[idx].val = arr
	case FieldDouble:
		arr := m.fields[idx].val.([]float64)
		for _, v := range vals {
			arr = append(arr, v.(float64))
		}
		m.fields[idx].val = arr
	}
}

func protoAppendScalar(m *Message, idx int, fs *FieldSchema, val any) {
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: emptySliceFor(fs.Type)}
	}
	switch fs.Type {
	case FieldInt32:
		m.fields[idx].val = append(m.fields[idx].val.([]int32), val.(int32))
	case FieldInt64:
		m.fields[idx].val = append(m.fields[idx].val.([]int64), val.(int64))
	case FieldUint32:
		m.fields[idx].val = append(m.fields[idx].val.([]uint32), val.(uint32))
	case FieldUint64:
		m.fields[idx].val = append(m.fields[idx].val.([]uint64), val.(uint64))
	case FieldBool:
		m.fields[idx].val = append(m.fields[idx].val.([]bool), val.(bool))
	case FieldFloat:
		m.fields[idx].val = append(m.fields[idx].val.([]float32), val.(float32))
	case FieldDouble:
		m.fields[idx].val = append(m.fields[idx].val.([]float64), val.(float64))
	}
}

func protoAppendString(m *Message, idx int, val string) {
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: []string{}}
	}
	m.fields[idx].val = append(m.fields[idx].val.([]string), val)
}

func protoAppendBytes(m *Message, idx int, val []byte) {
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: [][]byte{}}
	}
	m.fields[idx].val = append(m.fields[idx].val.([][]byte), val)
}

func protoAppendMessage(m *Message, idx int, val *Message) {
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: []*Message{}}
	}
	m.fields[idx].val = append(m.fields[idx].val.([]*Message), val)
}

func parseProtoScalar(t FieldType, data []byte, pos int, wire int) (any, int, error) {
	switch t {
	case FieldInt32:
		v, np, err := consumeVarint(data, pos)
		if err != nil {
			return nil, 0, err
		}
		return int32(v), np, nil
	case FieldInt64:
		v, np, err := consumeVarint(data, pos)
		if err != nil {
			return nil, 0, err
		}
		return int64(v), np, nil
	case FieldUint32:
		v, np, err := consumeVarint(data, pos)
		if err != nil {
			return nil, 0, err
		}
		return uint32(v), np, nil
	case FieldUint64:
		v, np, err := consumeVarint(data, pos)
		if err != nil {
			return nil, 0, err
		}
		return v, np, nil
	case FieldBool:
		v, np, err := consumeVarint(data, pos)
		if err != nil {
			return nil, 0, err
		}
		return v != 0, np, nil
	case FieldFloat:
		if len(data)-pos < 4 {
			return nil, 0, ErrTruncated
		}
		return math.Float32frombits(binary.LittleEndian.Uint32(data[pos : pos+4])), pos + 4, nil
	case FieldDouble:
		if len(data)-pos < 8 {
			return nil, 0, ErrTruncated
		}
		return math.Float64frombits(binary.LittleEndian.Uint64(data[pos : pos+8])), pos + 8, nil
	default:
		return nil, 0, ErrMalformedData
	}
}

func parseProtoString(data []byte, pos int) (string, int, error) {
	length, np, err := consumeVarint(data, pos)
	if err != nil {
		return "", 0, err
	}
	if length > uint64(len(data)-np) {
		return "", 0, ErrTruncated
	}
	n := int(length)
	return string(data[np : np+n]), np + n, nil
}

func parseProtoBytes(data []byte, pos int) ([]byte, int, error) {
	length, np, err := consumeVarint(data, pos)
	if err != nil {
		return nil, 0, err
	}
	if length > uint64(len(data)-np) {
		return nil, 0, ErrTruncated
	}
	n := int(length)
	out := make([]byte, n)
	copy(out, data[np:np+n])
	return out, np + n, nil
}

func parseProtoMessage(s *MessageSchema, data []byte, pos int) (*Message, int, error) {
	length, np, err := consumeVarint(data, pos)
	if err != nil {
		return nil, 0, err
	}
	if length > uint64(len(data)-np) {
		return nil, 0, ErrTruncated
	}
	n := int(length)
	nm := newMessage(s)
	if err := nm.DecodeProto(data[np : np+n]); err != nil {
		return nil, 0, err
	}
	return nm, np + n, nil
}

func skipProtoField(data []byte, pos int, wire int) (int, error) {
	switch wire {
	case wireVarint:
		_, np, err := consumeVarint(data, pos)
		return np, err
	case wireFixed64:
		if len(data)-pos < 8 {
			return 0, ErrTruncated
		}
		return pos + 8, nil
	case wireBytes:
		length, np, err := consumeVarint(data, pos)
		if err != nil {
			return 0, err
		}
		if length > uint64(len(data)-np) {
			return 0, ErrTruncated
		}
		return np + int(length), nil
	case wireFixed32:
		if len(data)-pos < 4 {
			return 0, ErrTruncated
		}
		return pos + 4, nil
	default:
		return 0, ErrMalformedData
	}
}

func consumeVarint(data []byte, pos int) (uint64, int, error) {
	var v uint64
	for i := 0; i < 10; i++ {
		if pos+i >= len(data) {
			return 0, pos, ErrTruncated
		}
		b := data[pos+i]
		if i == 9 {
			if b&0x80 != 0 {
				return 0, pos, ErrMalformedData
			}
			if b > 1 {
				return 0, pos, ErrMalformedData
			}
		}
		v |= uint64(b&0x7f) << (uint(i) * 7)
		if b&0x80 == 0 {
			return v, pos + i + 1, nil
		}
	}
	return 0, pos, ErrMalformedData
}
