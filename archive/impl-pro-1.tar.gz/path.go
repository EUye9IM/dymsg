package dymsg

import (
	"math"
	"strconv"
)

type pathComp struct {
	name    string
	indexed bool
	index   int
}

// parsePath splits a path expression into field/index components.
//
// The grammar is: path = "" | segment ("." segment)*
// segment = fieldName ("[" non-negative-decimal "]")?
func parsePath(path string) ([]pathComp, error) {
	if path == "" {
		return nil, nil
	}
	comps := make([]pathComp, 0, 4)
	for i := 0; i < len(path); {
		start := i
		for i < len(path) && path[i] != '.' && path[i] != '[' && path[i] != ']' {
			i++
		}
		name := path[start:i]
		if name == "" {
			return nil, ErrFieldNotFound
		}
		comp := pathComp{name: name}

		if i < len(path) && path[i] == '[' {
			i++
			if i >= len(path) {
				return nil, ErrFieldNotFound
			}
			if path[i] == ']' {
				return nil, ErrIndexOutOfRange
			}
			digitStart := i
			for i < len(path) && path[i] >= '0' && path[i] <= '9' {
				i++
			}
			if i == digitStart {
				return nil, ErrIndexOutOfRange
			}
			u, err := strconv.ParseUint(path[digitStart:i], 10, 64)
			if err != nil || u > uint64(maxInt()) {
				return nil, ErrIndexOutOfRange
			}
			comp.indexed = true
			comp.index = int(u)
			if i >= len(path) || path[i] != ']' {
				return nil, ErrFieldNotFound
			}
			i++
		}

		if i < len(path) {
			if path[i] != '.' {
				return nil, ErrFieldNotFound
			}
			i++
			if i >= len(path) {
				return nil, ErrFieldNotFound
			}
		}
		comps = append(comps, comp)
	}
	return comps, nil
}

func maxInt() int {
	if strconv.IntSize == 32 {
		return math.MaxInt32
	}
	return math.MaxInt64
}
