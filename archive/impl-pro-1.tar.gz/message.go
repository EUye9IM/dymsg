package dymsg

import (
	"reflect"
)

type fieldVal struct {
	set bool
	val any
}

// Message is a structured message instance with an associated schema.
// It is not safe for concurrent use; callers must serialize access to a given
// instance.
type Message struct {
	schema *MessageSchema
	fields []fieldVal
}

func newMessage(s *MessageSchema) *Message {
	return &Message{schema: s, fields: make([]fieldVal, len(s.Fields))}
}

func (m *Message) fieldIndexByName(name string) (int, *FieldSchema, bool) {
	i, ok := m.schema.lookupName(name)
	if !ok {
		return 0, nil, false
	}
	return i, &m.schema.Fields[i], true
}

// Get returns the value at path without returning a separate error; any error
// is embedded in Value.Err.
func (m *Message) Get(path string) Value {
	comps, err := parsePath(path)
	if err != nil {
		return valueErr(err)
	}
	if len(comps) == 0 {
		return selfValue(m)
	}

	cur := m
	sch := m.schema
	for i, comp := range comps {
		idx, ok := sch.lookupName(comp.name)
		if !ok {
			return valueErr(ErrFieldNotFound)
		}
		fs := &sch.Fields[idx]
		last := i == len(comps)-1

		if comp.indexed {
			if !fs.Repeated {
				return valueErr(ErrFieldNotFound)
			}
			if cur == nil || !cur.fields[idx].set {
				return valueErr(ErrIndexOutOfRange)
			}
			if comp.index < 0 || comp.index >= sliceLen(fs.Type, cur.fields[idx].val) {
				return valueErr(ErrIndexOutOfRange)
			}
			if last {
				return elementValue(fs, cur.fields[idx].val, comp.index)
			}
			if fs.Type != FieldMessage {
				return valueErr(ErrFieldNotFound)
			}
			elem := cur.fields[idx].val.([]*Message)[comp.index]
			if elem == nil {
				cur = nil
			} else {
				cur = elem
			}
			sch = &fs.Schema
			continue
		}

		if last {
			return fieldValue(cur, idx, fs)
		}
		if fs.Repeated {
			return valueErr(ErrFieldNotFound)
		}
		if fs.Type != FieldMessage {
			return valueErr(ErrFieldNotFound)
		}
		if cur == nil || !cur.fields[idx].set {
			cur = nil
		} else {
			cur = cur.fields[idx].val.(*Message)
			if cur == nil {
				cur = nil
			}
		}
		sch = &fs.Schema
	}
	// Unreachable for non-empty paths, but keeps the compiler happy.
	return valueErr(ErrFieldNotFound)
}

// Set writes value at path, deep-copying message values and slices.
func (m *Message) Set(path string, value any) error {
	if path == "" {
		if isNilValue(value) {
			m.clearAll()
			return nil
		}
		src, ok := value.(*Message)
		if !ok {
			return ErrTypeMismatch
		}
		if !schemaEqual(m.schema, src.schema) {
			return ErrTypeMismatch
		}
		if src == m {
			return nil
		}
		m.replaceFrom(src)
		return nil
	}

	comps, err := parsePath(path)
	if err != nil {
		return err
	}
	if isNilValue(value) {
		return m.clearComps(comps)
	}
	return m.setComps(comps, value)
}

// Append appends one element to the repeated field at path. If the repeated
// field is not set, an empty array is created first.
func (m *Message) Append(path string, value any) error {
	comps, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(comps) == 0 {
		return ErrTypeMismatch
	}
	cur := m
	sch := m.schema
	for i, comp := range comps {
		idx, ok := sch.lookupName(comp.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &sch.Fields[idx]
		last := i == len(comps)-1
		if comp.indexed {
			return ErrFieldNotFound
		}
		if last {
			if !fs.Repeated {
				return ErrTypeMismatch
			}
			return appendToField(cur, idx, fs, value)
		}
		if fs.Repeated || fs.Type != FieldMessage {
			return ErrFieldNotFound
		}
		if cur == nil || !cur.fields[idx].set {
			nm := newMessage(&fs.Schema)
			cur.fields[idx].set = true
			cur.fields[idx].val = nm
			cur = nm
		} else {
			nm := cur.fields[idx].val.(*Message)
			if nm == nil {
				nm = newMessage(&fs.Schema)
				cur.fields[idx].val = nm
			}
			cur = nm
		}
		sch = &fs.Schema
	}
	return nil
}

// Clear marks the field at path as unset. Clearing an already-unset field is
// a no-op. Clear("") clears the whole message.
func (m *Message) Clear(path string) error {
	if path == "" {
		m.clearAll()
		return nil
	}
	comps, err := parsePath(path)
	if err != nil {
		return err
	}
	return m.clearComps(comps)
}

// Has reports whether path exists and is set.
func (m *Message) Has(path string) bool {
	if path == "" {
		return true
	}
	comps, err := parsePath(path)
	if err != nil {
		return false
	}
	cur := m
	sch := m.schema
	for i, comp := range comps {
		idx, ok := sch.lookupName(comp.name)
		if !ok {
			return false
		}
		fs := &sch.Fields[idx]
		last := i == len(comps)-1
		if comp.indexed {
			if !fs.Repeated || cur == nil || !cur.fields[idx].set {
				return false
			}
			if comp.index < 0 || comp.index >= sliceLen(fs.Type, cur.fields[idx].val) {
				return false
			}
			if last {
				if fs.Type == FieldMessage {
					return cur.fields[idx].val.([]*Message)[comp.index] != nil
				}
				return true
			}
			if fs.Type != FieldMessage {
				return false
			}
			elem := cur.fields[idx].val.([]*Message)[comp.index]
			if elem == nil {
				return false
			}
			cur = elem
			sch = &fs.Schema
			continue
		}
		if last {
			return cur != nil && cur.fields[idx].set
		}
		if fs.Repeated || fs.Type != FieldMessage {
			return false
		}
		if cur == nil || !cur.fields[idx].set {
			return false
		}
		cur = cur.fields[idx].val.(*Message)
		if cur == nil {
			return false
		}
		sch = &fs.Schema
	}
	return false
}

// SetFields returns the names of currently-set fields in schema order.
func (m *Message) SetFields() []string {
	names := make([]string, 0, len(m.fields))
	for i, f := range m.fields {
		if f.set {
			names = append(names, m.schema.Fields[i].Name)
		}
	}
	return names
}

func (m *Message) clearAll() {
	for i := range m.fields {
		m.fields[i] = fieldVal{}
	}
}

func (m *Message) clearComps(comps []pathComp) error {
	if len(comps) == 0 {
		m.clearAll()
		return nil
	}
	cur := m
	sch := m.schema
	for i, comp := range comps {
		idx, ok := sch.lookupName(comp.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &sch.Fields[idx]
		last := i == len(comps)-1
		if comp.indexed {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if last {
				return ErrFieldNotFound
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			if cur == nil || !cur.fields[idx].set {
				cur = nil
				sch = &fs.Schema
				continue
			}
			if comp.index < 0 || comp.index >= sliceLen(fs.Type, cur.fields[idx].val) {
				return ErrIndexOutOfRange
			}
			elem := cur.fields[idx].val.([]*Message)[comp.index]
			if elem == nil {
				cur = nil
			} else {
				cur = elem
			}
			sch = &fs.Schema
			continue
		}
		if last {
			if cur != nil {
				cur.fields[idx] = fieldVal{}
			}
			return nil
		}
		if fs.Repeated || fs.Type != FieldMessage {
			return ErrFieldNotFound
		}
		if cur == nil || !cur.fields[idx].set {
			cur = nil
		} else {
			cur = cur.fields[idx].val.(*Message)
			if cur == nil {
				cur = nil
			}
		}
		sch = &fs.Schema
	}
	return nil
}

func (m *Message) setComps(comps []pathComp, value any) error {
	cur := m
	sch := m.schema
	for i, comp := range comps {
		idx, ok := sch.lookupName(comp.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &sch.Fields[idx]
		last := i == len(comps)-1

		if comp.indexed {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if cur == nil || !cur.fields[idx].set {
				return ErrIndexOutOfRange
			}
			if comp.index < 0 || comp.index >= sliceLen(fs.Type, cur.fields[idx].val) {
				return ErrIndexOutOfRange
			}
			if last {
				elem, err := convertElement(fs, value)
				if err != nil {
					return err
				}
				setSliceElem(cur.fields[idx].val, comp.index, elem, fs.Type)
				return nil
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			elem := cur.fields[idx].val.([]*Message)[comp.index]
			if elem == nil {
				return ErrFieldNotFound
			}
			cur = elem
			sch = &fs.Schema
			continue
		}

		if last {
			converted, err := convertFieldValue(fs, value)
			if err != nil {
				return err
			}
			cur.fields[idx] = fieldVal{set: true, val: converted}
			return nil
		}

		if fs.Repeated || fs.Type != FieldMessage {
			return ErrFieldNotFound
		}
		if cur == nil || !cur.fields[idx].set {
			nm := newMessage(&fs.Schema)
			cur.fields[idx] = fieldVal{set: true, val: nm}
			cur = nm
		} else {
			nm := cur.fields[idx].val.(*Message)
			if nm == nil {
				nm = newMessage(&fs.Schema)
				cur.fields[idx] = fieldVal{set: true, val: nm}
			}
			cur = nm
		}
		sch = &fs.Schema
	}
	return nil
}

func (m *Message) replaceFrom(src *Message) {
	m.clearAll()
	for i, f := range src.fields {
		if !f.set {
			continue
		}
		fs := &src.schema.Fields[i]
		m.fields[i].set = true
		if fs.Repeated {
			m.fields[i].val = cloneRepeated(fs.Type, f.val)
		} else if fs.Type == FieldMessage {
			m.fields[i].val = cloneMessage(f.val.(*Message))
		} else if fs.Type == FieldBytes {
			m.fields[i].val = cloneBytes(f.val.([]byte))
		} else {
			m.fields[i].val = f.val
		}
	}
}

func appendToField(m *Message, idx int, fs *FieldSchema, value any) error {
	elem, err := convertElement(fs, value)
	if err != nil {
		return err
	}
	if !m.fields[idx].set {
		m.fields[idx] = fieldVal{set: true, val: emptySliceFor(fs.Type)}
	}
	switch fs.Type {
	case FieldMessage:
		m.fields[idx].val = append(m.fields[idx].val.([]*Message), elem.(*Message))
	case FieldString:
		m.fields[idx].val = append(m.fields[idx].val.([]string), elem.(string))
	case FieldInt32:
		m.fields[idx].val = append(m.fields[idx].val.([]int32), elem.(int32))
	case FieldInt64:
		m.fields[idx].val = append(m.fields[idx].val.([]int64), elem.(int64))
	case FieldUint32:
		m.fields[idx].val = append(m.fields[idx].val.([]uint32), elem.(uint32))
	case FieldUint64:
		m.fields[idx].val = append(m.fields[idx].val.([]uint64), elem.(uint64))
	case FieldFloat:
		m.fields[idx].val = append(m.fields[idx].val.([]float32), elem.(float32))
	case FieldDouble:
		m.fields[idx].val = append(m.fields[idx].val.([]float64), elem.(float64))
	case FieldBool:
		m.fields[idx].val = append(m.fields[idx].val.([]bool), elem.(bool))
	case FieldBytes:
		m.fields[idx].val = append(m.fields[idx].val.([][]byte), elem.([]byte))
	default:
		return ErrTypeMismatch
	}
	return nil
}

func cloneMessage(src *Message) *Message {
	if src == nil {
		return nil
	}
	dst := newMessage(src.schema)
	for i, f := range src.fields {
		if !f.set {
			continue
		}
		fs := &src.schema.Fields[i]
		dst.fields[i].set = true
		if fs.Repeated {
			dst.fields[i].val = cloneRepeated(fs.Type, f.val)
		} else if fs.Type == FieldMessage {
			dst.fields[i].val = cloneMessage(f.val.(*Message))
		} else if fs.Type == FieldBytes {
			dst.fields[i].val = cloneBytes(f.val.([]byte))
		} else {
			dst.fields[i].val = f.val
		}
	}
	return dst
}

func cloneRepeated(typ FieldType, val any) any {
	switch typ {
	case FieldString:
		s := val.([]string)
		out := make([]string, len(s))
		copy(out, s)
		return out
	case FieldInt32:
		s := val.([]int32)
		out := make([]int32, len(s))
		copy(out, s)
		return out
	case FieldInt64:
		s := val.([]int64)
		out := make([]int64, len(s))
		copy(out, s)
		return out
	case FieldUint32:
		s := val.([]uint32)
		out := make([]uint32, len(s))
		copy(out, s)
		return out
	case FieldUint64:
		s := val.([]uint64)
		out := make([]uint64, len(s))
		copy(out, s)
		return out
	case FieldFloat:
		s := val.([]float32)
		out := make([]float32, len(s))
		copy(out, s)
		return out
	case FieldDouble:
		s := val.([]float64)
		out := make([]float64, len(s))
		copy(out, s)
		return out
	case FieldBool:
		s := val.([]bool)
		out := make([]bool, len(s))
		copy(out, s)
		return out
	case FieldBytes:
		s := val.([][]byte)
		out := make([][]byte, len(s))
		for i, b := range s {
			out[i] = cloneBytes(b)
		}
		return out
	case FieldMessage:
		s := val.([]*Message)
		out := make([]*Message, len(s))
		for i, msg := range s {
			out[i] = cloneMessage(msg)
		}
		return out
	default:
		return nil
	}
}

func cloneBytes(b []byte) []byte {
	if b == nil {
		return nil
	}
	out := make([]byte, len(b))
	copy(out, b)
	return out
}

func emptySliceFor(typ FieldType) any {
	switch typ {
	case FieldString:
		return []string{}
	case FieldInt32:
		return []int32{}
	case FieldInt64:
		return []int64{}
	case FieldUint32:
		return []uint32{}
	case FieldUint64:
		return []uint64{}
	case FieldFloat:
		return []float32{}
	case FieldDouble:
		return []float64{}
	case FieldBool:
		return []bool{}
	case FieldBytes:
		return [][]byte{}
	case FieldMessage:
		return []*Message{}
	default:
		return nil
	}
}

func sliceLen(typ FieldType, val any) int {
	switch typ {
	case FieldString:
		return len(val.([]string))
	case FieldInt32:
		return len(val.([]int32))
	case FieldInt64:
		return len(val.([]int64))
	case FieldUint32:
		return len(val.([]uint32))
	case FieldUint64:
		return len(val.([]uint64))
	case FieldFloat:
		return len(val.([]float32))
	case FieldDouble:
		return len(val.([]float64))
	case FieldBool:
		return len(val.([]bool))
	case FieldBytes:
		return len(val.([][]byte))
	case FieldMessage:
		return len(val.([]*Message))
	default:
		return 0
	}
}

func setSliceElem(arr any, i int, elem any, typ FieldType) {
	switch typ {
	case FieldString:
		arr.([]string)[i] = elem.(string)
	case FieldInt32:
		arr.([]int32)[i] = elem.(int32)
	case FieldInt64:
		arr.([]int64)[i] = elem.(int64)
	case FieldUint32:
		arr.([]uint32)[i] = elem.(uint32)
	case FieldUint64:
		arr.([]uint64)[i] = elem.(uint64)
	case FieldFloat:
		arr.([]float32)[i] = elem.(float32)
	case FieldDouble:
		arr.([]float64)[i] = elem.(float64)
	case FieldBool:
		arr.([]bool)[i] = elem.(bool)
	case FieldBytes:
		arr.([][]byte)[i] = elem.([]byte)
	case FieldMessage:
		arr.([]*Message)[i] = elem.(*Message)
	}
}

func isNilValue(v any) bool {
	if v == nil {
		return true
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Ptr, reflect.Slice:
		return rv.IsNil()
	default:
		return false
	}
}
