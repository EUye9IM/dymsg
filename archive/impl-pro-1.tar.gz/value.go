package dymsg

// Value is the result of a Get operation. It carries the value together with
// existence, presence and error state so callers can distinguish "field does
// not exist", "field exists but is unset", and "field is set".
type Value struct {
	typ      FieldType
	repeated bool
	exists   bool
	isSet    bool
	err      error
	val      any
	msg      *Message
}

func valueErr(err error) Value {
	return Value{err: err}
}

func selfValue(m *Message) Value {
	return Value{typ: FieldMessage, exists: true, isSet: true, val: m, msg: m}
}

func fieldValue(m *Message, idx int, fs *FieldSchema) Value {
	if m == nil || !m.fields[idx].set {
		return Value{
			typ:      fs.Type,
			repeated: fs.Repeated,
			exists:   true,
		}
	}
	v := Value{
		typ:      fs.Type,
		repeated: fs.Repeated,
		exists:   true,
		isSet:    true,
		val:      m.fields[idx].val,
	}
	if fs.Type == FieldMessage && !fs.Repeated && v.val != nil {
		v.msg = v.val.(*Message)
	}
	return v
}

func elementValue(fs *FieldSchema, arr any, idx int) Value {
	switch fs.Type {
	case FieldMessage:
		slice := arr.([]*Message)
		elem := slice[idx]
		if elem == nil {
			return Value{typ: FieldMessage, exists: true}
		}
		return Value{typ: FieldMessage, exists: true, isSet: true, val: elem, msg: elem}
	case FieldBytes:
		slice := arr.([][]byte)
		return Value{typ: FieldBytes, exists: true, isSet: true, val: slice[idx]}
	case FieldString:
		slice := arr.([]string)
		return Value{typ: FieldString, exists: true, isSet: true, val: slice[idx]}
	case FieldInt32:
		slice := arr.([]int32)
		return Value{typ: FieldInt32, exists: true, isSet: true, val: slice[idx]}
	case FieldInt64:
		slice := arr.([]int64)
		return Value{typ: FieldInt64, exists: true, isSet: true, val: slice[idx]}
	case FieldUint32:
		slice := arr.([]uint32)
		return Value{typ: FieldUint32, exists: true, isSet: true, val: slice[idx]}
	case FieldUint64:
		slice := arr.([]uint64)
		return Value{typ: FieldUint64, exists: true, isSet: true, val: slice[idx]}
	case FieldFloat:
		slice := arr.([]float32)
		return Value{typ: FieldFloat, exists: true, isSet: true, val: slice[idx]}
	case FieldDouble:
		slice := arr.([]float64)
		return Value{typ: FieldDouble, exists: true, isSet: true, val: slice[idx]}
	case FieldBool:
		slice := arr.([]bool)
		return Value{typ: FieldBool, exists: true, isSet: true, val: slice[idx]}
	default:
		return Value{err: ErrTypeMismatch}
	}
}

// Exists reports whether the path is valid and the field or element exists.
func (v Value) Exists() bool { return v.exists }

// IsSet reports whether the field has a presence value. Set fields may have
// zero values; IsSet distinguishes presence from value zero.
func (v Value) IsSet() bool { return v.isSet }

// Err returns the path/parse error, or nil on success.
func (v Value) Err() error { return v.err }

// Any returns the native Go value: scalars as their native type, message
// fields as *Message, and repeated fields as []T, [][]byte or []*Message.
// It returns nil when the value does not exist or is not set.
func (v Value) Any() any {
	if v.err != nil || !v.exists || !v.isSet {
		return nil
	}
	return v.val
}

func (v Value) scalarOK(t FieldType) bool {
	return v.err == nil && v.exists && v.isSet && !v.repeated && v.typ == t
}

func (v Value) sliceOK(t FieldType) bool {
	return v.err == nil && v.exists && v.isSet && v.repeated && v.typ == t
}

// String returns the value of a string field.
func (v Value) String() string {
	if !v.scalarOK(FieldString) {
		return ""
	}
	return v.val.(string)
}

// Int32 returns the value of an int32 field.
func (v Value) Int32() int32 {
	if !v.scalarOK(FieldInt32) {
		return 0
	}
	return v.val.(int32)
}

// Int64 returns the value of an int64 field.
func (v Value) Int64() int64 {
	if !v.scalarOK(FieldInt64) {
		return 0
	}
	return v.val.(int64)
}

// Uint32 returns the value of a uint32 field.
func (v Value) Uint32() uint32 {
	if !v.scalarOK(FieldUint32) {
		return 0
	}
	return v.val.(uint32)
}

// Uint64 returns the value of a uint64 field.
func (v Value) Uint64() uint64 {
	if !v.scalarOK(FieldUint64) {
		return 0
	}
	return v.val.(uint64)
}

// Float32 returns the value of a float field.
func (v Value) Float32() float32 {
	if !v.scalarOK(FieldFloat) {
		return 0
	}
	return v.val.(float32)
}

// Float64 returns the value of a double field.
func (v Value) Float64() float64 {
	if !v.scalarOK(FieldDouble) {
		return 0
	}
	return v.val.(float64)
}

// Bool returns the value of a bool field.
func (v Value) Bool() bool {
	if !v.scalarOK(FieldBool) {
		return false
	}
	return v.val.(bool)
}

// Bytes returns the value of a bytes field.
func (v Value) Bytes() []byte {
	if !v.scalarOK(FieldBytes) {
		return nil
	}
	return v.val.([]byte)
}

// Message returns the nested message of a message field. It also returns the
// receiver itself for Get("").
func (v Value) Message() *Message {
	if !v.scalarOK(FieldMessage) {
		return nil
	}
	return v.msg
}

// Len returns the length of a repeated field. It returns 0 for non-repeated,
// unset or missing values.
func (v Value) Len() int {
	if v.err != nil || !v.exists || !v.isSet || !v.repeated {
		return 0
	}
	return sliceLen(v.typ, v.val)
}

// Index returns the i-th element of a repeated field. Out-of-range indexes and
// non-repeated values produce ErrIndexOutOfRange.
func (v Value) Index(i int) Value {
	if v.err != nil {
		return v
	}
	if !v.repeated || !v.exists || !v.isSet {
		return Value{typ: v.typ, err: ErrIndexOutOfRange}
	}
	if i < 0 || i >= sliceLen(v.typ, v.val) {
		return Value{typ: v.typ, err: ErrIndexOutOfRange}
	}
	return elementValue(&FieldSchema{Type: v.typ}, v.val, i)
}

// Strings returns a string repeated field as []string.
func (v Value) Strings() []string {
	if !v.sliceOK(FieldString) {
		return nil
	}
	return v.val.([]string)
}

// Int32s returns an int32 repeated field as []int32.
func (v Value) Int32s() []int32 {
	if !v.sliceOK(FieldInt32) {
		return nil
	}
	return v.val.([]int32)
}

// Int64s returns an int64 repeated field as []int64.
func (v Value) Int64s() []int64 {
	if !v.sliceOK(FieldInt64) {
		return nil
	}
	return v.val.([]int64)
}

// Uint32s returns a uint32 repeated field as []uint32.
func (v Value) Uint32s() []uint32 {
	if !v.sliceOK(FieldUint32) {
		return nil
	}
	return v.val.([]uint32)
}

// Uint64s returns a uint64 repeated field as []uint64.
func (v Value) Uint64s() []uint64 {
	if !v.sliceOK(FieldUint64) {
		return nil
	}
	return v.val.([]uint64)
}

// Float32s returns a float repeated field as []float32.
func (v Value) Float32s() []float32 {
	if !v.sliceOK(FieldFloat) {
		return nil
	}
	return v.val.([]float32)
}

// Float64s returns a double repeated field as []float64.
func (v Value) Float64s() []float64 {
	if !v.sliceOK(FieldDouble) {
		return nil
	}
	return v.val.([]float64)
}

// Bools returns a bool repeated field as []bool.
func (v Value) Bools() []bool {
	if !v.sliceOK(FieldBool) {
		return nil
	}
	return v.val.([]bool)
}

// BytesSlice returns a bytes repeated field as [][]byte.
func (v Value) BytesSlice() [][]byte {
	if !v.sliceOK(FieldBytes) {
		return nil
	}
	return v.val.([][]byte)
}

// Messages returns a message repeated field as []*Message.
func (v Value) Messages() []*Message {
	if !v.sliceOK(FieldMessage) {
		return nil
	}
	return v.val.([]*Message)
}
