package dymsg

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"math"
	"strconv"
)

// EncodeJSON encodes the message as a JSON object. Unset fields are omitted
// and fields are emitted in schema declaration order.
func (m *Message) EncodeJSON() ([]byte, error) {
	var buf bytes.Buffer
	if err := writeJSONMessage(&buf, m); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func writeJSONMessage(buf *bytes.Buffer, m *Message) error {
	buf.WriteByte('{')
	first := true
	for i := range m.fields {
		if !m.fields[i].set {
			continue
		}
		fs := &m.schema.Fields[i]
		if !fs.Repeated && fs.Type == FieldMessage && isNilValue(m.fields[i].val) {
			continue
		}
		if !first {
			buf.WriteByte(',')
		}
		key, err := json.Marshal(fs.Name)
		if err != nil {
			return ErrMalformedData
		}
		buf.Write(key)
		buf.WriteByte(':')
		if err := writeJSONField(buf, fs, m.fields[i].val); err != nil {
			return err
		}
		first = false
	}
	buf.WriteByte('}')
	return nil
}

func writeJSONField(buf *bytes.Buffer, fs *FieldSchema, val any) error {
	if fs.Repeated {
		buf.WriteByte('[')
		n := sliceLen(fs.Type, val)
		switch fs.Type {
		case FieldMessage:
			arr := val.([]*Message)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if arr[i] == nil {
					buf.WriteString("null")
					continue
				}
				if err := writeJSONMessage(buf, arr[i]); err != nil {
					return err
				}
			}
		case FieldString:
			arr := val.([]string)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldString, arr[i]); err != nil {
					return err
				}
			}
		case FieldInt32:
			arr := val.([]int32)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldInt32, arr[i]); err != nil {
					return err
				}
			}
		case FieldInt64:
			arr := val.([]int64)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldInt64, arr[i]); err != nil {
					return err
				}
			}
		case FieldUint32:
			arr := val.([]uint32)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldUint32, arr[i]); err != nil {
					return err
				}
			}
		case FieldUint64:
			arr := val.([]uint64)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldUint64, arr[i]); err != nil {
					return err
				}
			}
		case FieldFloat:
			arr := val.([]float32)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldFloat, arr[i]); err != nil {
					return err
				}
			}
		case FieldDouble:
			arr := val.([]float64)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldDouble, arr[i]); err != nil {
					return err
				}
			}
		case FieldBool:
			arr := val.([]bool)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldBool, arr[i]); err != nil {
					return err
				}
			}
		case FieldBytes:
			arr := val.([][]byte)
			for i := 0; i < n; i++ {
				if i > 0 {
					buf.WriteByte(',')
				}
				if err := writeJSONScalar(buf, FieldBytes, arr[i]); err != nil {
					return err
				}
			}
		}
		buf.WriteByte(']')
		return nil
	}

	if fs.Type == FieldMessage {
		msg := val.(*Message)
		if msg == nil {
			buf.WriteString("null")
			return nil
		}
		return writeJSONMessage(buf, msg)
	}
	return writeJSONScalar(buf, fs.Type, val)
}

func writeJSONScalar(buf *bytes.Buffer, t FieldType, val any) error {
	switch t {
	case FieldFloat:
		f := float64(val.(float32))
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return ErrMalformedData
		}
	case FieldDouble:
		f := val.(float64)
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return ErrMalformedData
		}
	case FieldBytes:
		b64 := base64.StdEncoding.EncodeToString(val.([]byte))
		encoded, err := json.Marshal(b64)
		if err != nil {
			return ErrMalformedData
		}
		buf.Write(encoded)
		return nil
	}
	encoded, err := json.Marshal(val)
	if err != nil {
		return ErrMalformedData
	}
	buf.Write(encoded)
	return nil
}

// DecodeJSON replaces the message contents with values decoded from a JSON
// object. Unknown keys are ignored and top-level null clears the message.
func (m *Message) DecodeJSON(data []byte) error {
	if len(data) == 0 {
		return ErrTruncated
	}
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()

	var raw any
	if err := dec.Decode(&raw); err != nil {
		return ErrMalformedData
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		return ErrMalformedData
	}

	if raw == nil {
		m.clearAll()
		return nil
	}
	obj, ok := raw.(map[string]any)
	if !ok {
		return ErrMalformedData
	}

	m.clearAll()
	return decodeJSONObject(m, obj)
}

func decodeJSONObject(m *Message, obj map[string]any) error {
	for key, raw := range obj {
		idx, ok := m.schema.lookupName(key)
		if !ok {
			continue
		}
		fs := &m.schema.Fields[idx]
		if raw == nil {
			m.fields[idx] = fieldVal{}
			continue
		}
		if fs.Repeated {
			if err := decodeJSONRepeated(m, idx, fs, raw); err != nil {
				return err
			}
		} else {
			val, err := decodeJSONFieldValue(fs, raw)
			if err != nil {
				return err
			}
			m.fields[idx] = fieldVal{set: true, val: val}
		}
	}
	return nil
}

func decodeJSONFieldValue(fs *FieldSchema, raw any) (any, error) {
	if fs.Type == FieldMessage {
		obj, ok := raw.(map[string]any)
		if !ok {
			return nil, ErrMalformedData
		}
		nm := newMessage(&fs.Schema)
		if err := decodeJSONObject(nm, obj); err != nil {
			return nil, err
		}
		return nm, nil
	}
	return decodeJSONScalar(fs.Type, raw)
}

func decodeJSONRepeated(m *Message, idx int, fs *FieldSchema, raw any) error {
	arr, ok := raw.([]any)
	if !ok {
		return ErrMalformedData
	}
	if fs.Type == FieldMessage {
		out := make([]*Message, len(arr))
		for i, elem := range arr {
			if elem == nil {
				out[i] = nil
				continue
			}
			obj, ok := elem.(map[string]any)
			if !ok {
				return ErrMalformedData
			}
			nm := newMessage(&fs.Schema)
			if err := decodeJSONObject(nm, obj); err != nil {
				return err
			}
			out[i] = nm
		}
		m.fields[idx] = fieldVal{set: true, val: out}
		return nil
	}

	switch fs.Type {
	case FieldString:
		out := make([]string, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(string)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldInt32:
		out := make([]int32, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(int32)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldInt64:
		out := make([]int64, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(int64)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldUint32:
		out := make([]uint32, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(uint32)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldUint64:
		out := make([]uint64, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(uint64)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldFloat:
		out := make([]float32, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(float32)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldDouble:
		out := make([]float64, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(float64)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldBool:
		out := make([]bool, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.(bool)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	case FieldBytes:
		out := make([][]byte, len(arr))
		for i, elem := range arr {
			if elem == nil {
				return ErrMalformedData
			}
			v, err := decodeJSONScalar(fs.Type, elem)
			if err != nil {
				return err
			}
			out[i] = v.([]byte)
		}
		m.fields[idx] = fieldVal{set: true, val: out}
	default:
		return ErrMalformedData
	}
	return nil
}

func decodeJSONScalar(t FieldType, raw any) (any, error) {
	switch t {
	case FieldString:
		s, ok := raw.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		return s, nil
	case FieldBool:
		b, ok := raw.(bool)
		if !ok {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldBytes:
		s, ok := raw.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			b, err = base64.RawStdEncoding.DecodeString(s)
			if err != nil {
				return nil, ErrMalformedData
			}
		}
		return b, nil
	case FieldInt32:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseInt(num.String(), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return int32(n), nil
	case FieldInt64:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseInt(num.String(), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldUint32:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseUint(num.String(), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return uint32(n), nil
	case FieldUint64:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseUint(num.String(), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldFloat:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(num.String(), 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return float32(f), nil
	case FieldDouble:
		num, ok := raw.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(num.String(), 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return f, nil
	default:
		return nil, ErrMalformedData
	}
}
