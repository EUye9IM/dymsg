package dymsg

import (
	"bytes"
	"encoding/json"
	"errors"
	"math"
	"reflect"
	"strings"
	"sync"
	"testing"
)

func testConfig() []byte {
	return []byte(`{
	  "types": [
	    {
	      "typeId": 1001,
	      "fields": [
	        { "name": "name", "type": "string", "num": 1 },
	        { "name": "age", "type": "int32", "num": 2 },
	        { "name": "score", "type": "double", "num": 3 },
	        { "name": "active", "type": "bool", "num": 4 },
	        { "name": "data", "type": "bytes", "num": 5 },
	        {
	          "name": "addr",
	          "type": "message",
	          "num": 6,
	          "schema": {
	            "fields": [
	              { "name": "city", "type": "string", "num": 1 },
	              { "name": "zip", "type": "string", "num": 2 }
	            ]
	          }
	        },
	        { "name": "tags", "type": "string", "num": 7, "repeated": true },
	        { "name": "nums", "type": "int32", "num": 8, "repeated": true },
	        {
	          "name": "contacts",
	          "type": "message",
	          "num": 9,
	          "repeated": true,
	          "schema": {
	            "fields": [
	              { "name": "phone", "type": "string", "num": 1 }
	            ]
	          }
	        }
	      ]
	    },
	    {
	      "typeId": 1002,
	      "fields": [
	        { "name": "flag", "type": "bool", "num": 1 },
	        { "name": "count", "type": "uint64", "num": 2 }
	      ]
	    }
	  ]
	}`)
}

func registerTestSchemas(t *testing.T) {
	t.Helper()
	schemas, err := ParseSchema(testConfig())
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	for _, s := range schemas {
		if err := Register(s); err != nil && !errors.Is(err, ErrDuplicateID) {
			t.Fatalf("Register: %v", err)
		}
	}
}

func mustNew(t *testing.T, id uint16) *Message {
	t.Helper()
	m, err := New(id)
	if err != nil {
		t.Fatalf("New(%d): %v", id, err)
	}
	return m
}

func TestParseSchemaAndRegister(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q", got)
	}
	if _, err := New(9999); !errors.Is(err, ErrUnknownTypeID) {
		t.Fatalf("New unknown err = %v", err)
	}

	if err := Register(MessageSchema{TypeID: 1001, Fields: []FieldSchema{{Name: "name", Num: 1, Type: FieldString}}}); !errors.Is(err, ErrDuplicateID) {
		t.Fatalf("duplicate different err = %v", err)
	}
}

func TestParseSchemaMalformed(t *testing.T) {
	cases := []string{
		``,
		`{}`,
		`{"types":null}`,
		`{"types":[{"typeId":0,"fields":[]}]}`,
		`{"types":[{"typeId":65536,"fields":[]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":0,"type":"string"}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"bogus"}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a.b","num":1,"type":"string"}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"message"}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"string","schema":{"fields":[]}}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"string"},{"name":"b","num":1,"type":"string"}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"string"},{"name":"a","num":2,"type":"string"}]}]}`,
		`{"types":[{"typeId":1,"fields":[]},{"typeId":1,"fields":[]}]}`,
	}
	for i, c := range cases {
		if _, err := ParseSchema([]byte(c)); !errors.Is(err, ErrMalformedData) {
			t.Fatalf("case %d: err = %v, want ErrMalformedData", i, err)
		}
	}
}

func TestParseSchemaNonMessageWithSchema(t *testing.T) {
	_, err := ParseSchema([]byte(`{"types":[{"typeId":1,"fields":[{"name":"a","num":1,"type":"string","schema":{"fields":[]}}]}]}`))
	if !errors.Is(err, ErrMalformedData) {
		t.Fatalf("err = %v", err)
	}
}

func TestGetSetPresence(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	v := m.Get("name")
	if !v.Exists() || v.IsSet() || v.Err() != nil {
		t.Fatalf("unset field Value: exists=%v set=%v err=%v", v.Exists(), v.IsSet(), v.Err())
	}
	if v.String() != "" {
		t.Fatalf("unset String = %q", v.String())
	}

	if err := m.Set("name", "bob"); err != nil {
		t.Fatal(err)
	}
	v = m.Get("name")
	if !v.Exists() || !v.IsSet() || v.Err() != nil || v.String() != "bob" {
		t.Fatalf("set field Value: exists=%v set=%v err=%v val=%q", v.Exists(), v.IsSet(), v.Err(), v.String())
	}

	if err := m.Set("name", nil); err != nil {
		t.Fatal(err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared")
	}
	if v := m.Get("name"); v.IsSet() {
		t.Fatal("name should be unset")
	}

	if err := m.Clear("unknown"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Clear unknown err = %v", err)
	}
}

func TestPathErrors(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	if err := m.Append("tags", "a"); err != nil {
		t.Fatal(err)
	}

	cases := []struct {
		path string
		err  error
	}{
		{"unknown", ErrFieldNotFound},
		{"name[0]", ErrFieldNotFound},
		{"tags[-1]", ErrIndexOutOfRange},
		{"tags[abc]", ErrIndexOutOfRange},
		{"tags[]", ErrIndexOutOfRange},
		{"name.x", ErrFieldNotFound},
		{"tags[0].x", ErrFieldNotFound},
		{"tags[0", ErrFieldNotFound},
		{"tags[0]x", ErrFieldNotFound},
	}
	for _, c := range cases {
		if got := m.Get(c.path).Err(); !errors.Is(got, c.err) {
			t.Fatalf("Get(%q).Err() = %v, want %v", c.path, got, c.err)
		}
	}
	if got := m.Get("tags[1]").Err(); !errors.Is(got, ErrIndexOutOfRange) {
		t.Fatalf("out of range err = %v", got)
	}
}

func TestRepeatedAccess(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	if got := m.Get("tags").Len(); got != 0 {
		t.Fatalf("unset repeated len = %d", got)
	}
	if m.Get("tags").Strings() != nil {
		t.Fatal("unset repeated slice should be nil")
	}
	if err := m.Append("tags", "a"); err != nil {
		t.Fatal(err)
	}
	if err := m.Append("tags", "b"); err != nil {
		t.Fatal(err)
	}
	v := m.Get("tags")
	if v.Len() != 2 || !reflect.DeepEqual(v.Strings(), []string{"a", "b"}) {
		t.Fatalf("tags = %#v len=%d", v.Strings(), v.Len())
	}
	if got := m.Get("tags[1]").String(); got != "b" {
		t.Fatalf("tags[1] = %q", got)
	}
	if err := m.Set("tags[0]", "A"); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("tags[0]").String(); got != "A" {
		t.Fatalf("tags[0] = %q", got)
	}
	if err := m.Set("tags[5]", "z"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Set out of range err = %v", err)
	}
	if err := m.Set("tags[0]", "z"); err != nil {
		t.Fatal(err)
	}
	if err := m.Append("name", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append non-repeated err = %v", err)
	}

	if err := m.Set("nums", []int32{1, 2, 3}); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(m.Get("nums").Int32s(), []int32{1, 2, 3}) {
		t.Fatalf("nums = %v", m.Get("nums").Int32s())
	}
	if err := m.Append("nums", int64(4)); err != nil {
		t.Fatal(err)
	}
	if m.Get("nums").Len() != 4 || m.Get("nums[3]").Int32() != 4 {
		t.Fatalf("append nums mismatch")
	}
}

func TestNestedMessageAutoCreateAndDeepCopy(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatal(err)
	}
	addr := m.Get("addr").Message()
	if addr == nil || addr.Get("city").String() != "beijing" {
		t.Fatalf("addr = %#v", addr)
	}

	// Deep-copy a nested message on Set.
	other := mustNew(t, 1001)
	if err := other.Set("addr.city", "shanghai"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("addr", other.Get("addr").Message()); err != nil {
		t.Fatal(err)
	}
	if err := other.Set("addr.city", "guangzhou"); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("addr.city").String(); got != "shanghai" {
		t.Fatalf("nested deep copy broken: %q", got)
	}
}

func TestWholeMessageReplaceDeepCopy(t *testing.T) {
	registerTestSchemas(t)
	a := mustNew(t, 1001)
	b := mustNew(t, 1001)
	if err := a.Set("name", "alice"); err != nil {
		t.Fatal(err)
	}
	if err := a.Append("tags", "x"); err != nil {
		t.Fatal(err)
	}
	if err := b.Set("", a); err != nil {
		t.Fatal(err)
	}
	if err := a.Set("name", "bob"); err != nil {
		t.Fatal(err)
	}
	if err := a.Set("tags[0]", "y"); err != nil {
		t.Fatal(err)
	}
	if got := b.Get("name").String(); got != "alice" {
		t.Fatalf("name = %q", got)
	}
	if got := b.Get("tags[0]").String(); got != "x" {
		t.Fatalf("tags[0] = %q", got)
	}

	bad := mustNew(t, 1002)
	if err := b.Set("", bad); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set whole different schema err = %v", err)
	}
}

func TestTypeConversion(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	if err := m.Set("age", int64(18)); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("age").Int32(); got != 18 {
		t.Fatalf("age = %d", got)
	}
	if err := m.Set("age", "20"); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("age").Int32(); got != 20 {
		t.Fatalf("age string = %d", got)
	}
	if err := m.Set("age", 21.9); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("age").Int32(); got != 21 {
		t.Fatalf("age float = %d", got)
	}
	if err := m.Set("age", uint64(math.MaxUint32)); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("overflow err = %v", err)
	}
	if err := m.Set("age", float64(math.NaN())); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("NaN err = %v", err)
	}
	if err := m.Set("name", []byte("bytes-name")); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("name").String(); got != "bytes-name" {
		t.Fatalf("bytes->string = %q", got)
	}
	if err := m.Set("data", "raw"); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(m.Get("data").Bytes(), []byte("raw")) {
		t.Fatalf("string->bytes = %v", m.Get("data").Bytes())
	}
	if err := m.Set("age", []int{1}); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("slice to scalar err = %v", err)
	}
}

func TestClearAndSetFields(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("age", 1); err != nil {
		t.Fatal(err)
	}
	if err := m.Append("tags", "t"); err != nil {
		t.Fatal(err)
	}
	fields := m.SetFields()
	want := []string{"name", "age", "tags"}
	if !reflect.DeepEqual(fields, want) {
		t.Fatalf("SetFields = %v, want %v", fields, want)
	}
	if err := m.Clear("name"); err != nil {
		t.Fatal(err)
	}
	if err := m.Clear("name"); err != nil {
		t.Fatalf("clear unset should be nil: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be unset")
	}
	if err := m.Clear(""); err != nil {
		t.Fatal(err)
	}
	if got := m.SetFields(); len(got) != 0 {
		t.Fatalf("SetFields after Clear('') = %v", got)
	}
}

func TestJSONRoundTripAndNulls(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("age", 30); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("score", 1.5); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("active", true); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("data", []byte{1, 2, 3}); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("tags", []string{"a", "b"}); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("nums", []int32{1, 2}); err != nil {
		t.Fatal(err)
	}
	contact := newMessage(&m.schema.Fields[8].Schema)
	if err := contact.Set("phone", "123"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("contacts", []*Message{nil, contact}); err != nil {
		t.Fatal(err)
	}

	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatal(err)
	}
	var raw map[string]any
	if err := json.Unmarshal(b, &raw); err != nil {
		t.Fatal(err)
	}
	if raw["name"] != "alice" || raw["age"] != float64(30) {
		t.Fatalf("raw = %v", raw)
	}
	if _, ok := raw["unknown"]; ok {
		t.Fatal("unexpected key")
	}

	n := mustNew(t, 1001)
	if err := n.DecodeJSON(b); err != nil {
		t.Fatal(err)
	}
	if n.Get("name").String() != "alice" || n.Get("age").Int32() != 30 || n.Get("data").Bytes()[1] != 2 {
		t.Fatalf("roundtrip mismatch")
	}
	if n.Get("contacts").Len() != 2 || n.Get("contacts[0]").Message() != nil || n.Get("contacts[1].phone").String() != "123" {
		t.Fatalf("contacts roundtrip mismatch")
	}

	if err := n.DecodeJSON([]byte(`{"name":null,"age":2147483647,"unknown":1}`)); err != nil {
		t.Fatal(err)
	}
	if n.Has("name") {
		t.Fatal("null name should be unset")
	}
	if n.Get("age").Int32() != 2147483647 {
		t.Fatalf("age = %d", n.Get("age").Int32())
	}

	if err := n.DecodeJSON([]byte(`null`)); err != nil {
		t.Fatal(err)
	}
	if len(n.SetFields()) != 0 {
		t.Fatalf("top null should clear: %v", n.SetFields())
	}
}

func TestJSONDecodeErrors(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	cases := [][]byte{
		{},
		[]byte(`[]`),
		[]byte(`"x"`),
		[]byte(`123`),
		[]byte(`{"age":"18"}`),
		[]byte(`{"age":2147483648}`),
		[]byte(`{"data":"!!!"}`),
		[]byte(`{"nums":[1,null]}`),
		[]byte(`{"name":1}`),
		[]byte(`{"tags":"a"}`),
		[]byte(`{"age":1} trailing`),
	}
	for i, c := range cases {
		if len(c) == 0 {
			if err := m.DecodeJSON(c); !errors.Is(err, ErrTruncated) {
				t.Fatalf("empty case %d err = %v", i, err)
			}
			continue
		}
		if err := m.DecodeJSON(c); !errors.Is(err, ErrMalformedData) {
			t.Fatalf("case %d (%s) err = %v", i, c, err)
		}
	}
}

func TestProtoRoundTrip(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("age", -1); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("score", -1.25); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("active", true); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("data", []byte{0, 1, 2}); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("tags", []string{"a", "b"}); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("nums", []int32{-1, 0, 1}); err != nil {
		t.Fatal(err)
	}
	contact := newMessage(&m.schema.Fields[8].Schema)
	if err := contact.Set("phone", "inner"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("contacts", []*Message{contact}); err != nil {
		t.Fatal(err)
	}

	proto, err := m.EncodeProto()
	if err != nil {
		t.Fatal(err)
	}
	n := mustNew(t, 1001)
	if err := n.DecodeProto(proto); err != nil {
		t.Fatal(err)
	}
	if n.Get("name").String() != "alice" || n.Get("age").Int32() != -1 || n.Get("score").Float64() != -1.25 {
		t.Fatalf("scalar mismatch")
	}
	if !bytes.Equal(n.Get("data").Bytes(), []byte{0, 1, 2}) {
		t.Fatalf("bytes mismatch")
	}
	if !reflect.DeepEqual(n.Get("tags").Strings(), []string{"a", "b"}) {
		t.Fatalf("tags mismatch: %v", n.Get("tags").Strings())
	}
	if !reflect.DeepEqual(n.Get("nums").Int32s(), []int32{-1, 0, 1}) {
		t.Fatalf("nums mismatch: %v", n.Get("nums").Int32s())
	}
	if n.Get("contacts").Len() != 1 || n.Get("contacts[0].phone").String() != "inner" {
		t.Fatalf("contacts mismatch")
	}
}

func TestProtoDecodeEmptyAndUnknownSkip(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.DecodeProto(nil); err != nil {
		t.Fatalf("empty decode err = %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("empty proto should be unset: %v", m.SetFields())
	}

	// field 15 is unknown; should be skipped
	data := appendTag(nil, 15, wireVarint)
	data = appendVarint(data, 999)
	data = appendTag(data, 1, wireBytes)
	data = appendVarint(data, 3)
	data = append(data, "bob"...)
	if err := m.DecodeProto(data); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("name").String(); got != "bob" {
		t.Fatalf("name = %q", got)
	}
}

func TestProtoDecodeErrors(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	// field number zero
	if err := m.DecodeProto([]byte{0x00}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("field zero err = %v", err)
	}
	// illegal wire type 6
	bad := appendTag(nil, 1, 6)
	if err := m.DecodeProto(bad); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire 6 err = %v", err)
	}
	// wrong wire type for string field
	bad = appendTag(nil, 1, wireVarint)
	bad = appendVarint(bad, 1)
	if err := m.DecodeProto(bad); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wrong wire err = %v", err)
	}
	// truncated length-delimited
	bad = appendTag(nil, 1, wireBytes)
	bad = appendVarint(bad, 10)
	if err := m.DecodeProto(bad); !errors.Is(err, ErrTruncated) {
		t.Fatalf("truncated err = %v", err)
	}
}

func TestProtoPackedAndUnpacked(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)

	// unpacked int32 repeated: tag wire 0 for field 8 with values 1, 2
	data := appendTag(nil, 8, wireVarint)
	data = appendVarint(data, 1)
	data = appendTag(data, 8, wireVarint)
	data = appendVarint(data, 2)
	// packed int32 repeated: tag wire 2, length 2, values 3,4
	data = appendTag(data, 8, wireBytes)
	data = appendVarint(data, 2)
	data = appendVarint(data, 3)
	data = appendVarint(data, 4)

	if err := m.DecodeProto(data); err != nil {
		t.Fatal(err)
	}
	want := []int32{1, 2, 3, 4}
	if got := m.Get("nums").Int32s(); !reflect.DeepEqual(got, want) {
		t.Fatalf("nums = %v, want %v", got, want)
	}

	// Empty packed field should remain set with length 0.
	empty := appendTag(nil, 8, wireBytes)
	empty = appendVarint(empty, 0)
	if err := m.DecodeProto(empty); err != nil {
		t.Fatal(err)
	}
	if !m.Has("nums") || m.Get("nums").Len() != 0 {
		t.Fatalf("empty packed should set nums with len 0, set=%v len=%d", m.Has("nums"), m.Get("nums").Len())
	}
}

func TestConcurrentRegisterNew(t *testing.T) {
	registerTestSchemas(t)
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(2)
		go func() {
			defer wg.Done()
			if err := Register(MessageSchema{TypeID: 2001, Fields: []FieldSchema{{Name: "x", Num: 1, Type: FieldInt32}}}); err != nil {
				t.Errorf("Register: %v", err)
			}
		}()
		go func() {
			defer wg.Done()
			m, err := New(1001)
			if err != nil {
				t.Errorf("New: %v", err)
				return
			}
			_ = m.Set("name", "x")
		}()
	}
	wg.Wait()
}

func TestValueMessageScalarGetterZero(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("addr.city", "x"); err != nil {
		t.Fatal(err)
	}
	v := m.Get("addr")
	if v.Int32() != 0 || v.String() != "" {
		t.Fatalf("scalar getter on message should be zero")
	}
	if v.Message() == nil || v.Message().Get("city").String() != "x" {
		t.Fatal("Message getter should return nested message")
	}
}

func TestRepeatedMessagesAny(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("contacts", []*Message{nil}); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("contacts").Messages(); len(got) != 1 || got[0] != nil {
		t.Fatalf("Messages = %#v", got)
	}
	if v := m.Get("contacts").Index(0); v.Err() != nil || v.Exists() != true || v.IsSet() != false || v.Message() != nil {
		t.Fatalf("nil message element Value: err=%v exists=%v set=%v msg=%v", v.Err(), v.Exists(), v.IsSet(), v.Message())
	}
}

func TestEncodeJSONFloatInvalid(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("score", math.NaN()); err != nil {
		t.Fatal(err)
	}
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("NaN encode err = %v", err)
	}
	if err := m.Set("score", math.Inf(1)); err != nil {
		t.Fatal(err)
	}
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("Inf encode err = %v", err)
	}
}

func TestSetWholeMessageWithNil(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("", nil); err != nil {
		t.Fatal(err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("Set(\"\", nil) should clear: %v", m.SetFields())
	}
}

func TestRegisterMissingMessageSchema(t *testing.T) {
	err := Register(MessageSchema{TypeID: 4001, Fields: []FieldSchema{{Name: "m", Num: 1, Type: FieldMessage}}})
	if !errors.Is(err, ErrMalformedData) {
		t.Fatalf("Register missing nested schema err = %v", err)
	}
}

func TestRegisterDuplicateIdentical(t *testing.T) {
	registerTestSchemas(t)
	if err := Register(MessageSchema{TypeID: 3001, Fields: []FieldSchema{{Name: "a", Num: 1, Type: FieldString}}}); err != nil {
		t.Fatal(err)
	}
	if err := Register(MessageSchema{TypeID: 3001, Fields: []FieldSchema{{Name: "a", Num: 1, Type: FieldString}}}); err != nil {
		t.Fatal(err)
	}
	if err := Register(MessageSchema{TypeID: 3001, Fields: []FieldSchema{{Name: "b", Num: 1, Type: FieldString}}}); !errors.Is(err, ErrDuplicateID) {
		t.Fatalf("different duplicate err = %v", err)
	}
}

func TestEncodeJSONOrder(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("age", 1); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatal(err)
	}
	if string(b) != `{"name":"x","age":1}` {
		t.Fatalf("JSON order = %s", b)
	}
}

func TestDecodeJSONReplacesAll(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("age", 5); err != nil {
		t.Fatal(err)
	}
	if err := m.DecodeJSON([]byte(`{"name":"y"}`)); err != nil {
		t.Fatal(err)
	}
	if m.Has("age") {
		t.Fatal("DecodeJSON should replace old fields")
	}
	if got := m.Get("name").String(); got != "y" {
		t.Fatalf("name = %q", got)
	}
}

func TestDecodeProtoReplacesAll(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	data := appendTag(nil, 2, wireVarint)
	data = appendVarint(data, 42)
	if err := m.DecodeProto(data); err != nil {
		t.Fatal(err)
	}
	if m.Has("name") {
		t.Fatal("DecodeProto should replace old fields")
	}
	if got := m.Get("age").Int32(); got != 42 {
		t.Fatalf("age = %d", got)
	}
}

func TestPathEmptyGetSetClear(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	v := m.Get("")
	if v.Err() != nil || !v.Exists() || !v.IsSet() || v.Message() != m {
		t.Fatalf("Get(\"\") = %#v", v)
	}
	if err := m.Set("name", "x"); err != nil {
		t.Fatal(err)
	}
	if !m.Has("") {
		t.Fatal("Has(\"\") should be true")
	}
	if err := m.Clear(""); err != nil {
		t.Fatal(err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("Clear(\"\") = %v", m.SetFields())
	}
}

func TestRepeatedBytesStringConversion(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("data", "abc"); err != nil {
		t.Fatal(err)
	}
	if got := string(m.Get("data").Bytes()); got != "abc" {
		t.Fatalf("data = %s", got)
	}
	// bytes repeated roundtrip via JSON base64
	_ = m
}

func TestNestedRepeatedMessageSetAutoCreate(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	// path through nested message into repeated tags should auto-create addr
	if err := m.Set("addr.city", "x"); err != nil {
		t.Fatal(err)
	}
}

func TestValueSlicesForUnset(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	v := m.Get("tags")
	if v.Len() != 0 || v.Strings() != nil {
		t.Fatalf("unset repeated")
	}
	if err := m.Set("tags", []string{}); err != nil {
		t.Fatal(err)
	}
	if !m.Has("tags") || m.Get("tags").Len() != 0 {
		t.Fatal("empty repeated should be set")
	}
	if got := m.Get("tags").Strings(); got == nil {
		t.Fatal("empty repeated Strings should be non-nil slice")
	}
}

func TestClearNestedInRepeatedMessage(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	contact := newMessage(&m.schema.Fields[8].Schema)
	if err := contact.Set("phone", "123"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("contacts", []*Message{contact}); err != nil {
		t.Fatal(err)
	}
	if err := m.Clear("contacts[0].phone"); err != nil {
		t.Fatal(err)
	}
	if m.Get("contacts[0].phone").IsSet() {
		t.Fatal("phone should be cleared")
	}
	if m.Get("contacts").Len() != 1 || m.Get("contacts[0]").Message() == nil {
		t.Fatal("contact element should remain")
	}
	if err := m.Set("contacts[0].phone", "456"); err != nil {
		t.Fatal(err)
	}
	if err := m.Set("contacts[0].phone", nil); err != nil {
		t.Fatal(err)
	}
	if m.Get("contacts[0].phone").IsSet() {
		t.Fatal("phone should be cleared via Set nil")
	}
}

func TestSetIndexOnUnsetRepeated(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("tags[0]", "x"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Set index unset repeated err = %v", err)
	}
	if err := m.Set("name[0]", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set index on scalar err = %v", err)
	}
}

func TestParseSchemaMessageFields(t *testing.T) {
	cfg := []byte(`{"types":[{"typeId":1,"fields":[{"name":"m","type":"message","num":1,"schema":{"fields":[]}}]}]}`)
	schemas, err := ParseSchema(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatal(err)
	}
	m, err := New(1)
	if err != nil {
		t.Fatal(err)
	}
	if err := m.Set("m", &Message{schema: &schemas[0].Fields[0].Schema, fields: make([]fieldVal, 0)}); err != nil {
		t.Fatal(err)
	}
}

func TestStringConversionNumbers(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.Set("name", 123); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("name").String(); got != "123" {
		t.Fatalf("numeric->string = %q", got)
	}
	if err := m.Set("age", "18"); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("age").Int32(); got != 18 {
		t.Fatalf("string->int = %d", got)
	}
}

func TestAliasTypeConversion(t *testing.T) {
	registerTestSchemas(t)
	type myInt int32
	m := mustNew(t, 1001)
	if err := m.Set("age", myInt(7)); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("age").Int32(); got != 7 {
		t.Fatalf("alias conversion = %d", got)
	}
}

func TestDecodeJSONBytesBase64(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.DecodeJSON([]byte(`{"data":"AQID"}`)); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(m.Get("data").Bytes(), []byte{1, 2, 3}) {
		t.Fatalf("data = %v", m.Get("data").Bytes())
	}
	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(b), `"AQID"`) {
		t.Fatalf("encoded data = %s", b)
	}
}

func TestDecodeJSONUnknownNestedKeyIgnored(t *testing.T) {
	registerTestSchemas(t)
	m := mustNew(t, 1001)
	if err := m.DecodeJSON([]byte(`{"addr":{"city":"x","unknown":1}}`)); err != nil {
		t.Fatal(err)
	}
	if got := m.Get("addr.city").String(); got != "x" {
		t.Fatalf("city = %q", got)
	}
}
