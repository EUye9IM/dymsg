// Package dymsg provides runtime-defined messages whose schema is loaded
// from configuration rather than fixed at compile time. Messages can be read
// and written by field path and encoded to either JSON or a self-contained
// Protobuf wire-format subset.
package dymsg

import (
	"encoding/json"
	"errors"
	"sync"
)

// FieldType identifies the scalar or message type of a field.
type FieldType string

const (
	FieldInt32   FieldType = "int32"
	FieldInt64   FieldType = "int64"
	FieldUint32  FieldType = "uint32"
	FieldUint64  FieldType = "uint64"
	FieldFloat   FieldType = "float"
	FieldDouble  FieldType = "double"
	FieldBool    FieldType = "bool"
	FieldString  FieldType = "string"
	FieldBytes   FieldType = "bytes"
	FieldMessage FieldType = "message"
)

// Sentinel errors returned by the package.
var (
	ErrDuplicateID     = errors.New("dymsg: duplicate type id")
	ErrUnknownTypeID   = errors.New("dymsg: unknown type id")
	ErrFieldNotFound   = errors.New("dymsg: field not found or invalid path")
	ErrIndexOutOfRange = errors.New("dymsg: index out of range")
	ErrTypeMismatch    = errors.New("dymsg: type mismatch")
	ErrMalformedData   = errors.New("dymsg: malformed data")
	ErrTruncated       = errors.New("dymsg: truncated data")
)

// FieldSchema describes one field of a message.
type FieldSchema struct {
	Name     string        // field name, also used as JSON key
	Num      int           // protobuf field number, in [1, 65535]
	Type     FieldType     // field value type
	Repeated bool          // whether the field is an array
	Schema   MessageSchema // inline schema when Type == FieldMessage
}

// MessageSchema describes a message type. The unexported maps are caches
// built by ParseSchema/Register and must not be modified after registration.
type MessageSchema struct {
	TypeID uint16
	Fields []FieldSchema

	fieldByName map[string]int
	fieldByNum  map[int]int
	present     bool
}

func validFieldType(t FieldType) bool {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat,
		FieldDouble, FieldBool, FieldString, FieldBytes, FieldMessage:
		return true
	default:
		return false
	}
}

func schemaPresent(s *MessageSchema) bool {
	if s == nil {
		return false
	}
	return s.present || s.Fields != nil || s.fieldByName != nil || s.fieldByNum != nil
}

func (s *MessageSchema) lookupName(name string) (int, bool) {
	i, ok := s.fieldByName[name]
	return i, ok
}

func (s *MessageSchema) lookupNum(num int) (int, bool) {
	i, ok := s.fieldByNum[num]
	return i, ok
}

// parseSchemaFile mirrors the JSON configuration file format.
type parseSchemaFile struct {
	Types *[]parseTypeDef `json:"types"`
}

type parseTypeDef struct {
	TypeID int             `json:"typeId"`
	Fields []parseFieldDef `json:"fields"`
}

type parseFieldDef struct {
	Name     string          `json:"name"`
	Num      int             `json:"num"`
	Type     string          `json:"type"`
	Repeated bool            `json:"repeated"`
	Schema   *parseSchemaDef `json:"schema"`
}

type parseSchemaDef struct {
	Fields []parseFieldDef `json:"fields"`
}

// ParseSchema parses a JSON schema configuration. Each returned MessageSchema
// represents one top-level message type and can be passed to Register.
func ParseSchema(data []byte) ([]MessageSchema, error) {
	var file parseSchemaFile
	if err := json.Unmarshal(data, &file); err != nil {
		return nil, ErrMalformedData
	}
	if file.Types == nil {
		return nil, ErrMalformedData
	}

	types := *file.Types
	seenTypeIDs := make(map[int]struct{}, len(types))
	schemas := make([]MessageSchema, 0, len(types))
	for _, td := range types {
		if td.TypeID < 1 || td.TypeID > 65535 {
			return nil, ErrMalformedData
		}
		if _, dup := seenTypeIDs[td.TypeID]; dup {
			return nil, ErrMalformedData
		}
		seenTypeIDs[td.TypeID] = struct{}{}

		s := MessageSchema{TypeID: uint16(td.TypeID)}
		fields, err := parseFields(td.Fields)
		if err != nil {
			return nil, ErrMalformedData
		}
		s.Fields = fields
		if err := normalizeSchema(&s, true); err != nil {
			return nil, err
		}
		schemas = append(schemas, s)
	}
	return schemas, nil
}

func parseFields(defs []parseFieldDef) ([]FieldSchema, error) {
	fields := make([]FieldSchema, 0, len(defs))
	names := make(map[string]struct{}, len(defs))
	nums := make(map[int]struct{}, len(defs))
	for _, fd := range defs {
		if fd.Name == "" || containsPathSpecial(fd.Name) {
			return nil, ErrMalformedData
		}
		if fd.Num < 1 || fd.Num > 65535 {
			return nil, ErrMalformedData
		}
		if _, dup := names[fd.Name]; dup {
			return nil, ErrMalformedData
		}
		if _, dup := nums[fd.Num]; dup {
			return nil, ErrMalformedData
		}
		ft := FieldType(fd.Type)
		if !validFieldType(ft) {
			return nil, ErrMalformedData
		}
		fs := FieldSchema{
			Name:     fd.Name,
			Num:      fd.Num,
			Type:     ft,
			Repeated: fd.Repeated,
		}
		if ft == FieldMessage {
			if fd.Schema == nil {
				return nil, ErrMalformedData
			}
			nested, err := parseFields(fd.Schema.Fields)
			if err != nil {
				return nil, err
			}
			fs.Schema = MessageSchema{Fields: nested, present: true}
		} else if fd.Schema != nil {
			return nil, ErrMalformedData
		}
		names[fd.Name] = struct{}{}
		nums[fd.Num] = struct{}{}
		fields = append(fields, fs)
	}
	return fields, nil
}

func containsPathSpecial(name string) bool {
	for i := 0; i < len(name); i++ {
		if name[i] == '.' || name[i] == '[' || name[i] == ']' {
			return true
		}
	}
	return false
}

var registry = struct {
	sync.RWMutex
	byID map[uint16]*MessageSchema
}{
	byID: make(map[uint16]*MessageSchema),
}

// Register registers a top-level message schema under its TypeID. Registering
// the same content again is idempotent. Registering the same TypeID with
// different content returns ErrDuplicateID. Register is safe for concurrent use.
func Register(s MessageSchema) error {
	if s.TypeID < 1 || s.TypeID > 65535 {
		return ErrMalformedData
	}
	if err := normalizeSchema(&s, true); err != nil {
		return err
	}

	registry.Lock()
	defer registry.Unlock()
	old, ok := registry.byID[s.TypeID]
	if ok {
		if schemaEqual(old, &s) {
			return nil
		}
		return ErrDuplicateID
	}
	registry.byID[s.TypeID] = &s
	return nil
}

// New creates an empty Message instance for a registered type ID.
// New is safe for concurrent use.
func New(typeID uint16) (*Message, error) {
	registry.RLock()
	s := registry.byID[typeID]
	registry.RUnlock()
	if s == nil {
		return nil, ErrUnknownTypeID
	}
	return newMessage(s), nil
}

func normalizeSchema(s *MessageSchema, top bool) error {
	if top {
		if s.TypeID < 1 || s.TypeID > 65535 {
			return ErrMalformedData
		}
	} else {
		s.TypeID = 0
	}

	fields := append([]FieldSchema(nil), s.Fields...)
	nameIdx := make(map[string]int, len(fields))
	numIdx := make(map[int]int, len(fields))
	for i := range fields {
		f := &fields[i]
		if f.Name == "" || containsPathSpecial(f.Name) {
			return ErrMalformedData
		}
		if f.Num < 1 || f.Num > 65535 {
			return ErrMalformedData
		}
		if !validFieldType(f.Type) {
			return ErrMalformedData
		}
		if _, dup := nameIdx[f.Name]; dup {
			return ErrMalformedData
		}
		if _, dup := numIdx[f.Num]; dup {
			return ErrMalformedData
		}
		if f.Type == FieldMessage {
			if !schemaPresent(&f.Schema) {
				return ErrMalformedData
			}
			if err := normalizeSchema(&f.Schema, false); err != nil {
				return err
			}
		} else if schemaPresent(&f.Schema) {
			return ErrMalformedData
		}
		nameIdx[f.Name] = i
		numIdx[f.Num] = i
	}
	s.Fields = fields
	s.fieldByName = nameIdx
	s.fieldByNum = numIdx
	return nil
}

func schemaEqual(a, b *MessageSchema) bool {
	if a == nil || b == nil {
		return a == b
	}
	if a.TypeID != b.TypeID || len(a.Fields) != len(b.Fields) {
		return false
	}
	for i := range a.Fields {
		fa := &a.Fields[i]
		fb := &b.Fields[i]
		if fa.Name != fb.Name || fa.Num != fb.Num || fa.Type != fb.Type || fa.Repeated != fb.Repeated {
			return false
		}
		if fa.Type == FieldMessage {
			if !schemaEqual(&fa.Schema, &fb.Schema) {
				return false
			}
		}
	}
	return true
}
