package dymsg

import (
	"math"
	"reflect"
	"strconv"
)

const (
	maxUint32 = ^uint32(0)
	maxInt32  = int32(maxUint32 >> 1)
	minInt32  = -maxInt32 - 1

	maxUint64 = ^uint64(0)
	maxInt64  = int64(maxUint64 >> 1)
	minInt64  = -maxInt64 - 1
)

func convertFieldValue(fs *FieldSchema, value any) (any, error) {
	if fs.Repeated {
		return convertRepeated(fs, value)
	}
	if fs.Type == FieldMessage {
		return convertMessageField(fs, value)
	}
	return convertScalar(fs.Type, value)
}

func convertElement(fs *FieldSchema, value any) (any, error) {
	if fs.Type == FieldMessage {
		return convertMessageField(fs, value)
	}
	return convertScalar(fs.Type, value)
}

func convertMessageField(fs *FieldSchema, value any) (any, error) {
	if isNilValue(value) {
		return nil, ErrTypeMismatch
	}
	msg, ok := value.(*Message)
	if !ok {
		return nil, ErrTypeMismatch
	}
	if !schemaEqual(&fs.Schema, msg.schema) {
		return nil, ErrTypeMismatch
	}
	return cloneMessage(msg), nil
}

func convertRepeated(fs *FieldSchema, value any) (any, error) {
	if isNilValue(value) {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return nil, ErrTypeMismatch
	}
	n := rv.Len()

	switch fs.Type {
	case FieldString:
		out := make([]string, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldString, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(string)
		}
		return out, nil
	case FieldInt32:
		out := make([]int32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldInt32, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(int32)
		}
		return out, nil
	case FieldInt64:
		out := make([]int64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldInt64, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(int64)
		}
		return out, nil
	case FieldUint32:
		out := make([]uint32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldUint32, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(uint32)
		}
		return out, nil
	case FieldUint64:
		out := make([]uint64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldUint64, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(uint64)
		}
		return out, nil
	case FieldFloat:
		out := make([]float32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldFloat, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(float32)
		}
		return out, nil
	case FieldDouble:
		out := make([]float64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldDouble, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(float64)
		}
		return out, nil
	case FieldBool:
		out := make([]bool, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldBool, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.(bool)
		}
		return out, nil
	case FieldBytes:
		out := make([][]byte, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(FieldBytes, rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v.([]byte)
		}
		return out, nil
	case FieldMessage:
		out := make([]*Message, n)
		for i := 0; i < n; i++ {
			ev := rv.Index(i)
			if canBeNil(ev) && ev.IsNil() {
				out[i] = nil
				continue
			}
			msg, ok := ev.Interface().(*Message)
			if !ok {
				return nil, ErrTypeMismatch
			}
			if msg == nil {
				out[i] = nil
				continue
			}
			if !schemaEqual(&fs.Schema, msg.schema) {
				return nil, ErrTypeMismatch
			}
			out[i] = cloneMessage(msg)
		}
		return out, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func canBeNil(rv reflect.Value) bool {
	switch rv.Kind() {
	case reflect.Chan, reflect.Func, reflect.Interface, reflect.Map, reflect.Ptr, reflect.Slice:
		return true
	default:
		return false
	}
}

func convertScalar(t FieldType, value any) (any, error) {
	if isNilValue(value) {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)

	switch t {
	case FieldString:
		if rv.Kind() == reflect.String {
			return rv.String(), nil
		}
		if isBytesValue(rv) {
			return string(rv.Bytes()), nil
		}
		if isNumericKind(rv.Kind()) {
			return numericToString(rv), nil
		}
		return nil, ErrTypeMismatch

	case FieldBytes:
		if isBytesValue(rv) {
			return cloneBytes(rv.Bytes()), nil
		}
		if rv.Kind() == reflect.String {
			return []byte(rv.String()), nil
		}
		return nil, ErrTypeMismatch

	case FieldBool:
		if rv.Kind() == reflect.Bool {
			return rv.Bool(), nil
		}
		return nil, ErrTypeMismatch

	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat, FieldDouble:
		if rv.Kind() == reflect.String {
			return parseNumericString(t, rv.String())
		}
		if !isNumericKind(rv.Kind()) {
			return nil, ErrTypeMismatch
		}
		switch rv.Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return intToTarget(t, rv.Int())
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return uintToTarget(t, rv.Uint())
		case reflect.Float32, reflect.Float64:
			return floatToTarget(t, rv.Float())
		}
		return nil, ErrTypeMismatch

	default:
		return nil, ErrTypeMismatch
	}
}

func parseNumericString(t FieldType, s string) (any, error) {
	switch t {
	case FieldInt32:
		n, err := strconv.ParseInt(s, 10, 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return int32(n), nil
	case FieldInt64:
		n, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return n, nil
	case FieldUint32:
		n, err := strconv.ParseUint(s, 10, 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return uint32(n), nil
	case FieldUint64:
		n, err := strconv.ParseUint(s, 10, 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return n, nil
	case FieldFloat:
		n, err := strconv.ParseFloat(s, 32)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return float32(n), nil
	case FieldDouble:
		n, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return nil, ErrTypeMismatch
		}
		return n, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func numericToString(rv reflect.Value) string {
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(rv.Int(), 10)
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return strconv.FormatUint(rv.Uint(), 10)
	case reflect.Float32:
		return strconv.FormatFloat(rv.Float(), 'g', -1, 32)
	case reflect.Float64:
		return strconv.FormatFloat(rv.Float(), 'g', -1, 64)
	default:
		return ""
	}
}

func intToTarget(t FieldType, x int64) (any, error) {
	switch t {
	case FieldInt32:
		if x < int64(minInt32) || x > int64(maxInt32) {
			return nil, ErrTypeMismatch
		}
		return int32(x), nil
	case FieldInt64:
		return x, nil
	case FieldUint32:
		if x < 0 || uint64(x) > uint64(maxUint32) {
			return nil, ErrTypeMismatch
		}
		return uint32(x), nil
	case FieldUint64:
		if x < 0 {
			return nil, ErrTypeMismatch
		}
		return uint64(x), nil
	case FieldFloat:
		return float32(x), nil
	case FieldDouble:
		return float64(x), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func uintToTarget(t FieldType, x uint64) (any, error) {
	switch t {
	case FieldInt32:
		if x > uint64(maxInt32) {
			return nil, ErrTypeMismatch
		}
		return int32(x), nil
	case FieldInt64:
		if x > uint64(maxInt64) {
			return nil, ErrTypeMismatch
		}
		return int64(x), nil
	case FieldUint32:
		if x > uint64(maxUint32) {
			return nil, ErrTypeMismatch
		}
		return uint32(x), nil
	case FieldUint64:
		return x, nil
	case FieldFloat:
		return float32(x), nil
	case FieldDouble:
		return float64(x), nil
	default:
		return nil, ErrTypeMismatch
	}
}

func floatToTarget(t FieldType, f float64) (any, error) {
	switch t {
	case FieldInt32:
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		tr := math.Trunc(f)
		if tr < float64(minInt32) || tr > float64(maxInt32) {
			return nil, ErrTypeMismatch
		}
		return int32(tr), nil
	case FieldInt64:
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		tr := math.Trunc(f)
		if tr < -9223372036854775808.0 || tr >= 9223372036854775808.0 {
			return nil, ErrTypeMismatch
		}
		return int64(tr), nil
	case FieldUint32:
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		tr := math.Trunc(f)
		if tr < 0 || tr > float64(maxUint32) {
			return nil, ErrTypeMismatch
		}
		return uint32(tr), nil
	case FieldUint64:
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return nil, ErrTypeMismatch
		}
		tr := math.Trunc(f)
		if tr < 0 || tr >= 18446744073709551616.0 {
			return nil, ErrTypeMismatch
		}
		return uint64(tr), nil
	case FieldFloat:
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return float32(f), nil
		}
		if f > math.MaxFloat32 || f < -math.MaxFloat32 {
			return nil, ErrTypeMismatch
		}
		return float32(f), nil
	case FieldDouble:
		return f, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func isNumericKind(k reflect.Kind) bool {
	switch k {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64,
		reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64,
		reflect.Float32, reflect.Float64:
		return true
	default:
		return false
	}
}

func isBytesValue(rv reflect.Value) bool {
	return rv.Kind() == reflect.Slice && rv.Type().Elem().Kind() == reflect.Uint8
}
