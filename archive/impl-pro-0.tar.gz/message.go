package dymsg

import (
	"strconv"
)

type fieldValue struct {
	set  bool
	elem any
}

// Message is a dynamic structured message instance.
type Message struct {
	schema MessageSchema
	fields map[string]*fieldValue
}

func newMessage(s MessageSchema) *Message {
	s.ensureMaps()
	return &Message{schema: s, fields: make(map[string]*fieldValue)}
}

func newMessageWithFields(s MessageSchema, fields map[string]*fieldValue) *Message {
	s.ensureMaps()
	if fields == nil {
		fields = make(map[string]*fieldValue)
	}
	return &Message{schema: s, fields: fields}
}

func (m *Message) ensureSchemaMaps() {
	if m != nil && (m.schema.byName == nil || m.schema.byNum == nil) {
		m.schema.ensureMaps()
	}
}

func (m *Message) ensureFieldsMap() {
	if m != nil && m.fields == nil {
		m.fields = make(map[string]*fieldValue)
	}
}

type pathSeg struct {
	field    string
	index    int
	hasIndex bool
}

func parsePath(path string) ([]pathSeg, error) {
	if path == "" {
		return nil, nil
	}
	segs := make([]pathSeg, 0, 2)
	pos := 0
	for pos < len(path) {
		start := pos
		for pos < len(path) && path[pos] != '.' && path[pos] != '[' {
			pos++
		}
		name := path[start:pos]
		if name == "" {
			return nil, ErrFieldNotFound
		}
		seg := pathSeg{field: name}

		if pos < len(path) && path[pos] == '[' {
			pos++
			digitsStart := pos
			for pos < len(path) && path[pos] >= '0' && path[pos] <= '9' {
				pos++
			}
			if pos == digitsStart {
				return nil, ErrIndexOutOfRange
			}
			if pos >= len(path) || path[pos] != ']' {
				return nil, ErrFieldNotFound
			}
			n, err := strconv.Atoi(path[digitsStart:pos])
			if err != nil {
				return nil, ErrIndexOutOfRange
			}
			seg.index = n
			seg.hasIndex = true
			pos++ // consume ']'
		}

		segs = append(segs, seg)

		if pos < len(path) {
			if path[pos] != '.' {
				return nil, ErrFieldNotFound
			}
			pos++
			if pos == len(path) {
				return nil, ErrFieldNotFound
			}
		}
	}
	return segs, nil
}

// Get returns the value at path. Errors are embedded in the returned Value.
func (m *Message) Get(path string) Value {
	if path == "" {
		return Value{exists: true, set: true, val: m}
	}
	m.ensureSchemaMaps()
	segs, err := parsePath(path)
	if err != nil {
		return Value{err: err}
	}
	return m.getPath(segs)
}

func (m *Message) getPath(segs []pathSeg) Value {
	cur := m
	for i, seg := range segs {
		field, ok := cur.schema.fieldByName(seg.field)
		if !ok {
			return Value{err: ErrFieldNotFound}
		}
		last := i == len(segs)-1

		if seg.hasIndex {
			if !field.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			fv := cur.fields[field.Name]
			if fv == nil || !fv.set {
				return Value{err: ErrIndexOutOfRange}
			}
			list := fv.elem.([]any)
			if seg.index >= len(list) {
				return Value{err: ErrIndexOutOfRange}
			}
			elem := list[seg.index]
			if last {
				return Value{exists: true, set: true, val: elem}
			}
			if field.Type != FieldMessage {
				return Value{err: ErrFieldNotFound}
			}
			child, _ := elem.(*Message)
			if child == nil {
				return schemaOnlyGet(field.Schema, segs[i+1:])
			}
			cur = child
			continue
		}

		if last {
			fv := cur.fields[field.Name]
			return valueFromField(field, fv)
		}

		if field.Repeated {
			return Value{err: ErrFieldNotFound}
		}
		if field.Type != FieldMessage {
			return Value{err: ErrFieldNotFound}
		}

		fv := cur.fields[field.Name]
		if fv == nil || !fv.set || fv.elem == nil {
			return schemaOnlyGet(field.Schema, segs[i+1:])
		}
		child, ok := fv.elem.(*Message)
		if !ok || child == nil {
			return schemaOnlyGet(field.Schema, segs[i+1:])
		}
		cur = child
	}
	return Value{err: ErrFieldNotFound}
}

func schemaOnlyGet(schema MessageSchema, segs []pathSeg) Value {
	schema.ensureMaps()
	curSchema := schema
	for i, seg := range segs {
		field, ok := curSchema.fieldByName(seg.field)
		if !ok {
			return Value{err: ErrFieldNotFound}
		}
		last := i == len(segs)-1
		if seg.hasIndex {
			if !field.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			return Value{err: ErrIndexOutOfRange}
		}
		if last {
			return Value{exists: true, set: false}
		}
		if field.Repeated {
			return Value{err: ErrFieldNotFound}
		}
		if field.Type != FieldMessage {
			return Value{err: ErrFieldNotFound}
		}
		curSchema = field.Schema
	}
	return Value{err: ErrFieldNotFound}
}

func validatePathSchema(schema MessageSchema, segs []pathSeg) error {
	schema.ensureMaps()
	curSchema := schema
	for i, seg := range segs {
		field, ok := curSchema.fieldByName(seg.field)
		if !ok {
			return ErrFieldNotFound
		}
		last := i == len(segs)-1
		if seg.hasIndex {
			if !field.Repeated {
				return ErrFieldNotFound
			}
			if last {
				return nil
			}
			if field.Type != FieldMessage {
				return ErrFieldNotFound
			}
			curSchema = field.Schema
			continue
		}
		if last {
			return nil
		}
		if field.Repeated {
			return ErrFieldNotFound
		}
		if field.Type != FieldMessage {
			return ErrFieldNotFound
		}
		curSchema = field.Schema
	}
	return nil
}

func valueFromField(field FieldSchema, fv *fieldValue) Value {
	if fv == nil || !fv.set {
		return Value{exists: true, set: false}
	}
	if field.Repeated {
		list := fv.elem.([]any)
		return Value{exists: true, set: true, list: list, val: typedSlice(field, list)}
	}
	return Value{exists: true, set: true, val: fv.elem}
}

// Set assigns value to path. The value is deep-copied.
func (m *Message) Set(path string, value any) error {
	if path == "" {
		if value == nil || isTypedNilMessage(value) {
			m.fields = make(map[string]*fieldValue)
			return nil
		}
		src, ok := value.(*Message)
		if !ok {
			return ErrTypeMismatch
		}
		if src == nil {
			m.fields = make(map[string]*fieldValue)
			return nil
		}
		if !schemaEqual(m.schema, src.schema) {
			return ErrTypeMismatch
		}
		m.fields = cloneFields(src.fields)
		return nil
	}

	m.ensureSchemaMaps()
	m.ensureFieldsMap()
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	if value == nil || isTypedNilMessage(value) {
		return m.clearPath(segs)
	}
	return m.setPath(segs, value)
}

func (m *Message) setPath(segs []pathSeg, value any) error {
	cur := m
	for i := 0; i < len(segs)-1; i++ {
		seg := segs[i]
		field, ok := cur.schema.fieldByName(seg.field)
		if !ok {
			return ErrFieldNotFound
		}
		if seg.hasIndex {
			if !field.Repeated {
				return ErrFieldNotFound
			}
			fv := cur.fields[field.Name]
			if fv == nil || !fv.set {
				return ErrIndexOutOfRange
			}
			list := fv.elem.([]any)
			if seg.index >= len(list) {
				return ErrIndexOutOfRange
			}
			if field.Type != FieldMessage {
				return ErrFieldNotFound
			}
			child, _ := list[seg.index].(*Message)
			if child == nil {
				child = newMessage(field.Schema)
				list[seg.index] = child
			}
			cur = child
			continue
		}

		if field.Repeated {
			return ErrFieldNotFound
		}
		if field.Type != FieldMessage {
			return ErrFieldNotFound
		}

		fv := cur.fields[field.Name]
		if fv == nil {
			fv = &fieldValue{set: true, elem: newMessage(field.Schema)}
			cur.fields[field.Name] = fv
		} else if !fv.set || fv.elem == nil {
			fv.set = true
			fv.elem = newMessage(field.Schema)
		}
		child, ok := fv.elem.(*Message)
		if !ok || child == nil {
			child = newMessage(field.Schema)
			fv.elem = child
		}
		cur = child
	}

	seg := segs[len(segs)-1]
	field, ok := cur.schema.fieldByName(seg.field)
	if !ok {
		return ErrFieldNotFound
	}

	if seg.hasIndex {
		if !field.Repeated {
			return ErrFieldNotFound
		}
		fv := cur.fields[field.Name]
		if fv == nil || !fv.set {
			return ErrIndexOutOfRange
		}
		list := fv.elem.([]any)
		if seg.index >= len(list) {
			return ErrIndexOutOfRange
		}
		elem, err := convertElement(field, value)
		if err != nil {
			return err
		}
		list[seg.index] = elem
		return nil
	}

	if field.Repeated {
		list, err := convertRepeatedSlice(field, value)
		if err != nil {
			return err
		}
		fv := cur.fields[field.Name]
		if fv == nil {
			fv = &fieldValue{}
			cur.fields[field.Name] = fv
		}
		fv.set = true
		fv.elem = list
		return nil
	}

	elem, err := convertScalar(field, value)
	if err != nil {
		return err
	}
	fv := cur.fields[field.Name]
	if fv == nil {
		fv = &fieldValue{}
		cur.fields[field.Name] = fv
	}
	fv.set = true
	fv.elem = elem
	return nil
}

// Append appends an element to a repeated field.
func (m *Message) Append(path string, value any) error {
	m.ensureSchemaMaps()
	m.ensureFieldsMap()
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return ErrFieldNotFound
	}

	cur := m
	for i := 0; i < len(segs)-1; i++ {
		seg := segs[i]
		field, ok := cur.schema.fieldByName(seg.field)
		if !ok {
			return ErrFieldNotFound
		}
		if seg.hasIndex {
			if !field.Repeated {
				return ErrFieldNotFound
			}
			fv := cur.fields[field.Name]
			if fv == nil || !fv.set {
				return ErrIndexOutOfRange
			}
			list := fv.elem.([]any)
			if seg.index >= len(list) {
				return ErrIndexOutOfRange
			}
			if field.Type != FieldMessage {
				return ErrFieldNotFound
			}
			child, _ := list[seg.index].(*Message)
			if child == nil {
				child = newMessage(field.Schema)
				list[seg.index] = child
			}
			cur = child
			continue
		}

		if field.Repeated {
			return ErrFieldNotFound
		}
		if field.Type != FieldMessage {
			return ErrFieldNotFound
		}
		fv := cur.fields[field.Name]
		if fv == nil {
			fv = &fieldValue{set: true, elem: newMessage(field.Schema)}
			cur.fields[field.Name] = fv
		} else if !fv.set || fv.elem == nil {
			fv.set = true
			fv.elem = newMessage(field.Schema)
		}
		child, ok := fv.elem.(*Message)
		if !ok || child == nil {
			child = newMessage(field.Schema)
			fv.elem = child
		}
		cur = child
	}

	seg := segs[len(segs)-1]
	if seg.hasIndex {
		return ErrFieldNotFound
	}
	field, ok := cur.schema.fieldByName(seg.field)
	if !ok {
		return ErrFieldNotFound
	}
	if !field.Repeated {
		return ErrTypeMismatch
	}

	elem, err := convertElement(field, value)
	if err != nil {
		return err
	}
	fv := cur.fields[field.Name]
	if fv == nil {
		fv = &fieldValue{set: true, elem: []any{}}
		cur.fields[field.Name] = fv
	} else if !fv.set {
		fv.set = true
		fv.elem = []any{}
	}
	list := fv.elem.([]any)
	fv.elem = append(list, elem)
	return nil
}

// Clear marks path as unset. Clearing an already-unset field is idempotent.
func (m *Message) Clear(path string) error {
	if path == "" {
		m.fields = make(map[string]*fieldValue)
		return nil
	}
	m.ensureSchemaMaps()
	m.ensureFieldsMap()
	segs, err := parsePath(path)
	if err != nil {
		return err
	}
	return m.clearPath(segs)
}

func (m *Message) clearPath(segs []pathSeg) error {
	cur := m
	for i, seg := range segs {
		field, ok := cur.schema.fieldByName(seg.field)
		if !ok {
			return ErrFieldNotFound
		}
		last := i == len(segs)-1

		if seg.hasIndex {
			if !field.Repeated {
				return ErrFieldNotFound
			}
			fv := cur.fields[field.Name]
			if fv == nil || !fv.set {
				// Clearing an element of an absent/unset repeated field is a no-op.
				if err := validatePathSchema(field.Schema, segs[i+1:]); err != nil {
					return err
				}
				return nil
			}
			list := fv.elem.([]any)
			if seg.index >= len(list) {
				if err := validatePathSchema(field.Schema, segs[i+1:]); err != nil {
					return err
				}
				return nil
			}
			if last {
				list[seg.index] = zeroValueForType(field.Type)
				return nil
			}
			if field.Type != FieldMessage {
				return ErrFieldNotFound
			}
			child, _ := list[seg.index].(*Message)
			if child == nil {
				if err := validatePathSchema(field.Schema, segs[i+1:]); err != nil {
					return err
				}
				return nil
			}
			cur = child
			continue
		}

		fv := cur.fields[field.Name]
		if last {
			if fv != nil {
				fv.set = false
				fv.elem = nil
			}
			return nil
		}

		if field.Repeated {
			return ErrFieldNotFound
		}
		if field.Type != FieldMessage {
			return ErrFieldNotFound
		}
		if fv == nil || !fv.set || fv.elem == nil {
			if err := validatePathSchema(field.Schema, segs[i+1:]); err != nil {
				return err
			}
			return nil
		}
		child, ok := fv.elem.(*Message)
		if !ok || child == nil {
			if err := validatePathSchema(field.Schema, segs[i+1:]); err != nil {
				return err
			}
			return nil
		}
		cur = child
	}
	return nil
}

// Has reports whether path exists and is set.
func (m *Message) Has(path string) bool {
	v := m.Get(path)
	return v.Err() == nil && v.Exists() && v.IsSet()
}

// SetFields returns the names of set top-level fields in schema declaration
// order.
func (m *Message) SetFields() []string {
	if m == nil {
		return nil
	}
	names := make([]string, 0, len(m.fields))
	for _, f := range m.schema.fields {
		if fv := m.fields[f.Name]; fv != nil && fv.set {
			names = append(names, f.Name)
		}
	}
	return names
}

func zeroValueForType(t FieldType) any {
	switch t {
	case FieldInt32:
		return int32(0)
	case FieldInt64:
		return int64(0)
	case FieldUint32:
		return uint32(0)
	case FieldUint64:
		return uint64(0)
	case FieldFloat:
		return float32(0)
	case FieldDouble:
		return float64(0)
	case FieldBool:
		return false
	case FieldString:
		return ""
	case FieldBytes:
		return []byte(nil)
	case FieldMessage:
		return nil
	default:
		return nil
	}
}

// cloneFields deep-copies all fields.
func cloneFields(src map[string]*fieldValue) map[string]*fieldValue {
	if src == nil {
		return make(map[string]*fieldValue)
	}
	dst := make(map[string]*fieldValue, len(src))
	for name, fv := range src {
		if fv == nil || !fv.set {
			continue
		}
		nf := &fieldValue{set: true}
		nf.elem = cloneStoredValue(fv.elem)
		dst[name] = nf
	}
	return dst
}

func cloneStoredValue(v any) any {
	switch x := v.(type) {
	case []any:
		out := make([]any, len(x))
		for i, e := range x {
			out[i] = cloneElementValue(e)
		}
		return out
	case []byte:
		return append([]byte(nil), x...)
	case *Message:
		return cloneMessage(x)
	default:
		return x
	}
}

func cloneElementValue(e any) any {
	switch x := e.(type) {
	case []byte:
		return append([]byte(nil), x...)
	case *Message:
		if x == nil {
			return nil
		}
		return cloneMessage(x)
	default:
		return x
	}
}

func cloneMessage(m *Message) *Message {
	if m == nil {
		return nil
	}
	return newMessageWithFields(m.schema, cloneFields(m.fields))
}
