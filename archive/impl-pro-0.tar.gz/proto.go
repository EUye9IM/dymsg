package dymsg

import (
	"encoding/binary"
	"math"
)

const (
	wireVarint          = 0
	wireFixed64         = 1
	wireLengthDelimited = 2
	wireFixed32         = 5
)

// EncodeProto encodes the message using the protobuf wire format subset
// described by the package specification.
func (m *Message) EncodeProto() ([]byte, error) {
	if m == nil {
		return nil, nil
	}
	buf := make([]byte, 0, 64)
	for _, f := range m.schema.fields {
		fv := m.fields[f.Name]
		if fv == nil || !fv.set {
			continue
		}
		if !f.Repeated && f.Type == FieldMessage && fv.elem == nil {
			continue
		}
		if !f.Repeated {
			var err error
			buf, err = appendProtoSingle(buf, f, fv.elem)
			if err != nil {
				return nil, err
			}
			continue
		}

		list := fv.elem.([]any)
		if len(list) == 0 {
			continue
		}
		if isPackedScalar(f.Type) {
			content, err := encodePackedContent(f.Type, list)
			if err != nil {
				return nil, err
			}
			buf = appendProtoTag(buf, f.Num, wireLengthDelimited)
			buf = appendVarint(buf, uint64(len(content)))
			buf = append(buf, content...)
		} else {
			for _, elem := range list {
				if f.Type == FieldMessage && elem == nil {
					continue
				}
				var err error
				buf, err = appendProtoSingle(buf, f, elem)
				if err != nil {
					return nil, err
				}
			}
		}
	}
	return buf, nil
}

func appendProtoSingle(buf []byte, f FieldSchema, val any) ([]byte, error) {
	switch f.Type {
	case FieldInt32:
		v, _ := val.(int32)
		buf = appendProtoTag(buf, f.Num, wireVarint)
		buf = appendVarint(buf, uint64(int64(v)))
		return buf, nil
	case FieldInt64:
		v, _ := val.(int64)
		buf = appendProtoTag(buf, f.Num, wireVarint)
		buf = appendVarint(buf, uint64(v))
		return buf, nil
	case FieldUint32:
		v, _ := val.(uint32)
		buf = appendProtoTag(buf, f.Num, wireVarint)
		buf = appendVarint(buf, uint64(v))
		return buf, nil
	case FieldUint64:
		v, _ := val.(uint64)
		buf = appendProtoTag(buf, f.Num, wireVarint)
		buf = appendVarint(buf, v)
		return buf, nil
	case FieldBool:
		v, _ := val.(bool)
		buf = appendProtoTag(buf, f.Num, wireVarint)
		if v {
			buf = appendVarint(buf, 1)
		} else {
			buf = appendVarint(buf, 0)
		}
		return buf, nil
	case FieldFloat:
		v, _ := val.(float32)
		buf = appendProtoTag(buf, f.Num, wireFixed32)
		var tmp [4]byte
		binary.LittleEndian.PutUint32(tmp[:], math.Float32bits(v))
		buf = append(buf, tmp[:]...)
		return buf, nil
	case FieldDouble:
		v, _ := val.(float64)
		buf = appendProtoTag(buf, f.Num, wireFixed64)
		var tmp [8]byte
		binary.LittleEndian.PutUint64(tmp[:], math.Float64bits(v))
		buf = append(buf, tmp[:]...)
		return buf, nil
	case FieldString:
		v, _ := val.(string)
		buf = appendProtoTag(buf, f.Num, wireLengthDelimited)
		buf = appendVarint(buf, uint64(len(v)))
		buf = append(buf, v...)
		return buf, nil
	case FieldBytes:
		v, _ := val.([]byte)
		buf = appendProtoTag(buf, f.Num, wireLengthDelimited)
		buf = appendVarint(buf, uint64(len(v)))
		buf = append(buf, v...)
		return buf, nil
	case FieldMessage:
		msg, _ := val.(*Message)
		if msg == nil {
			return buf, nil
		}
		child, err := msg.EncodeProto()
		if err != nil {
			return nil, err
		}
		buf = appendProtoTag(buf, f.Num, wireLengthDelimited)
		buf = appendVarint(buf, uint64(len(child)))
		buf = append(buf, child...)
		return buf, nil
	default:
		return nil, ErrMalformedData
	}
}

func encodePackedContent(ft FieldType, list []any) ([]byte, error) {
	buf := make([]byte, 0, len(list)*4)
	for _, elem := range list {
		switch ft {
		case FieldInt32:
			v, _ := elem.(int32)
			buf = appendVarint(buf, uint64(int64(v)))
		case FieldInt64:
			v, _ := elem.(int64)
			buf = appendVarint(buf, uint64(v))
		case FieldUint32:
			v, _ := elem.(uint32)
			buf = appendVarint(buf, uint64(v))
		case FieldUint64:
			v, _ := elem.(uint64)
			buf = appendVarint(buf, v)
		case FieldBool:
			v, _ := elem.(bool)
			if v {
				buf = appendVarint(buf, 1)
			} else {
				buf = appendVarint(buf, 0)
			}
		case FieldFloat:
			v, _ := elem.(float32)
			var tmp [4]byte
			binary.LittleEndian.PutUint32(tmp[:], math.Float32bits(v))
			buf = append(buf, tmp[:]...)
		case FieldDouble:
			v, _ := elem.(float64)
			var tmp [8]byte
			binary.LittleEndian.PutUint64(tmp[:], math.Float64bits(v))
			buf = append(buf, tmp[:]...)
		default:
			return nil, ErrMalformedData
		}
	}
	return buf, nil
}

// DecodeProto replaces the message contents with the supplied protobuf wire
// data.
func (m *Message) DecodeProto(data []byte) error {
	if m == nil {
		return ErrMalformedData
	}
	m.schema.ensureMaps()
	fields := make(map[string]*fieldValue)
	pos := 0
	for pos < len(data) {
		key, err := readVarint(data, &pos)
		if err != nil {
			return err
		}
		fieldNum := int(key >> 3)
		wire := int(key & 0x7)
		if fieldNum == 0 {
			return ErrMalformedData
		}
		if wire == 6 || wire == 7 || wire == 3 || wire == 4 {
			return ErrMalformedData
		}

		field, known := m.schema.fieldByNum(fieldNum)
		if !known {
			if err := skipProtoField(data, &pos, wire); err != nil {
				return err
			}
			continue
		}
		if err := decodeProtoField(fields, field, wire, data, &pos); err != nil {
			return err
		}
	}
	m.fields = fields
	return nil
}

func skipProtoField(data []byte, pos *int, wire int) error {
	switch wire {
	case wireVarint:
		_, err := readVarint(data, pos)
		return err
	case wireFixed64:
		if *pos+8 > len(data) {
			return ErrTruncated
		}
		*pos += 8
		return nil
	case wireLengthDelimited:
		length, err := readVarint(data, pos)
		if err != nil {
			return err
		}
		if length > uint64(len(data)-*pos) {
			return ErrTruncated
		}
		*pos += int(length)
		return nil
	case wireFixed32:
		if *pos+4 > len(data) {
			return ErrTruncated
		}
		*pos += 4
		return nil
	default:
		return ErrMalformedData
	}
}

func decodeProtoField(fields map[string]*fieldValue, f FieldSchema, wire int, data []byte, pos *int) error {
	if f.Repeated && isPackedScalar(f.Type) && wire == wireLengthDelimited {
		length, err := readVarint(data, pos)
		if err != nil {
			return err
		}
		if length > uint64(len(data)-*pos) {
			return ErrTruncated
		}
		content := data[*pos : *pos+int(length)]
		*pos += int(length)
		elems, err := decodePackedScalars(f.Type, content)
		if err != nil {
			return err
		}
		appendRepeatedValues(fields, f, elems)
		return nil
	}

	expectedWire := protoWireType(f.Type)
	if wire != expectedWire {
		return ErrMalformedData
	}
	elem, err := decodeSingleValue(f, wire, data, pos)
	if err != nil {
		return err
	}
	if f.Repeated {
		appendRepeatedValues(fields, f, []any{elem})
	} else {
		fields[f.Name] = &fieldValue{set: true, elem: elem}
	}
	return nil
}

func decodeSingleValue(f FieldSchema, wire int, data []byte, pos *int) (any, error) {
	switch f.Type {
	case FieldInt32:
		v, err := readVarint(data, pos)
		if err != nil {
			return nil, err
		}
		return int32(v), nil
	case FieldInt64:
		v, err := readVarint(data, pos)
		if err != nil {
			return nil, err
		}
		return int64(v), nil
	case FieldUint32:
		v, err := readVarint(data, pos)
		if err != nil {
			return nil, err
		}
		return uint32(v), nil
	case FieldUint64:
		v, err := readVarint(data, pos)
		if err != nil {
			return nil, err
		}
		return v, nil
	case FieldBool:
		v, err := readVarint(data, pos)
		if err != nil {
			return nil, err
		}
		return v != 0, nil
	case FieldFloat:
		if *pos+4 > len(data) {
			return nil, ErrTruncated
		}
		v := binary.LittleEndian.Uint32(data[*pos : *pos+4])
		*pos += 4
		return math.Float32frombits(v), nil
	case FieldDouble:
		if *pos+8 > len(data) {
			return nil, ErrTruncated
		}
		v := binary.LittleEndian.Uint64(data[*pos : *pos+8])
		*pos += 8
		return math.Float64frombits(v), nil
	case FieldString:
		content, err := readLengthDelimited(data, pos)
		if err != nil {
			return nil, err
		}
		return string(content), nil
	case FieldBytes:
		content, err := readLengthDelimited(data, pos)
		if err != nil {
			return nil, err
		}
		return append([]byte(nil), content...), nil
	case FieldMessage:
		content, err := readLengthDelimited(data, pos)
		if err != nil {
			return nil, err
		}
		child, err := decodeProtoMessage(f.Schema, content)
		if err != nil {
			return nil, err
		}
		return child, nil
	default:
		return nil, ErrMalformedData
	}
}

func decodePackedScalars(ft FieldType, content []byte) ([]any, error) {
	var elems []any
	switch ft {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		pos := 0
		for pos < len(content) {
			v, err := readVarint(content, &pos)
			if err != nil {
				return nil, err
			}
			switch ft {
			case FieldInt32:
				elems = append(elems, int32(v))
			case FieldInt64:
				elems = append(elems, int64(v))
			case FieldUint32:
				elems = append(elems, uint32(v))
			case FieldUint64:
				elems = append(elems, v)
			case FieldBool:
				elems = append(elems, v != 0)
			}
		}
		return elems, nil
	case FieldFloat:
		if len(content)%4 != 0 {
			return nil, ErrMalformedData
		}
		elems = make([]any, 0, len(content)/4)
		for i := 0; i < len(content); i += 4 {
			bits := binary.LittleEndian.Uint32(content[i : i+4])
			elems = append(elems, math.Float32frombits(bits))
		}
		return elems, nil
	case FieldDouble:
		if len(content)%8 != 0 {
			return nil, ErrMalformedData
		}
		elems = make([]any, 0, len(content)/8)
		for i := 0; i < len(content); i += 8 {
			bits := binary.LittleEndian.Uint64(content[i : i+8])
			elems = append(elems, math.Float64frombits(bits))
		}
		return elems, nil
	default:
		return nil, ErrMalformedData
	}
}

func appendRepeatedValues(fields map[string]*fieldValue, f FieldSchema, elems []any) {
	fv := fields[f.Name]
	if fv == nil {
		fv = &fieldValue{set: true, elem: []any{}}
		fields[f.Name] = fv
	} else if !fv.set {
		fv.set = true
		fv.elem = []any{}
	}
	list := fv.elem.([]any)
	fv.elem = append(list, elems...)
}

func readLengthDelimited(data []byte, pos *int) ([]byte, error) {
	length, err := readVarint(data, pos)
	if err != nil {
		return nil, err
	}
	if length > uint64(len(data)-*pos) {
		return nil, ErrTruncated
	}
	content := data[*pos : *pos+int(length)]
	*pos += int(length)
	return content, nil
}

func decodeProtoMessage(schema MessageSchema, data []byte) (*Message, error) {
	msg := newMessage(schema)
	if err := msg.DecodeProto(data); err != nil {
		return nil, err
	}
	return msg, nil
}

func appendProtoTag(buf []byte, fieldNum int, wire int) []byte {
	return appendVarint(buf, uint64(fieldNum<<3)|uint64(wire))
}

func appendVarint(buf []byte, v uint64) []byte {
	for v >= 0x80 {
		buf = append(buf, byte(v)|0x80)
		v >>= 7
	}
	return append(buf, byte(v))
}

func readVarint(data []byte, pos *int) (uint64, error) {
	var v uint64
	for shift := uint(0); shift < 64; shift += 7 {
		if *pos >= len(data) {
			return 0, ErrTruncated
		}
		b := data[*pos]
		*pos++
		if shift == 63 && (b&0xfe) != 0 {
			return 0, ErrMalformedData
		}
		v |= uint64(b&0x7f) << shift
		if b < 0x80 {
			return v, nil
		}
	}
	return 0, ErrMalformedData
}

func protoWireType(t FieldType) int {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		return wireVarint
	case FieldFloat:
		return wireFixed32
	case FieldDouble:
		return wireFixed64
	case FieldString, FieldBytes, FieldMessage:
		return wireLengthDelimited
	default:
		return -1
	}
}

func isPackedScalar(t FieldType) bool {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool, FieldFloat, FieldDouble:
		return true
	default:
		return false
	}
}
