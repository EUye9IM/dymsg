package dymsg

import (
	"math"
	"reflect"
	"strconv"
)

func convertScalar(f FieldSchema, value any) (any, error) {
	if value == nil {
		return nil, ErrTypeMismatch
	}
	switch f.Type {
	case FieldMessage:
		msg, ok := value.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if msg == nil {
			return nil, ErrTypeMismatch
		}
		if !schemaEqual(f.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		return cloneMessage(msg), nil
	case FieldString:
		s, err := toString(value)
		if err != nil {
			return nil, err
		}
		return s, nil
	case FieldBytes:
		b, err := toBytes(value)
		if err != nil {
			return nil, err
		}
		return append([]byte(nil), b...), nil
	case FieldInt32:
		return toInt32(value)
	case FieldInt64:
		return toInt64Value(value)
	case FieldUint32:
		return toUint32(value)
	case FieldUint64:
		return toUint64Value(value)
	case FieldFloat:
		return toFloat32(value)
	case FieldDouble:
		return toFloat64Value(value)
	case FieldBool:
		return toBool(value)
	default:
		return nil, ErrTypeMismatch
	}
}

func convertElement(f FieldSchema, value any) (any, error) {
	if f.Type == FieldMessage {
		if value == nil || isTypedNilMessage(value) {
			return nil, nil
		}
		msg, ok := value.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if !schemaEqual(f.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		return cloneMessage(msg), nil
	}
	return convertScalar(f, value)
}

func isTypedNilMessage(value any) bool {
	rv := reflect.ValueOf(value)
	return rv.Kind() == reflect.Ptr && rv.IsNil() && rv.Type().Elem() == reflect.TypeOf(Message{})
}

func convertRepeatedSlice(f FieldSchema, value any) ([]any, error) {
	switch f.Type {
	case FieldInt32:
		s, ok := value.([]int32)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldInt64:
		s, ok := value.([]int64)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldUint32:
		s, ok := value.([]uint32)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldUint64:
		s, ok := value.([]uint64)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldFloat:
		s, ok := value.([]float32)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldDouble:
		s, ok := value.([]float64)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldBool:
		s, ok := value.([]bool)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldString:
		s, ok := value.([]string)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = v
		}
		return out, nil
	case FieldBytes:
		s, ok := value.([][]byte)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, v := range s {
			out[i] = append([]byte(nil), v...)
		}
		return out, nil
	case FieldMessage:
		s, ok := value.([]*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		out := make([]any, len(s))
		for i, m := range s {
			if m == nil {
				out[i] = nil
				continue
			}
			if !schemaEqual(f.Schema, m.schema) {
				return nil, ErrTypeMismatch
			}
			out[i] = cloneMessage(m)
		}
		return out, nil
	default:
		return nil, ErrTypeMismatch
	}
}

func toString(value any) (string, error) {
	if value == nil {
		return "", ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)
	switch rv.Kind() {
	case reflect.String:
		return rv.String(), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return string(rv.Bytes()), nil
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(rv.Int(), 10), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return strconv.FormatUint(rv.Uint(), 10), nil
	case reflect.Float32, reflect.Float64:
		return strconv.FormatFloat(rv.Float(), 'g', -1, rv.Type().Bits()), nil
	}
	return "", ErrTypeMismatch
}

func toBytes(value any) ([]byte, error) {
	if value == nil {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)
	switch rv.Kind() {
	case reflect.String:
		return []byte(rv.String()), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return append([]byte(nil), rv.Bytes()...), nil
		}
	}
	return nil, ErrTypeMismatch
}

func toBool(value any) (bool, error) {
	if value == nil {
		return false, ErrTypeMismatch
	}
	rv := reflect.ValueOf(value)
	if rv.Kind() == reflect.Bool {
		return rv.Bool(), nil
	}
	return false, ErrTypeMismatch
}

func toInt32(value any) (int32, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		n, err := strconv.ParseInt(s, 10, 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return int32(n), nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) || f < -2147483648.0 || f >= 2147483648.0 {
			return 0, ErrTypeMismatch
		}
		return int32(math.Trunc(f)), nil
	}
	if isIntKind(rv.Kind()) {
		i := rv.Int()
		if i < math.MinInt32 || i > math.MaxInt32 {
			return 0, ErrTypeMismatch
		}
		return int32(i), nil
	}
	if isUintKind(rv.Kind()) {
		u := rv.Uint()
		if u > math.MaxInt32 {
			return 0, ErrTypeMismatch
		}
		return int32(u), nil
	}
	return 0, ErrTypeMismatch
}

func toInt64Value(value any) (int64, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		n, err := strconv.ParseInt(s, 10, 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return n, nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) || f < -9223372036854775808.0 || f >= 9223372036854775808.0 {
			return 0, ErrTypeMismatch
		}
		return int64(math.Trunc(f)), nil
	}
	if isIntKind(rv.Kind()) {
		return rv.Int(), nil
	}
	if isUintKind(rv.Kind()) {
		u := rv.Uint()
		if u > math.MaxInt64 {
			return 0, ErrTypeMismatch
		}
		return int64(u), nil
	}
	return 0, ErrTypeMismatch
}

func toUint32(value any) (uint32, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		n, err := strconv.ParseUint(s, 10, 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return uint32(n), nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) || f < 0 || f >= 4294967296.0 {
			return 0, ErrTypeMismatch
		}
		return uint32(math.Trunc(f)), nil
	}
	if isIntKind(rv.Kind()) {
		i := rv.Int()
		if i < 0 || uint64(i) > math.MaxUint32 {
			return 0, ErrTypeMismatch
		}
		return uint32(i), nil
	}
	if isUintKind(rv.Kind()) {
		u := rv.Uint()
		if u > math.MaxUint32 {
			return 0, ErrTypeMismatch
		}
		return uint32(u), nil
	}
	return 0, ErrTypeMismatch
}

func toUint64Value(value any) (uint64, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		n, err := strconv.ParseUint(s, 10, 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return n, nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) || f < 0 || f >= 18446744073709551616.0 {
			return 0, ErrTypeMismatch
		}
		return uint64(math.Trunc(f)), nil
	}
	if isIntKind(rv.Kind()) {
		i := rv.Int()
		if i < 0 {
			return 0, ErrTypeMismatch
		}
		return uint64(i), nil
	}
	if isUintKind(rv.Kind()) {
		return rv.Uint(), nil
	}
	return 0, ErrTypeMismatch
}

func toFloat32(value any) (float32, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		f, err := strconv.ParseFloat(s, 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return float32(f), nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		f := rv.Float()
		out := float32(f)
		if math.IsInf(float64(out), 0) && !math.IsInf(f, 0) {
			return 0, ErrTypeMismatch
		}
		return out, nil
	}
	if isIntKind(rv.Kind()) {
		f := float64(rv.Int())
		out := float32(f)
		if math.IsInf(float64(out), 0) {
			return 0, ErrTypeMismatch
		}
		return out, nil
	}
	if isUintKind(rv.Kind()) {
		f := float64(rv.Uint())
		out := float32(f)
		if math.IsInf(float64(out), 0) {
			return 0, ErrTypeMismatch
		}
		return out, nil
	}
	return 0, ErrTypeMismatch
}

func toFloat64Value(value any) (float64, error) {
	if value == nil {
		return 0, ErrTypeMismatch
	}
	if s, ok := reflectString(value); ok {
		f, err := strconv.ParseFloat(s, 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return f, nil
	}
	rv := reflect.ValueOf(value)
	if isFloatKind(rv.Kind()) {
		return rv.Float(), nil
	}
	if isIntKind(rv.Kind()) {
		return float64(rv.Int()), nil
	}
	if isUintKind(rv.Kind()) {
		return float64(rv.Uint()), nil
	}
	return 0, ErrTypeMismatch
}

func reflectString(value any) (string, bool) {
	rv := reflect.ValueOf(value)
	if rv.Kind() == reflect.String {
		return rv.String(), true
	}
	return "", false
}

func isIntKind(k reflect.Kind) bool {
	switch k {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return true
	default:
		return false
	}
}

func isUintKind(k reflect.Kind) bool {
	switch k {
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return true
	default:
		return false
	}
}

func isFloatKind(k reflect.Kind) bool {
	return k == reflect.Float32 || k == reflect.Float64
}
