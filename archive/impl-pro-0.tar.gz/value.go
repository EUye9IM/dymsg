package dymsg

// Value is the result of Message.Get. It carries value, presence, and error
// state for a field or repeated element.
type Value struct {
	exists bool
	set    bool
	err    error
	val    any
	list   []any
}

// Exists reports whether path is valid and the field/element exists.
func (v Value) Exists() bool { return v.exists }

// IsSet reports whether the field/element is set.
func (v Value) IsSet() bool { return v.set }

// Err returns the path lookup error, if any.
func (v Value) Err() error { return v.err }

// Any returns the native value: scalar types, *Message, or a typed slice for
// repeated fields. It returns nil for unset or nonexistent values.
func (v Value) Any() any {
	if v.err != nil || !v.exists || !v.set {
		return nil
	}
	return v.val
}

func (v Value) String() string {
	if v.err != nil || !v.exists || !v.set {
		return ""
	}
	s, _ := v.val.(string)
	return s
}

func (v Value) Int32() int32 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(int32)
	return n
}

func (v Value) Int64() int64 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(int64)
	return n
}

func (v Value) Uint32() uint32 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(uint32)
	return n
}

func (v Value) Uint64() uint64 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(uint64)
	return n
}

func (v Value) Float32() float32 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(float32)
	return n
}

func (v Value) Float64() float64 {
	if v.err != nil || !v.exists || !v.set {
		return 0
	}
	n, _ := v.val.(float64)
	return n
}

func (v Value) Bool() bool {
	if v.err != nil || !v.exists || !v.set {
		return false
	}
	b, _ := v.val.(bool)
	return b
}

func (v Value) Bytes() []byte {
	if v.err != nil || !v.exists || !v.set {
		return nil
	}
	b, _ := v.val.([]byte)
	return b
}

func (v Value) Message() *Message {
	if v.err != nil || !v.exists || !v.set {
		return nil
	}
	m, _ := v.val.(*Message)
	return m
}

// Len returns the length of a repeated field value, or 0 otherwise.
func (v Value) Len() int {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return 0
	}
	return len(v.list)
}

// Index returns the i-th element of a repeated field value.
func (v Value) Index(i int) Value {
	if v.err != nil {
		return Value{err: v.err}
	}
	if !v.exists || !v.set || v.list == nil {
		return Value{err: ErrIndexOutOfRange}
	}
	if i < 0 || i >= len(v.list) {
		return Value{err: ErrIndexOutOfRange}
	}
	elem := v.list[i]
	return Value{exists: true, set: true, val: elem}
}

func (v Value) Strings() []string {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]string, len(v.list))
	for i, e := range v.list {
		if e == nil {
			return nil
		}
		s, ok := e.(string)
		if !ok {
			return nil
		}
		out[i] = s
	}
	return out
}

func (v Value) Int32s() []int32 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]int32, len(v.list))
	for i, e := range v.list {
		n, ok := e.(int32)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Int64s() []int64 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]int64, len(v.list))
	for i, e := range v.list {
		n, ok := e.(int64)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Uint32s() []uint32 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]uint32, len(v.list))
	for i, e := range v.list {
		n, ok := e.(uint32)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Uint64s() []uint64 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]uint64, len(v.list))
	for i, e := range v.list {
		n, ok := e.(uint64)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Float32s() []float32 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]float32, len(v.list))
	for i, e := range v.list {
		n, ok := e.(float32)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Float64s() []float64 {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]float64, len(v.list))
	for i, e := range v.list {
		n, ok := e.(float64)
		if !ok {
			return nil
		}
		out[i] = n
	}
	return out
}

func (v Value) Bools() []bool {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]bool, len(v.list))
	for i, e := range v.list {
		b, ok := e.(bool)
		if !ok {
			return nil
		}
		out[i] = b
	}
	return out
}

func (v Value) BytesSlice() [][]byte {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([][]byte, len(v.list))
	for i, e := range v.list {
		if e == nil {
			return nil
		}
		b, ok := e.([]byte)
		if !ok {
			return nil
		}
		out[i] = append([]byte(nil), b...)
	}
	return out
}

func (v Value) Messages() []*Message {
	if v.err != nil || !v.exists || !v.set || v.list == nil {
		return nil
	}
	out := make([]*Message, len(v.list))
	for i, e := range v.list {
		if e == nil {
			out[i] = nil
			continue
		}
		m, ok := e.(*Message)
		if !ok {
			return nil
		}
		out[i] = m
	}
	return out
}

func typedSlice(f FieldSchema, list []any) any {
	switch f.Type {
	case FieldString:
		out := make([]string, len(list))
		for i, e := range list {
			if e == nil {
				return nil
			}
			s, ok := e.(string)
			if !ok {
				return nil
			}
			out[i] = s
		}
		return out
	case FieldInt32:
		out := make([]int32, len(list))
		for i, e := range list {
			n, ok := e.(int32)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldInt64:
		out := make([]int64, len(list))
		for i, e := range list {
			n, ok := e.(int64)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldUint32:
		out := make([]uint32, len(list))
		for i, e := range list {
			n, ok := e.(uint32)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldUint64:
		out := make([]uint64, len(list))
		for i, e := range list {
			n, ok := e.(uint64)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldFloat:
		out := make([]float32, len(list))
		for i, e := range list {
			n, ok := e.(float32)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldDouble:
		out := make([]float64, len(list))
		for i, e := range list {
			n, ok := e.(float64)
			if !ok {
				return nil
			}
			out[i] = n
		}
		return out
	case FieldBool:
		out := make([]bool, len(list))
		for i, e := range list {
			b, ok := e.(bool)
			if !ok {
				return nil
			}
			out[i] = b
		}
		return out
	case FieldBytes:
		out := make([][]byte, len(list))
		for i, e := range list {
			if e == nil {
				return nil
			}
			b, ok := e.([]byte)
			if !ok {
				return nil
			}
			out[i] = append([]byte(nil), b...)
		}
		return out
	case FieldMessage:
		out := make([]*Message, len(list))
		for i, e := range list {
			if e == nil {
				out[i] = nil
				continue
			}
			m, ok := e.(*Message)
			if !ok {
				return nil
			}
			out[i] = m
		}
		return out
	default:
		return nil
	}
}
