package dymsg

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"math"
	"strconv"
)

// EncodeJSON encodes the message as a JSON object. Fields are emitted in
// schema declaration order and unset fields are omitted.
func (m *Message) EncodeJSON() ([]byte, error) {
	if m == nil {
		return []byte("null"), nil
	}
	buf := make([]byte, 0, 64)
	buf = append(buf, '{')
	first := true
	for _, f := range m.schema.fields {
		fv := m.fields[f.Name]
		if fv == nil || !fv.set {
			continue
		}
		if !f.Repeated && f.Type == FieldMessage && fv.elem == nil {
			continue
		}
		if !first {
			buf = append(buf, ',')
		}
		first = false

		keyBytes, _ := json.Marshal(f.Name)
		buf = append(buf, keyBytes...)
		buf = append(buf, ':')

		var err error
		if f.Repeated {
			buf, err = appendJSONRepeated(buf, f, fv.elem.([]any))
		} else {
			buf, err = appendJSONValue(buf, f, fv.elem)
		}
		if err != nil {
			return nil, err
		}
	}
	buf = append(buf, '}')
	return buf, nil
}

func appendJSONRepeated(buf []byte, f FieldSchema, list []any) ([]byte, error) {
	buf = append(buf, '[')
	for i, elem := range list {
		if i > 0 {
			buf = append(buf, ',')
		}
		if f.Type == FieldMessage && elem == nil {
			buf = append(buf, "null"...)
			continue
		}
		var err error
		buf, err = appendJSONValue(buf, f, elem)
		if err != nil {
			return nil, err
		}
	}
	buf = append(buf, ']')
	return buf, nil
}

func appendJSONValue(buf []byte, f FieldSchema, val any) ([]byte, error) {
	if f.Type == FieldMessage {
		msg, _ := val.(*Message)
		if msg == nil {
			buf = append(buf, "null"...)
			return buf, nil
		}
		child, err := msg.EncodeJSON()
		if err != nil {
			return nil, err
		}
		return append(buf, child...), nil
	}
	if f.Type == FieldFloat {
		if v, ok := val.(float32); ok && (math.IsNaN(float64(v)) || math.IsInf(float64(v), 0)) {
			return nil, ErrMalformedData
		}
	}
	if f.Type == FieldDouble {
		if v, ok := val.(float64); ok && (math.IsNaN(v) || math.IsInf(v, 0)) {
			return nil, ErrMalformedData
		}
	}
	if f.Type == FieldBytes {
		v, _ := val.([]byte)
		s := base64.StdEncoding.EncodeToString(v)
		b, err := json.Marshal(s)
		if err != nil {
			return nil, ErrMalformedData
		}
		return append(buf, b...), nil
	}
	b, err := json.Marshal(val)
	if err != nil {
		return nil, ErrMalformedData
	}
	return append(buf, b...), nil
}

// DecodeJSON replaces the message contents with the supplied JSON object.
func (m *Message) DecodeJSON(data []byte) error {
	if m == nil {
		return ErrMalformedData
	}
	if len(data) == 0 {
		return ErrTruncated
	}

	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var raw any
	if err := dec.Decode(&raw); err != nil {
		return ErrMalformedData
	}
	var extra any
	if err := dec.Decode(&extra); err != io.EOF {
		return ErrMalformedData
	}

	if raw == nil {
		m.fields = make(map[string]*fieldValue)
		return nil
	}

	obj, ok := raw.(map[string]any)
	if !ok {
		return ErrMalformedData
	}

	fields, err := decodeJSONObject(m.schema, obj)
	if err != nil {
		return err
	}
	m.fields = fields
	return nil
}

func decodeJSONObject(schema MessageSchema, obj map[string]any) (map[string]*fieldValue, error) {
	schema.ensureMaps()
	fields := make(map[string]*fieldValue)
	for key, val := range obj {
		f, ok := schema.fieldByName(key)
		if !ok {
			continue
		}
		fv, err := decodeJSONField(f, val)
		if err != nil {
			return nil, err
		}
		if fv != nil {
			fields[f.Name] = fv
		}
	}
	return fields, nil
}

func decodeJSONField(f FieldSchema, val any) (*fieldValue, error) {
	if val == nil {
		return nil, nil
	}

	if f.Repeated {
		arr, ok := val.([]any)
		if !ok {
			return nil, ErrMalformedData
		}
		list := make([]any, 0, len(arr))
		if f.Type == FieldMessage {
			for _, item := range arr {
				if item == nil {
					list = append(list, nil)
					continue
				}
				obj, ok := item.(map[string]any)
				if !ok {
					return nil, ErrMalformedData
				}
				childFields, err := decodeJSONObject(f.Schema, obj)
				if err != nil {
					return nil, err
				}
				list = append(list, newMessageWithFields(f.Schema, childFields))
			}
		} else {
			for _, item := range arr {
				if item == nil {
					return nil, ErrMalformedData
				}
				elem, err := jsonScalar(f.Type, item)
				if err != nil {
					return nil, err
				}
				list = append(list, elem)
			}
		}
		return &fieldValue{set: true, elem: list}, nil
	}

	if f.Type == FieldMessage {
		obj, ok := val.(map[string]any)
		if !ok {
			return nil, ErrMalformedData
		}
		childFields, err := decodeJSONObject(f.Schema, obj)
		if err != nil {
			return nil, err
		}
		return &fieldValue{set: true, elem: newMessageWithFields(f.Schema, childFields)}, nil
	}

	elem, err := jsonScalar(f.Type, val)
	if err != nil {
		return nil, err
	}
	return &fieldValue{set: true, elem: elem}, nil
}

func jsonScalar(ft FieldType, val any) (any, error) {
	switch ft {
	case FieldString:
		s, ok := val.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		return s, nil
	case FieldBool:
		b, ok := val.(bool)
		if !ok {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldBytes:
		s, ok := val.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldInt32:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseInt(num.String(), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return int32(n), nil
	case FieldInt64:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseInt(num.String(), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldUint32:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseUint(num.String(), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return uint32(n), nil
	case FieldUint64:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		n, err := strconv.ParseUint(num.String(), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return n, nil
	case FieldFloat:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(num.String(), 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return float32(f), nil
	case FieldDouble:
		num, ok := val.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(num.String(), 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return f, nil
	default:
		return nil, ErrMalformedData
	}
}
