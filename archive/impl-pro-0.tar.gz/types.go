package dymsg

import "errors"

// FieldType identifies the scalar or message type of a field.
type FieldType string

const (
	FieldInt32   FieldType = "int32"
	FieldInt64   FieldType = "int64"
	FieldUint32  FieldType = "uint32"
	FieldUint64  FieldType = "uint64"
	FieldFloat   FieldType = "float"
	FieldDouble  FieldType = "double"
	FieldBool    FieldType = "bool"
	FieldString  FieldType = "string"
	FieldBytes   FieldType = "bytes"
	FieldMessage FieldType = "message"
)

// FieldSchema describes one field inside a message schema.
type FieldSchema struct {
	Name     string
	Num      int
	Type     FieldType
	Repeated bool
	Schema   MessageSchema
}

// MessageSchema describes a message type. Its internal representation is an
// implementation detail; use ParseSchema to construct schemas from the JSON
// configuration format.
type MessageSchema struct {
	typeID uint16
	fields []FieldSchema
	byName map[string]int
	byNum  map[int]int
}

// Sentinel errors.
var (
	ErrDuplicateID     = errors.New("dymsg: duplicate type id with different schema")
	ErrUnknownTypeID   = errors.New("dymsg: unknown type id")
	ErrFieldNotFound   = errors.New("dymsg: field not found or invalid path")
	ErrIndexOutOfRange = errors.New("dymsg: index out of range")
	ErrTypeMismatch    = errors.New("dymsg: type mismatch")
	ErrMalformedData   = errors.New("dymsg: malformed data")
	ErrTruncated       = errors.New("dymsg: truncated data")
)
