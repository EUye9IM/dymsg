package dymsg

import (
	"bytes"
	"encoding/json"
	"strconv"
	"strings"
	"sync"
)

var (
	registryMu sync.RWMutex
	registry   = map[uint16]MessageSchema{}
)

// ParseSchema parses a JSON configuration containing a top-level "types"
// array and returns the top-level message schemas. The returned schemas still
// need to be registered with Register before New can construct messages.
func ParseSchema(data []byte) ([]MessageSchema, error) {
	if len(data) == 0 {
		return nil, ErrMalformedData
	}

	var root map[string]json.RawMessage
	if err := json.Unmarshal(data, &root); err != nil {
		return nil, ErrMalformedData
	}

	typesRaw, ok := root["types"]
	if !ok {
		return nil, ErrMalformedData
	}

	var rawTypes []json.RawMessage
	if err := json.Unmarshal(typesRaw, &rawTypes); err != nil {
		return nil, ErrMalformedData
	}
	if rawTypes == nil {
		return nil, ErrMalformedData
	}

	schemas := make([]MessageSchema, 0, len(rawTypes))
	seen := make(map[uint16]bool, len(rawTypes))
	for _, raw := range rawTypes {
		s, err := parseType(raw, true)
		if err != nil {
			return nil, err
		}
		if seen[s.typeID] {
			return nil, ErrMalformedData
		}
		seen[s.typeID] = true
		schemas = append(schemas, s)
	}
	return schemas, nil
}

// Register registers a parsed message schema under its type id. Registering
// the same schema again is idempotent; registering a different schema for the
// same id returns ErrDuplicateID.
func Register(s MessageSchema) error {
	if s.typeID == 0 {
		return ErrMalformedData
	}
	s.ensureMaps()
	if err := validateSchema(s, true); err != nil {
		return err
	}

	registryMu.Lock()
	defer registryMu.Unlock()
	if old, ok := registry[s.typeID]; ok {
		if schemaEqual(old, s) {
			return nil
		}
		return ErrDuplicateID
	}
	registry[s.typeID] = s
	return nil
}

// New constructs an empty message for a registered type id.
func New(typeID uint16) (*Message, error) {
	registryMu.RLock()
	s, ok := registry[typeID]
	registryMu.RUnlock()
	if !ok {
		return nil, ErrUnknownTypeID
	}
	return newMessage(s), nil
}

func parseType(raw json.RawMessage, top bool) (MessageSchema, error) {
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		return MessageSchema{}, ErrMalformedData
	}

	var s MessageSchema
	if top {
		idRaw, ok := obj["typeId"]
		if !ok {
			return MessageSchema{}, ErrMalformedData
		}
		id, err := parseJSONInt(idRaw)
		if err != nil || id < 1 || id > 65535 {
			return MessageSchema{}, ErrMalformedData
		}
		s.typeID = uint16(id)
	} else {
		if _, exists := obj["typeId"]; exists {
			return MessageSchema{}, ErrMalformedData
		}
	}

	fieldsRaw, ok := obj["fields"]
	if !ok {
		return MessageSchema{}, ErrMalformedData
	}
	var rawFields []json.RawMessage
	if err := json.Unmarshal(fieldsRaw, &rawFields); err != nil {
		return MessageSchema{}, ErrMalformedData
	}
	if rawFields == nil {
		return MessageSchema{}, ErrMalformedData
	}

	s.fields = make([]FieldSchema, 0, len(rawFields))
	seenNames := make(map[string]bool, len(rawFields))
	seenNums := make(map[int]bool, len(rawFields))
	for _, rawField := range rawFields {
		f, err := parseField(rawField)
		if err != nil {
			return MessageSchema{}, err
		}
		if seenNames[f.Name] {
			return MessageSchema{}, ErrMalformedData
		}
		if seenNums[f.Num] {
			return MessageSchema{}, ErrMalformedData
		}
		seenNames[f.Name] = true
		seenNums[f.Num] = true
		s.fields = append(s.fields, f)
	}

	s.ensureMaps()
	if err := validateSchema(s, top); err != nil {
		return MessageSchema{}, err
	}
	return s, nil
}

func parseField(raw json.RawMessage) (FieldSchema, error) {
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		return FieldSchema{}, ErrMalformedData
	}

	var f FieldSchema

	nameRaw, ok := obj["name"]
	if !ok {
		return FieldSchema{}, ErrMalformedData
	}
	name, err := parseJSONString(nameRaw)
	if err != nil {
		return FieldSchema{}, ErrMalformedData
	}
	if name == "" || strings.ContainsAny(name, ".[]") {
		return FieldSchema{}, ErrMalformedData
	}
	f.Name = name

	typeRaw, ok := obj["type"]
	if !ok {
		return FieldSchema{}, ErrMalformedData
	}
	typeName, err := parseJSONString(typeRaw)
	if err != nil {
		return FieldSchema{}, ErrMalformedData
	}
	ft, ok := fieldTypeFromString(typeName)
	if !ok {
		return FieldSchema{}, ErrMalformedData
	}
	f.Type = ft

	numRaw, ok := obj["num"]
	if !ok {
		return FieldSchema{}, ErrMalformedData
	}
	num, err := parseJSONInt(numRaw)
	if err != nil || num < 1 || num > 65535 {
		return FieldSchema{}, ErrMalformedData
	}
	f.Num = int(num)

	if repRaw, exists := obj["repeated"]; exists {
		rep, err := parseJSONBool(repRaw)
		if err != nil {
			return FieldSchema{}, ErrMalformedData
		}
		f.Repeated = rep
	}

	schemaRaw, hasSchema := obj["schema"]
	if f.Type == FieldMessage {
		if !hasSchema {
			return FieldSchema{}, ErrMalformedData
		}
		nested, err := parseType(schemaRaw, false)
		if err != nil {
			return FieldSchema{}, err
		}
		f.Schema = nested
	} else if hasSchema {
		return FieldSchema{}, ErrMalformedData
	}

	return f, nil
}

func fieldTypeFromString(s string) (FieldType, bool) {
	switch FieldType(s) {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat, FieldDouble, FieldBool, FieldString, FieldBytes, FieldMessage:
		return FieldType(s), true
	default:
		return "", false
	}
}

func parseJSONInt(raw json.RawMessage) (int64, error) {
	var num json.Number
	if err := json.Unmarshal(raw, &num); err != nil {
		return 0, err
	}
	return strconv.ParseInt(num.String(), 10, 64)
}

func parseJSONString(raw json.RawMessage) (string, error) {
	var s string
	if err := json.Unmarshal(raw, &s); err != nil {
		return "", err
	}
	return s, nil
}

func parseJSONBool(raw json.RawMessage) (bool, error) {
	if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		return false, ErrMalformedData
	}
	var b bool
	if err := json.Unmarshal(raw, &b); err != nil {
		return false, err
	}
	return b, nil
}

func (s *MessageSchema) ensureMaps() {
	if s.byName == nil || s.byNum == nil {
		s.byName = make(map[string]int, len(s.fields))
		s.byNum = make(map[int]int, len(s.fields))
		for i := range s.fields {
			s.byName[s.fields[i].Name] = i
			s.byNum[s.fields[i].Num] = i
		}
	}
	for i := range s.fields {
		if s.fields[i].Type == FieldMessage {
			s.fields[i].Schema.ensureMaps()
		}
	}
}

func (s MessageSchema) fieldByName(name string) (FieldSchema, bool) {
	idx, ok := s.byName[name]
	if !ok {
		return FieldSchema{}, false
	}
	return s.fields[idx], true
}

func (s MessageSchema) fieldByNum(num int) (FieldSchema, bool) {
	idx, ok := s.byNum[num]
	if !ok {
		return FieldSchema{}, false
	}
	return s.fields[idx], true
}

func validateSchema(s MessageSchema, top bool) error {
	if top {
		if s.typeID == 0 {
			return ErrMalformedData
		}
	} else if s.typeID != 0 {
		return ErrMalformedData
	}

	seenNames := make(map[string]bool, len(s.fields))
	seenNums := make(map[int]bool, len(s.fields))
	for _, f := range s.fields {
		if f.Name == "" || strings.ContainsAny(f.Name, ".[]") {
			return ErrMalformedData
		}
		if f.Num < 1 || f.Num > 65535 {
			return ErrMalformedData
		}
		switch f.Type {
		case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat, FieldDouble, FieldBool, FieldString, FieldBytes:
		case FieldMessage:
			if err := validateSchema(f.Schema, false); err != nil {
				return err
			}
		default:
			return ErrMalformedData
		}
		if seenNames[f.Name] || seenNums[f.Num] {
			return ErrMalformedData
		}
		seenNames[f.Name] = true
		seenNums[f.Num] = true
	}
	return nil
}

func schemaEqual(a, b MessageSchema) bool {
	if len(a.fields) != len(b.fields) {
		return false
	}
	for i := range a.fields {
		fa, fb := a.fields[i], b.fields[i]
		if fa.Name != fb.Name || fa.Num != fb.Num || fa.Type != fb.Type || fa.Repeated != fb.Repeated {
			return false
		}
		if fa.Type == FieldMessage && !schemaEqual(fa.Schema, fb.Schema) {
			return false
		}
	}
	return true
}
