module dymsg

go 1.21
