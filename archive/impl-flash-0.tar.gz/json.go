package dymsg

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"reflect"
	"strconv"
)

func (m *Message) EncodeJSON() ([]byte, error) {
	var buf bytes.Buffer
	buf.WriteByte('{')
	first := true
	for i, ok := range m.set {
		if !ok {
			continue
		}
		fs := &m.schema.Fields[i]
		if fs.Type == FieldMessage && !fs.Repeated {
			msg, _ := m.vals[i].(*Message)
			if msg == nil {
				continue
			}
		}
		if !first {
			buf.WriteByte(',')
		}
		first = false
		key, _ := json.Marshal(fs.Name)
		buf.Write(key)
		buf.WriteByte(':')
		if err := m.writeJSONValue(&buf, i, fs); err != nil {
			return nil, err
		}
	}
	buf.WriteByte('}')
	return buf.Bytes(), nil
}

func (m *Message) writeJSONValue(buf *bytes.Buffer, idx int, fs *FieldSchema) error {
	val := m.vals[idx]
	if fs.Repeated {
		buf.WriteByte('[')
		rv := reflect.ValueOf(val)
		n := rv.Len()
		for i := 0; i < n; i++ {
			if i > 0 {
				buf.WriteByte(',')
			}
			elem := rv.Index(i).Interface()
			if fs.Type == FieldMessage {
				msg, _ := elem.(*Message)
				if msg == nil {
					buf.WriteString("null")
					continue
				}
				b, err := msg.EncodeJSON()
				if err != nil {
					return err
				}
				buf.Write(b)
			} else if fs.Type == FieldBytes {
				b, _ := elem.([]byte)
				writeJSONBytes(buf, b)
			} else {
				b, err := json.Marshal(elem)
				if err != nil {
					return ErrMalformedData
				}
				buf.Write(b)
			}
		}
		buf.WriteByte(']')
		return nil
	}
	if fs.Type == FieldMessage {
		msg, _ := val.(*Message)
		b, err := msg.EncodeJSON()
		if err != nil {
			return err
		}
		buf.Write(b)
		return nil
	}
	if fs.Type == FieldBytes {
		b, _ := val.([]byte)
		writeJSONBytes(buf, b)
		return nil
	}
	b, err := json.Marshal(val)
	if err != nil {
		return ErrMalformedData
	}
	buf.Write(b)
	return nil
}

func writeJSONBytes(buf *bytes.Buffer, b []byte) {
	buf.WriteByte('"')
	if b != nil {
		buf.WriteString(base64.StdEncoding.EncodeToString(b))
	}
	buf.WriteByte('"')
}

func (m *Message) DecodeJSON(data []byte) error {
	if len(bytes.TrimSpace(data)) == 0 {
		return ErrTruncated
	}
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var raw json.RawMessage
	if err := dec.Decode(&raw); err != nil {
		return ErrMalformedData
	}
	if _, err := dec.Token(); err != io.EOF {
		return ErrMalformedData
	}
	trimmed := bytes.TrimSpace(raw)
	if bytes.Equal(trimmed, []byte("null")) {
		m.clearAll()
		return nil
	}
	if len(trimmed) == 0 || trimmed[0] != '{' {
		return ErrMalformedData
	}
	m.clearAll()
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(trimmed, &obj); err != nil {
		return ErrMalformedData
	}
	for key, rawVal := range obj {
		fi, ok := m.schema.fieldIndexByName(key)
		if !ok {
			continue
		}
		fs := &m.schema.Fields[fi]
		if err := m.decodeFieldValue(fs, rawVal); err != nil {
			return err
		}
	}
	return nil
}

func (m *Message) decodeFieldValue(fs *FieldSchema, raw json.RawMessage) error {
	trimmed := bytes.TrimSpace(raw)
	if bytes.Equal(trimmed, []byte("null")) {
		fi := m.schema.byName[fs.Name]
		m.set[fi] = false
		m.vals[fi] = nil
		return nil
	}
	fi := m.schema.byName[fs.Name]
	if fs.Repeated {
		if len(trimmed) == 0 || trimmed[0] != '[' {
			return ErrMalformedData
		}
		elems, err := decodeJSONArray(raw)
		if err != nil {
			return err
		}
		if fs.Type == FieldMessage {
			out := make([]*Message, len(elems))
			for i, e := range elems {
				et := bytes.TrimSpace(e)
				if bytes.Equal(et, []byte("null")) {
					out[i] = nil
					continue
				}
				sub := newMessage(&fs.Schema)
				if err := sub.DecodeJSON(e); err != nil {
					return err
				}
				out[i] = sub
			}
			m.set[fi] = true
			m.vals[fi] = out
			return nil
		}
		typed, err := buildScalarSlice(elems, fs.Type)
		if err != nil {
			return err
		}
		m.set[fi] = true
		m.vals[fi] = typed
		return nil
	}
	if fs.Type == FieldMessage {
		sub := newMessage(&fs.Schema)
		if err := sub.DecodeJSON(raw); err != nil {
			return err
		}
		m.set[fi] = true
		m.vals[fi] = sub
		return nil
	}
	v, err := strictJSONScalar(fs.Type, raw)
	if err != nil {
		return err
	}
	m.set[fi] = true
	m.vals[fi] = v
	return nil
}

func decodeJSONArray(raw json.RawMessage) ([]json.RawMessage, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return nil, ErrMalformedData
	}
	if d, ok := tok.(json.Delim); !ok || d != '[' {
		return nil, ErrMalformedData
	}
	var elems []json.RawMessage
	for dec.More() {
		var elem json.RawMessage
		if err := dec.Decode(&elem); err != nil {
			return nil, ErrMalformedData
		}
		elems = append(elems, elem)
	}
	tok, err = dec.Token()
	if err != nil {
		return nil, ErrMalformedData
	}
	if d, ok := tok.(json.Delim); !ok || d != ']' {
		return nil, ErrMalformedData
	}
	return elems, nil
}

func buildScalarSlice(elems []json.RawMessage, typ FieldType) (any, error) {
	switch typ {
	case FieldInt32:
		out := make([]int32, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(int32))
		}
		return out, nil
	case FieldInt64:
		out := make([]int64, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(int64))
		}
		return out, nil
	case FieldUint32:
		out := make([]uint32, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(uint32))
		}
		return out, nil
	case FieldUint64:
		out := make([]uint64, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(uint64))
		}
		return out, nil
	case FieldFloat:
		out := make([]float32, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(float32))
		}
		return out, nil
	case FieldDouble:
		out := make([]float64, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(float64))
		}
		return out, nil
	case FieldBool:
		out := make([]bool, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(bool))
		}
		return out, nil
	case FieldString:
		out := make([]string, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.(string))
		}
		return out, nil
	case FieldBytes:
		out := make([][]byte, 0, len(elems))
		for _, e := range elems {
			if bytes.Equal(bytes.TrimSpace(e), []byte("null")) {
				return nil, ErrMalformedData
			}
			v, err := strictJSONScalar(typ, e)
			if err != nil {
				return nil, err
			}
			out = append(out, v.([]byte))
		}
		return out, nil
	}
	return nil, ErrMalformedData
}

func strictJSONScalar(typ FieldType, raw []byte) (any, error) {
	trimmed := bytes.TrimSpace(raw)
	switch typ {
	case FieldInt32:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		i, err := strconv.ParseInt(string(n), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return int32(i), nil
	case FieldInt64:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		i, err := strconv.ParseInt(string(n), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return i, nil
	case FieldUint32:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		u, err := strconv.ParseUint(string(n), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return uint32(u), nil
	case FieldUint64:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		u, err := strconv.ParseUint(string(n), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return u, nil
	case FieldFloat:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(string(n), 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return float32(f), nil
	case FieldDouble:
		n, err := decodeJSONNumber(trimmed)
		if err != nil {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(string(n), 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return f, nil
	case FieldBool:
		if bytes.Equal(trimmed, []byte("true")) {
			return true, nil
		}
		if bytes.Equal(trimmed, []byte("false")) {
			return false, nil
		}
		return nil, ErrMalformedData
	case FieldString:
		var s string
		if err := json.Unmarshal(trimmed, &s); err != nil {
			return nil, ErrMalformedData
		}
		return s, nil
	case FieldBytes:
		var s string
		if err := json.Unmarshal(trimmed, &s); err != nil {
			return nil, ErrMalformedData
		}
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			return nil, ErrMalformedData
		}
		return b, nil
	}
	return nil, ErrMalformedData
}

func decodeJSONNumber(raw []byte) (json.Number, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return "", err
	}
	n, ok := tok.(json.Number)
	if !ok {
		return "", ErrMalformedData
	}
	return n, nil
}
