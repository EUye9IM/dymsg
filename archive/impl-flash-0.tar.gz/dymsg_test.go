package dymsg

import (
	"bytes"
	"encoding/base64"
	"errors"
	"math"
	"reflect"
	"strings"
	"testing"
)

const testCfg = `{
  "types": [
    {
      "typeId": 1001,
      "fields": [
        { "name": "name", "type": "string", "num": 1 },
        { "name": "age", "type": "int32", "num": 2 },
        {
          "name": "addr",
          "type": "message",
          "num": 3,
          "schema": {
            "fields": [
              { "name": "city", "type": "string", "num": 1 },
              { "name": "zip", "type": "string", "num": 2 }
            ]
          }
        },
        { "name": "tags", "type": "string", "num": 4, "repeated": true },
        { "name": "scores", "type": "int32", "num": 5, "repeated": true },
        {
          "name": "contacts",
          "type": "message",
          "num": 6,
          "repeated": true,
          "schema": {
            "fields": [
              { "name": "phone", "type": "string", "num": 1 }
            ]
          }
        },
        { "name": "data", "type": "bytes", "num": 7 },
        { "name": "height", "type": "double", "num": 8 },
        { "name": "weight", "type": "float", "num": 9 },
        { "name": "active", "type": "bool", "num": 10 },
        { "name": "big", "type": "int64", "num": 11 },
        { "name": "bigu", "type": "uint64", "num": 12 },
        { "name": "nums", "type": "double", "num": 13, "repeated": true }
      ]
    }
  ]
}`

func mustParseAndRegister(t *testing.T) {
	t.Helper()
	schemas, err := ParseSchema([]byte(testCfg))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	for _, s := range schemas {
		if err := Register(s); err != nil {
			t.Fatalf("Register: %v", err)
		}
	}
}

func TestParseSchemaAndNew(t *testing.T) {
	mustParseAndRegister(t)
	m, err := New(1001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if m == nil {
		t.Fatal("m is nil")
	}
	if _, err := New(9999); !errors.Is(err, ErrUnknownTypeID) {
		t.Fatalf("New unknown: got %v, want ErrUnknownTypeID", err)
	}
}

func TestParseSchemaErrors(t *testing.T) {
	cases := []string{
		`{}`, // missing types
		`{`, // invalid JSON
		`{"types":[{"typeId":0,"fields":[]}]}`,           // typeId 0
		`{"types":[{"typeId":65536,"fields":[]}]}`,       // typeId too big
		`{"types":[{"typeId":1,"fields":[]},{"typeId":1,"fields":[]}]}`, // duplicate typeId
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"int32","num":0}]}]}`,  // num 0
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"int32","num":65536}]}]}`, // num too big
		`{"types":[{"typeId":1,"fields":[{"name":"a.b","type":"int32","num":1}]}]}`,   // bad name
		`{"types":[{"typeId":1,"fields":[{"name":"a[0]","type":"int32","num":1}]}]}`,  // bad name
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"bogus","num":1}]}]}`,     // bad type
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"int32","num":1,"schema":{"fields":[]}}]}]}`, // schema on non-message
		`{"types":[{"name":"a","type":"message","num":1}]}`, // message without schema
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"int32","num":1},{"name":"a","type":"int32","num":2}]}]}`, // dup name
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"int32","num":1},{"name":"b","type":"int32","num":1}]}]}`, // dup num
		`{"types":[{"typeId":1,"fields":[{"name":"","type":"int32","num":1}]}]}`, // empty name
	}
	for _, c := range cases {
		if _, err := ParseSchema([]byte(c)); !errors.Is(err, ErrMalformedData) {
			t.Errorf("ParseSchema(%q) = %v, want ErrMalformedData", c, err)
		}
	}
}

func TestRegisterDuplicate(t *testing.T) {
	schemas, err := ParseSchema([]byte(testCfg))
	if err != nil {
		t.Fatal(err)
	}
	s := schemas[0]
	// same content is idempotent
	if err := Register(s); err != nil {
		t.Fatalf("Register same: %v", err)
	}
	// different content -> ErrDuplicateID
	s2 := s
	s2.Fields = append([]FieldSchema(nil), s.Fields...)
	s2.Fields[0].Name = "name2"
	if err := Register(s2); !errors.Is(err, ErrDuplicateID) {
		t.Fatalf("Register diff: got %v, want ErrDuplicateID", err)
	}
	// typeID 0 -> ErrMalformedData
	var bad MessageSchema
	if err := Register(bad); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("Register typeID 0: got %v, want ErrMalformedData", err)
	}
}

func TestSetGetScalar(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("name", "alice"); err != nil {
		t.Fatalf("Set name: %v", err)
	}
	if v := m.Get("name"); !v.Exists() || !v.IsSet() || v.String() != "alice" {
		t.Fatalf("Get name: %+v", v)
	}
	if v := m.Get("age"); v.Exists() != true || v.IsSet() != false {
		t.Fatalf("Get age unset: exists=%v set=%v", v.Exists(), v.IsSet())
	}
	if err := m.Set("age", int32(30)); err != nil {
		t.Fatalf("Set age: %v", err)
	}
	if v := m.Get("age"); v.Int32() != 30 {
		t.Fatalf("Get age: %v", v.Int32())
	}
	if v := m.Get("age"); v.Any() != int32(30) {
		t.Fatalf("Get age Any: %#v", v.Any())
	}
}

func TestPresence(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// unset field exists but IsSet false
	v := m.Get("name")
	if !v.Exists() || v.IsSet() {
		t.Fatalf("unset name: exists=%v set=%v", v.Exists(), v.IsSet())
	}
	if v.Err() != nil {
		t.Fatalf("unset name err: %v", v.Err())
	}
	// unknown field
	v = m.Get("nope")
	if v.Exists() || v.Err() != ErrFieldNotFound {
		t.Fatalf("unknown: exists=%v err=%v", v.Exists(), v.Err())
	}
	// set zero value
	m.Set("age", int32(0))
	v = m.Get("age")
	if !v.Exists() || !v.IsSet() || v.Int32() != 0 {
		t.Fatalf("zero age: exists=%v set=%v val=%v", v.Exists(), v.IsSet(), v.Int32())
	}
	if !m.Has("age") {
		t.Fatal("Has age should be true")
	}
}

func TestNestedAutoCreate(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatalf("Set addr.city: %v", err)
	}
	v := m.Get("addr")
	if !v.Exists() || !v.IsSet() || v.Message() == nil {
		t.Fatalf("addr not set properly: %+v", v)
	}
	if v := m.Get("addr.city"); v.String() != "beijing" {
		t.Fatalf("addr.city = %q", v.String())
	}
	if v := m.Get("addr.zip"); v.IsSet() {
		t.Fatalf("addr.zip should be unset")
	}
	// descending into unset nested message -> ErrFieldNotFound
	m2, _ := New(1001)
	v = m2.Get("addr.city")
	if v.Err() != ErrFieldNotFound {
		t.Fatalf("Get addr.city on unset addr: err=%v", v.Err())
	}
}

func TestRepeatedAppend(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Append("tags", "a"); err != nil {
		t.Fatalf("Append tags: %v", err)
	}
	if err := m.Append("tags", "b"); err != nil {
		t.Fatalf("Append tags: %v", err)
	}
	v := m.Get("tags")
	if v.Len() != 2 {
		t.Fatalf("tags len = %d", v.Len())
	}
	if v.Index(0).String() != "a" || v.Index(1).String() != "b" {
		t.Fatalf("tags elements wrong")
	}
	if v.Index(2).Err() != ErrIndexOutOfRange || v.Index(2).Exists() {
		t.Fatalf("tags index 2 should be out of range")
	}
	if v.Index(-1).Err() != ErrIndexOutOfRange {
		t.Fatalf("tags index -1 should be out of range")
	}
	if v.Strings() == nil || len(v.Strings()) != 2 {
		t.Fatalf("tags Strings: %#v", v.Strings())
	}
}

func TestRepeatedSetSlice(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("scores", []int32{1, 2, 3}); err != nil {
		t.Fatalf("Set scores: %v", err)
	}
	v := m.Get("scores")
	if v.Len() != 3 || v.Index(1).Int32() != 2 {
		t.Fatalf("scores wrong: %+v", v)
	}
	// lenient conversion
	if err := m.Set("scores", []int{4, 5}); err != nil {
		t.Fatalf("Set scores []int: %v", err)
	}
	if v := m.Get("scores"); v.Len() != 2 || v.Index(0).Int32() != 4 {
		t.Fatalf("scores after []int: %+v", v)
	}
	// non-slice -> ErrTypeMismatch
	if err := m.Set("scores", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set scores string: got %v", err)
	}
}

func TestAppendErrors(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Append("name", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append non-repeated: got %v", err)
	}
	if err := m.Append("nope", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Append unknown: got %v", err)
	}
	if err := m.Append("tags", int32(123)); err != nil {
		t.Fatalf("Append tags int to string: %v", err)
	}
	if v := m.Get("tags"); v.Len() != 1 || v.Index(0).String() != "123" {
		t.Fatalf("tags after int append: %+v", v)
	}
}

func TestSetErrors(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("nope", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set unknown: got %v", err)
	}
	if err := m.Set("name[0]", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set scalar index: got %v", err)
	}
	if err := m.Set("tags[0]", "x"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Set tags[0] unset: got %v", err)
	}
	m.Append("tags", "a")
	if err := m.Set("tags[0]", "b"); err != nil {
		t.Fatalf("Set tags[0]: %v", err)
	}
	if v := m.Get("tags"); v.Index(0).String() != "b" {
		t.Fatalf("tags[0] = %q", v.Index(0).String())
	}
	if err := m.Set("tags[5]", "x"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Set tags[5]: got %v", err)
	}
	// numeric overflow
	if err := m.Set("age", int64(1<<40)); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set age overflow: got %v", err)
	}
	if err := m.Set("age", "18"); err != nil {
		t.Fatalf("Set age string->int: %v", err)
	}
	if v := m.Get("age"); v.Int32() != 18 {
		t.Fatalf("age = %v", v.Int32())
	}
}

func TestSetNilClears(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "alice")
	if !m.Has("name") {
		t.Fatal("name should be set")
	}
	if err := m.Set("name", nil); err != nil {
		t.Fatalf("Set name nil: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared")
	}
	if err := m.Set("", nil); err != nil {
		t.Fatalf("Set all nil: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields after clear: %v", m.SetFields())
	}
}

func TestSetWholeMessage(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	src, _ := New(1001)
	src.Set("name", "bob")
	src.Set("age", int32(10))
	if err := m.Set("", src); err != nil {
		t.Fatalf("Set whole: %v", err)
	}
	if m.Get("name").String() != "bob" || m.Get("age").Int32() != 10 {
		t.Fatalf("m not copied")
	}
	// deep copy independence
	src.Set("name", "changed")
	if m.Get("name").String() != "bob" {
		t.Fatalf("deep copy failed: %q", m.Get("name").String())
	}
	// incompatible schema
	sch := *m.schema
	sch.Fields = append([]FieldSchema(nil), m.schema.Fields...)
	sch.Fields[0].Name = "zzz"
	diff := newMessage(&sch)
	if err := m.Set("", diff); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set whole diff schema: got %v", err)
	}
}

func TestSetFieldsOrder(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("active", true)
	m.Set("name", "x")
	m.Set("age", int32(1))
	got := m.SetFields()
	want := []string{"name", "age", "active"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("SetFields = %v, want %v", got, want)
	}
}

func TestClear(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	if err := m.Clear("name"); err != nil {
		t.Fatalf("Clear name: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared")
	}
	// clear unset is idempotent
	if err := m.Clear("name"); err != nil {
		t.Fatalf("Clear unset: %v", err)
	}
	if err := m.Clear("nope"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Clear unknown: got %v", err)
	}
	// clear nested with auto-created parent
	m.Set("addr.city", "x")
	if err := m.Clear("addr.city"); err != nil {
		t.Fatalf("Clear addr.city: %v", err)
	}
	if m.Has("addr.city") {
		t.Fatal("addr.city should be cleared")
	}
	if !m.Has("addr") {
		t.Fatal("addr should still be set")
	}
}

func TestClearIndex(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Append("tags", "a")
	m.Append("tags", "b")
	if err := m.Clear("tags[0]"); err != nil {
		t.Fatalf("Clear tags[0]: %v", err)
	}
	if v := m.Get("tags"); v.Len() != 2 || v.Index(0).String() != "" {
		t.Fatalf("tags after clear element: %+v", v)
	}
	if err := m.Clear("tags[5]"); !errors.Is(err, ErrIndexOutOfRange) {
		t.Fatalf("Clear tags[5]: got %v", err)
	}
}

func TestRepeatedWithoutIndexDescent(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	var c *Message
	m.Append("contacts", c)
	// descending into a repeated field without an index is a path error, not a panic
	if v := m.Get("contacts.phone"); v.Err() != ErrFieldNotFound {
		t.Fatalf("Get contacts.phone err = %v, want ErrFieldNotFound", v.Err())
	}
	if err := m.Set("contacts.phone", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Set contacts.phone err = %v, want ErrFieldNotFound", err)
	}
	if err := m.Set("contacts", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set contacts scalar err = %v, want ErrTypeMismatch", err)
	}
	if err := m.Append("contacts.phone", "x"); !errors.Is(err, ErrFieldNotFound) {
		t.Fatalf("Append contacts.phone err = %v, want ErrFieldNotFound", err)
	}
}

func TestPathErrors(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	cases := []string{"unknown", "name[0]", "name.x", "addr.city.x", "tags[0", "tags[0]x"}
	for _, p := range cases {
		v := m.Get(p)
		if v.Err() != ErrFieldNotFound {
			t.Errorf("Get(%q) err = %v, want ErrFieldNotFound", p, v.Err())
		}
	}
	idxCases := []string{"tags[-1]", "tags[abc]", "tags[]"}
	for _, p := range idxCases {
		v := m.Get(p)
		if v.Err() != ErrIndexOutOfRange {
			t.Errorf("Get(%q) err = %v, want ErrIndexOutOfRange", p, v.Err())
		}
	}
	// Set on invalid path
	if err := m.Set("unknown", 1); !errors.Is(err, ErrFieldNotFound) {
		t.Errorf("Set unknown err = %v", err)
	}
}

func TestGetSelf(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	v := m.Get("")
	if !v.Exists() || !v.IsSet() {
		t.Fatalf("Get empty: %+v", v)
	}
	if v.Message() != m {
		t.Fatal("Get empty Message() should be m")
	}
	if v.Any() != m {
		t.Fatal("Get empty Any() should be m")
	}
}

func TestJSONRoundTrip(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "alice")
	m.Set("age", int32(30))
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Set("scores", []int32{90, 95})
	m.Set("data", []byte("hello"))
	m.Set("height", 1.75)
	m.Set("weight", float32(68.5))
	m.Set("active", true)
	m.Set("big", int64(-1234567890123))
	m.Set("bigu", uint64(18446744073709551615))

	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	m2, _ := New(1001)
	if err := m2.DecodeJSON(b); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m2.Get("name").String() != "alice" {
		t.Fatalf("name = %q", m2.Get("name").String())
	}
	if m2.Get("age").Int32() != 30 {
		t.Fatalf("age = %v", m2.Get("age").Int32())
	}
	if m2.Get("addr.city").String() != "beijing" {
		t.Fatalf("addr.city = %q", m2.Get("addr.city").String())
	}
	if v := m2.Get("tags"); v.Len() != 2 || v.Index(0).String() != "a" || v.Index(1).String() != "b" {
		t.Fatalf("tags = %+v", v)
	}
	if v := m2.Get("scores"); v.Len() != 2 || v.Index(0).Int32() != 90 {
		t.Fatalf("scores = %+v", v)
	}
	if string(m2.Get("data").Bytes()) != "hello" {
		t.Fatalf("data = %q", string(m2.Get("data").Bytes()))
	}
	if math.Abs(m2.Get("height").Float64()-1.75) > 1e-9 {
		t.Fatalf("height = %v", m2.Get("height").Float64())
	}
	if math.Abs(float64(m2.Get("weight").Float32())-68.5) > 1e-4 {
		t.Fatalf("weight = %v", m2.Get("weight").Float32())
	}
	if !m2.Get("active").Bool() {
		t.Fatal("active should be true")
	}
	if m2.Get("big").Int64() != -1234567890123 {
		t.Fatalf("big = %v", m2.Get("big").Int64())
	}
	if m2.Get("bigu").Uint64() != 18446744073709551615 {
		t.Fatalf("bigu = %v", m2.Get("bigu").Uint64())
	}
}

func TestJSONNullHandling(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	if err := m.DecodeJSON([]byte(`null`)); err != nil {
		t.Fatalf("DecodeJSON null: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields after null: %v", m.SetFields())
	}
	if err := m.DecodeJSON([]byte(`{"name":null}`)); err != nil {
		t.Fatalf("DecodeJSON name null: %v", err)
	}
	if m.Has("name") {
		t.Fatal("name should be unset")
	}
}

func TestJSONErrors(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeJSON([]byte(``)); !errors.Is(err, ErrTruncated) {
		t.Fatalf("empty: got %v", err)
	}
	for _, in := range []string{`[]`, `"x"`, `123`, `{`, `{"age":"18"}`, `{"age":2147483648}`, `{"scores":[1,null]}`, `{"unknown":1} garbage`} {
		if err := m.DecodeJSON([]byte(in)); !errors.Is(err, ErrMalformedData) {
			t.Errorf("DecodeJSON(%q) = %v, want ErrMalformedData", in, err)
		}
	}
	// unknown key ignored
	if err := m.DecodeJSON([]byte(`{"unknown":1,"name":"ok"}`)); err != nil {
		t.Fatalf("DecodeJSON unknown: %v", err)
	}
	if m.Get("name").String() != "ok" {
		t.Fatalf("name = %q", m.Get("name").String())
	}
}

func TestJSONRepeatedMessageNull(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeJSON([]byte(`{"contacts":[null,{"phone":"123"}]}`)); err != nil {
		t.Fatalf("DecodeJSON contacts: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 2 {
		t.Fatalf("contacts len = %d", v.Len())
	}
	if v.Index(0).Message() != nil {
		t.Fatal("contacts[0] should be nil")
	}
	if v.Index(1).Message() == nil {
		t.Fatal("contacts[1] should be a message")
	}
	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	if !bytes.Contains(b, []byte("null")) {
		t.Fatalf("expected null in encoded JSON: %s", b)
	}
}

func TestJSONBytesBase64(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("data", []byte{0, 1, 2, 3})
	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	want := base64.StdEncoding.EncodeToString([]byte{0, 1, 2, 3})
	if !bytes.Contains(b, []byte(want)) {
		t.Fatalf("expected base64 %q in %s", want, b)
	}
	// invalid base64 -> error
	m2, _ := New(1001)
	if err := m2.DecodeJSON([]byte(`{"data":"!!!"}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("DecodeJSON bad base64: %v", err)
	}
}

func TestJSONNaNEncodeError(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("height", math.NaN())
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("EncodeJSON NaN: got %v", err)
	}
	m.Set("height", math.Inf(1))
	if _, err := m.EncodeJSON(); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("EncodeJSON Inf: got %v", err)
	}
}

func TestJSONMessageFieldEmpty(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeJSON([]byte(`{"addr":{}}`)); err != nil {
		t.Fatalf("DecodeJSON addr: %v", err)
	}
	if !m.Has("addr") {
		t.Fatal("addr should be set")
	}
	b, _ := m.EncodeJSON()
	if !bytes.Contains(b, []byte(`"addr":{}`)) {
		t.Fatalf("expected addr empty object: %s", b)
	}
}

func TestProtoRoundTrip(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "alice")
	m.Set("age", int32(-30))
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Set("scores", []int32{90, -95})
	m.Set("data", []byte("hello"))
	m.Set("height", 1.75)
	m.Set("weight", float32(68.5))
	m.Set("active", true)
	m.Set("big", int64(-1234567890123))
	m.Set("bigu", uint64(18446744073709551615))

	b, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(1001)
	if err := m2.DecodeProto(b); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m2.Get("name").String() != "alice" {
		t.Fatalf("name = %q", m2.Get("name").String())
	}
	if m2.Get("age").Int32() != -30 {
		t.Fatalf("age = %v", m2.Get("age").Int32())
	}
	if m2.Get("addr.city").String() != "beijing" {
		t.Fatalf("addr.city = %q", m2.Get("addr.city").String())
	}
	if v := m2.Get("tags"); v.Len() != 2 || v.Index(0).String() != "a" {
		t.Fatalf("tags = %+v", v)
	}
	if v := m2.Get("scores"); v.Len() != 2 || v.Index(0).Int32() != 90 || v.Index(1).Int32() != -95 {
		t.Fatalf("scores = %+v", v)
	}
	if string(m2.Get("data").Bytes()) != "hello" {
		t.Fatalf("data = %q", string(m2.Get("data").Bytes()))
	}
	if math.Abs(m2.Get("height").Float64()-1.75) > 1e-9 {
		t.Fatalf("height = %v", m2.Get("height").Float64())
	}
	if math.Abs(float64(m2.Get("weight").Float32())-68.5) > 1e-4 {
		t.Fatalf("weight = %v", m2.Get("weight").Float32())
	}
	if !m2.Get("active").Bool() {
		t.Fatal("active should be true")
	}
	if m2.Get("big").Int64() != -1234567890123 {
		t.Fatalf("big = %v", m2.Get("big").Int64())
	}
	if m2.Get("bigu").Uint64() != 18446744073709551615 {
		t.Fatalf("bigu = %v", m2.Get("bigu").Uint64())
	}
}

func TestProtoEmptyMessage(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeProto(nil); err != nil {
		t.Fatalf("DecodeProto empty: %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields: %v", m.SetFields())
	}
}

func TestProtoErrors(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// field number 0
	if err := m.DecodeProto([]byte{0}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("field 0: got %v", err)
	}
	// invalid wire type 6
	if err := m.DecodeProto([]byte{0x0e}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire type 6: got %v", err)
	}
	// invalid wire type 7
	if err := m.DecodeProto([]byte{0x0f}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire type 7: got %v", err)
	}
	// wire type mismatch: name is string (wt 2), but use wt 0
	if err := m.DecodeProto([]byte{0x08, 0x01}); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("wire type mismatch: got %v", err)
	}
	// truncated length-delimited
	// field 1 (name), wt 2, key = (1<<3)|2 = 0x0a, then length 10 but only 3 bytes
	if err := m.DecodeProto([]byte{0x0a, 0x0a, 'a', 'b', 'c'}); !errors.Is(err, ErrTruncated) {
		t.Fatalf("truncated: got %v", err)
	}
}

func TestProtoSkipUnknown(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// unknown field num 100, wt 0, varint 5
	// then known field name = "ok"
	// key for field 100 wt0 = (100<<3)|0 = 800 -> varint: 800 = 0b1100100000, low 7 bits 0x20, continue, next 0x06
	data := []byte{0xa0, 0x06, 0x05, 0x0a, 0x02, 'o', 'k'}
	if err := m.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto skip unknown: %v", err)
	}
	if m.Get("name").String() != "ok" {
		t.Fatalf("name = %q", m.Get("name").String())
	}
}

func TestProtoPackedUnpackedMix(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// scores field num 5, wt 2 packed: key=(5<<3)|2=0x2a, length 4, varints [1,2,3,4]
	// then unpacked: key=(5<<3)|0=0x28, varint 5
	data := []byte{0x2a, 0x04, 0x01, 0x02, 0x03, 0x04, 0x28, 0x05}
	if err := m.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto packed: %v", err)
	}
	v := m.Get("scores")
	if v.Len() != 5 || v.Index(4).Int32() != 5 {
		t.Fatalf("scores = %+v", v)
	}
}

func TestDeepCopyNested(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	src, _ := New(1001)
	src.Set("addr.city", "beijing")
	src.Set("tags", []string{"a", "b"})
	if err := m.Set("", src); err != nil {
		t.Fatalf("Set whole: %v", err)
	}
	// mutate source
	src.Set("addr.city", "shanghai")
	src.Append("tags", "c")
	if m.Get("addr.city").String() != "beijing" {
		t.Fatalf("nested deep copy failed: %q", m.Get("addr.city").String())
	}
	if v := m.Get("tags"); v.Len() != 2 {
		t.Fatalf("tags deep copy failed: %d", v.Len())
	}
}

func TestConvertAlias(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	type MyInt int32
	if err := m.Set("age", MyInt(42)); err != nil {
		t.Fatalf("Set alias: %v", err)
	}
	if v := m.Get("age"); v.Int32() != 42 {
		t.Fatalf("age = %v", v.Int32())
	}
}

func TestFloatToIntTruncation(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("age", 3.9); err != nil {
		t.Fatalf("Set float to int: %v", err)
	}
	if v := m.Get("age"); v.Int32() != 3 {
		t.Fatalf("age = %v", v.Int32())
	}
	if err := m.Set("age", math.NaN()); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set NaN to int: got %v", err)
	}
}

func TestValueGettersWrongType(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	if v := m.Get("name"); v.Int32() != 0 || v.Bool() != false || v.Float64() != 0 {
		t.Fatalf("wrong-type getters should return zero")
	}
	if v := m.Get("name"); v.Bytes() != nil || v.Message() != nil {
		t.Fatalf("wrong-type getters should return nil")
	}
}

func TestConcurrentNew(t *testing.T) {
	mustParseAndRegister(t)
	done := make(chan struct{})
	for i := 0; i < 20; i++ {
		go func() {
			for j := 0; j < 100; j++ {
				m, err := New(1001)
				if err != nil {
					t.Errorf("New: %v", err)
					break
				}
				m.Set("name", "x")
			}
			done <- struct{}{}
		}()
	}
	for i := 0; i < 20; i++ {
		<-done
	}
}

func TestMessageNilElementAppend(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	var nilContact *Message
	if err := m.Append("contacts", nilContact); err != nil {
		t.Fatalf("Append nil contact: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 1 || v.Index(0).Message() != nil {
		t.Fatalf("contacts: %+v", v)
	}
	// appending untyped nil should error
	if err := m.Append("contacts", nil); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append untyped nil: got %v", err)
	}
}

func TestSetIndexedElement(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Append("tags", "a")
	m.Append("tags", "b")
	if err := m.Set("tags[1]", "z"); err != nil {
		t.Fatalf("Set tags[1]: %v", err)
	}
	if v := m.Get("tags"); v.Index(1).String() != "z" {
		t.Fatalf("tags[1] = %q", v.Index(1).String())
	}
}

func TestSetBytesCopied(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	src := []byte("hello")
	if err := m.Set("data", src); err != nil {
		t.Fatalf("Set data: %v", err)
	}
	src[0] = 'X'
	if string(m.Get("data").Bytes()) != "hello" {
		t.Fatalf("bytes not copied: %q", string(m.Get("data").Bytes()))
	}
}

func TestStringToBytes(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("data", "hello"); err != nil {
		t.Fatalf("Set data from string: %v", err)
	}
	if string(m.Get("data").Bytes()) != "hello" {
		t.Fatalf("data = %q", string(m.Get("data").Bytes()))
	}
	if err := m.Set("name", []byte("world")); err != nil {
		t.Fatalf("Set name from bytes: %v", err)
	}
	if m.Get("name").String() != "world" {
		t.Fatalf("name = %q", m.Get("name").String())
	}
}

func TestSetRepeatedMessages(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// contacts schema has field "phone". We'll construct via a sub-message.
	contact := newMessage(&m.schema.Fields[5].Schema)
	contact.Set("phone", "111")
	contact2 := newMessage(&m.schema.Fields[5].Schema)
	contact2.Set("phone", "222")
	if err := m.Set("contacts", []*Message{contact, nil, contact2}); err != nil {
		t.Fatalf("Set contacts: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 3 {
		t.Fatalf("contacts len = %d", v.Len())
	}
	if v.Index(0).Message() == nil || v.Index(0).Message().Get("phone").String() != "111" {
		t.Fatalf("contacts[0] wrong")
	}
	if v.Index(1).Message() != nil {
		t.Fatal("contacts[1] should be nil")
	}
	if v.Index(2).Message().Get("phone").String() != "222" {
		t.Fatal("contacts[2] wrong")
	}
}

func TestSchemaMismatchSetMessage(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// wrong schema message
	schemas, _ := ParseSchema([]byte(`{"types":[{"typeId":2001,"fields":[{"name":"x","type":"int32","num":1}]}]}`))
	Register(schemas[0])
	other, _ := New(2001)
	if err := m.Set("addr", other); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set addr wrong schema: got %v", err)
	}
}

func TestJSONTopLevelNonObject(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	for _, in := range []string{`[]`, `"x"`, `123`, `true`} {
		if err := m.DecodeJSON([]byte(in)); !errors.Is(err, ErrMalformedData) {
			t.Errorf("DecodeJSON(%q) = %v, want ErrMalformedData", in, err)
		}
	}
}

func TestEmptySchemaMessage(t *testing.T) {
	schemas, err := ParseSchema([]byte(`{"types":[{"typeId":3001,"fields":[]}]}`))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, _ := New(3001)
	b, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	if string(b) != "{}" {
		t.Fatalf("empty message JSON = %s", b)
	}
	bp, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	if len(bp) != 0 {
		t.Fatalf("empty message proto = %v", bp)
	}
}

func TestProtoRoundTripRepeatedBytes(t *testing.T) {
	schemas, err := ParseSchema([]byte(`{"types":[{"typeId":4001,"fields":[{"name":"blobs","type":"bytes","num":1,"repeated":true}]}]}`))
	if err != nil {
		t.Fatal(err)
	}
	Register(schemas[0])
	m, _ := New(4001)
	m.Set("blobs", [][]byte{{1, 2}, {3, 4}})
	b, err := m.EncodeProto()
	if err != nil {
		t.Fatal(err)
	}
	m2, _ := New(4001)
	if err := m2.DecodeProto(b); err != nil {
		t.Fatal(err)
	}
	if v := m2.Get("blobs"); v.Len() != 2 || !bytes.Equal(v.Index(0).Bytes(), []byte{1, 2}) {
		t.Fatalf("blobs = %+v", v)
	}
}

func TestValueIndexOnNonSlice(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	if v := m.Get("name").Index(0); v.Err() != ErrIndexOutOfRange {
		t.Fatalf("Index on scalar: got %v", v.Err())
	}
	if v := m.Get("name").Len(); v != 0 {
		t.Fatalf("Len on scalar: got %d", v)
	}
}

func TestSetFieldsEmpty(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if len(m.SetFields()) != 0 {
		t.Fatalf("SetFields = %v", m.SetFields())
	}
}

func TestJSONRepeatedScalarNullError(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeJSON([]byte(`{"scores":[1,null]}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("got %v", err)
	}
}

func TestProtoUint32RoundTrip(t *testing.T) {
	schemas, err := ParseSchema([]byte(`{"types":[{"typeId":5001,"fields":[{"name":"u32","type":"uint32","num":1}]}]}`))
	if err != nil {
		t.Fatal(err)
	}
	Register(schemas[0])
	m, _ := New(5001)
	m.Set("u32", uint32(4000000000))
	b, _ := m.EncodeProto()
	m2, _ := New(5001)
	if err := m2.DecodeProto(b); err != nil {
		t.Fatal(err)
	}
	if m2.Get("u32").Uint32() != 4000000000 {
		t.Fatalf("u32 = %v", m2.Get("u32").Uint32())
	}
}

func TestLenAndSliceGettersUnset(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if v := m.Get("tags"); v.Len() != 0 || v.Strings() != nil {
		t.Fatalf("unset tags: len=%d strings=%v", v.Len(), v.Strings())
	}
	if v := m.Get("scores"); v.Int32s() != nil {
		t.Fatalf("unset scores: %v", v.Int32s())
	}
	if v := m.Get("contacts"); v.Messages() != nil {
		t.Fatalf("unset contacts: %v", v.Messages())
	}
}

func TestDecodeJSONReplaces(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	m.Set("age", int32(10))
	if err := m.DecodeJSON([]byte(`{"name":"y"}`)); err != nil {
		t.Fatal(err)
	}
	if m.Get("name").String() != "y" {
		t.Fatalf("name = %q", m.Get("name").String())
	}
	if m.Has("age") {
		t.Fatal("age should be cleared")
	}
}

func TestDecodeProtoReplaces(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("name", "x")
	m.Set("age", int32(10))
	// encode only age
	other, _ := New(1001)
	other.Set("age", int32(20))
	b, _ := other.EncodeProto()
	if err := m.DecodeProto(b); err != nil {
		t.Fatal(err)
	}
	if m.Has("name") {
		t.Fatal("name should be cleared")
	}
	if m.Get("age").Int32() != 20 {
		t.Fatalf("age = %v", m.Get("age").Int32())
	}
}

func TestProtoEmptyPackedSetsField(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	// field 5 (scores), wt 2 (packed), length 0
	if err := m.DecodeProto([]byte{0x2a, 0x00}); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if !m.Has("scores") {
		t.Fatal("scores should be set after empty packed field")
	}
	if v := m.Get("scores"); v.Len() != 0 {
		t.Fatalf("scores len = %d", v.Len())
	}
}

func TestDecodeJSONFloatOverflow(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.DecodeJSON([]byte(`{"weight":1e39}`)); !errors.Is(err, ErrMalformedData) {
		t.Fatalf("DecodeJSON weight overflow: got %v", err)
	}
}

func TestSetScalarRepeatedNilElement(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	if err := m.Set("scores", []any{nil, int32(1)}); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Set scores with nil element: got %v", err)
	}
}

func TestProtoRepeatedMessageRoundTrip(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	contact := newMessage(&m.schema.Fields[5].Schema)
	contact.Set("phone", "111")
	var nilContact *Message
	if err := m.Set("contacts", []*Message{contact, nilContact, contact}); err != nil {
		t.Fatalf("Set contacts: %v", err)
	}
	b, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m2, _ := New(1001)
	if err := m2.DecodeProto(b); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	v := m2.Get("contacts")
	if v.Len() != 2 { // nil element skipped in encoding
		t.Fatalf("contacts len = %d, want 2", v.Len())
	}
	if v.Index(0).Message() == nil || v.Index(0).Message().Get("phone").String() != "111" {
		t.Fatalf("contacts[0] wrong")
	}
}

func TestSetDescendIntoTypedNilMessageElement(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	var c *Message
	m.Append("contacts", c)
	if err := m.Set("contacts[0].phone", "123"); err != nil {
		t.Fatalf("Set contacts[0].phone: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 1 || v.Index(0).Message() == nil {
		t.Fatalf("contacts: %+v", v)
	}
	if v.Index(0).Message().Get("phone").String() != "123" {
		t.Fatalf("phone = %q", v.Index(0).Message().Get("phone").String())
	}
}

func TestAppendDescendIntoTypedNilMessageElement(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	var c *Message
	m.Append("contacts", c)
	// Append to a field inside the nil element should auto-create the element
	// and then append to the nested repeated field. Here contacts has only "phone",
	// which is non-repeated, so Append should return ErrTypeMismatch.
	if err := m.Append("contacts[0].phone", "x"); !errors.Is(err, ErrTypeMismatch) {
		t.Fatalf("Append contacts[0].phone: got %v", err)
	}
}

func TestClearDescendIntoTypedNilMessageElement(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	var c *Message
	m.Append("contacts", c)
	// Clearing a field inside a nil element is idempotent.
	if err := m.Clear("contacts[0].phone"); err != nil {
		t.Fatalf("Clear contacts[0].phone: %v", err)
	}
}

func TestDeepCopyRepeatedMessage(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	contact := newMessage(&m.schema.Fields[5].Schema)
	contact.Set("phone", "111")
	if err := m.Set("contacts", []*Message{contact}); err != nil {
		t.Fatalf("Set contacts: %v", err)
	}
	// mutate source
	contact.Set("phone", "999")
	if got := m.Get("contacts").Index(0).Message().Get("phone").String(); got != "111" {
		t.Fatalf("repeated message deep copy failed: %q", got)
	}
}

func TestGetIndexedNestedField(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	contact := newMessage(&m.schema.Fields[5].Schema)
	contact.Set("phone", "555")
	m.Set("contacts", []*Message{contact})
	if v := m.Get("contacts[0].phone"); v.String() != "555" {
		t.Fatalf("contacts[0].phone = %q", v.String())
	}
}

func TestConcurrentRegister(t *testing.T) {
	schemas, err := ParseSchema([]byte(`{"types":[{"typeId":6001,"fields":[{"name":"x","type":"int32","num":1}]}]}`))
	if err != nil {
		t.Fatal(err)
	}
	done := make(chan struct{})
	for i := 0; i < 20; i++ {
		go func() {
			for j := 0; j < 20; j++ {
				if err := Register(schemas[0]); err != nil {
					t.Errorf("Register: %v", err)
					break
				}
			}
			done <- struct{}{}
		}()
	}
	for i := 0; i < 20; i++ {
		<-done
	}
	if _, err := New(6001); err != nil {
		t.Fatalf("New after concurrent Register: %v", err)
	}
}

func TestManualSchemaRegister(t *testing.T) {
	s := MessageSchema{
		TypeID: 7001,
		Fields: []FieldSchema{
			{Name: "a", Num: 1, Type: FieldInt32},
			{Name: "b", Num: 2, Type: FieldString, Repeated: true},
		},
	}
	if err := Register(s); err != nil {
		t.Fatalf("Register manual: %v", err)
	}
	m, err := New(7001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if err := m.Set("a", int32(7)); err != nil {
		t.Fatalf("Set a: %v", err)
	}
	if err := m.Append("b", "x"); err != nil {
		t.Fatalf("Append b: %v", err)
	}
	if m.Get("a").Int32() != 7 || m.Get("b").Index(0).String() != "x" {
		t.Fatalf("manual schema message wrong")
	}
}

func TestJSONOrdering(t *testing.T) {
	mustParseAndRegister(t)
	m, _ := New(1001)
	m.Set("active", true)
	m.Set("name", "x")
	b, _ := m.EncodeJSON()
	s := string(b)
	if strings.Index(s, `"name"`) > strings.Index(s, `"active"`) {
		t.Fatalf("fields not in schema order: %s", s)
	}
}
