package dymsg

import (
	"encoding/binary"
	"math"
	"reflect"
)

func appendVarint(buf []byte, v uint64) []byte {
	for v >= 0x80 {
		buf = append(buf, byte(v)|0x80)
		v >>= 7
	}
	return append(buf, byte(v))
}

func appendKey(buf []byte, num int, wt int) []byte {
	return appendVarint(buf, uint64(num)<<3|uint64(wt))
}

func readVarint(data []byte) (uint64, int, error) {
	var x uint64
	for i := 0; i < len(data) && i < 10; i++ {
		b := data[i]
		if i == 9 && b > 1 {
			// 10th byte may only carry bit 63; anything more overflows uint64.
			return 0, 0, ErrMalformedData
		}
		x |= uint64(b&0x7f) << (7 * uint(i))
		if b&0x80 == 0 {
			return x, i + 1, nil
		}
	}
	if len(data) < 10 {
		return 0, 0, ErrTruncated
	}
	return 0, 0, ErrMalformedData
}

func appendLittleEndian32(buf []byte, v uint32) []byte {
	return binary.LittleEndian.AppendUint32(buf, v)
}

func appendLittleEndian64(buf []byte, v uint64) []byte {
	return binary.LittleEndian.AppendUint64(buf, v)
}

func wireTypeFor(t FieldType) int {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		return 0
	case FieldDouble:
		return 1
	case FieldString, FieldBytes, FieldMessage:
		return 2
	case FieldFloat:
		return 5
	}
	return 0
}

func isPackableScalar(t FieldType) bool {
	switch t {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool, FieldFloat, FieldDouble:
		return true
	}
	return false
}

func (m *Message) EncodeProto() ([]byte, error) {
	var buf []byte
	for i, ok := range m.set {
		if !ok {
			continue
		}
		fs := &m.schema.Fields[i]
		if fs.Type == FieldMessage && !fs.Repeated {
			msg, _ := m.vals[i].(*Message)
			if msg == nil {
				continue
			}
		}
		if err := m.writeProtoField(&buf, i, fs); err != nil {
			return nil, err
		}
	}
	return buf, nil
}

func (m *Message) writeProtoField(buf *[]byte, idx int, fs *FieldSchema) error {
	val := m.vals[idx]
	num := fs.Num
	if fs.Repeated {
		if isPackableScalar(fs.Type) {
			var payload []byte
			rv := reflect.ValueOf(val)
			n := rv.Len()
			for i := 0; i < n; i++ {
				elem := rv.Index(i).Interface()
				switch fs.Type {
				case FieldInt32:
					payload = appendVarint(payload, uint64(int64(elem.(int32))))
				case FieldInt64:
					payload = appendVarint(payload, uint64(elem.(int64)))
				case FieldUint32:
					payload = appendVarint(payload, uint64(elem.(uint32)))
				case FieldUint64:
					payload = appendVarint(payload, elem.(uint64))
				case FieldBool:
					if elem.(bool) {
						payload = appendVarint(payload, 1)
					} else {
						payload = appendVarint(payload, 0)
					}
				case FieldFloat:
					payload = appendLittleEndian32(payload, math.Float32bits(elem.(float32)))
				case FieldDouble:
					payload = appendLittleEndian64(payload, math.Float64bits(elem.(float64)))
				}
			}
			*buf = appendKey(*buf, num, 2)
			*buf = appendVarint(*buf, uint64(len(payload)))
			*buf = append(*buf, payload...)
			return nil
		}
		// repeated string/bytes/message: one key per element
		rv := reflect.ValueOf(val)
		n := rv.Len()
		for i := 0; i < n; i++ {
			elem := rv.Index(i).Interface()
			switch fs.Type {
			case FieldString:
				s := elem.(string)
				*buf = appendKey(*buf, num, 2)
				*buf = appendVarint(*buf, uint64(len(s)))
				*buf = append(*buf, s...)
			case FieldBytes:
				b := elem.([]byte)
				*buf = appendKey(*buf, num, 2)
				*buf = appendVarint(*buf, uint64(len(b)))
				*buf = append(*buf, b...)
			case FieldMessage:
				msg, _ := elem.(*Message)
				if msg == nil {
					continue
				}
				inner, err := msg.EncodeProto()
				if err != nil {
					return err
				}
				*buf = appendKey(*buf, num, 2)
				*buf = appendVarint(*buf, uint64(len(inner)))
				*buf = append(*buf, inner...)
			}
		}
		return nil
	}
	switch fs.Type {
	case FieldInt32:
		*buf = appendKey(*buf, num, 0)
		*buf = appendVarint(*buf, uint64(int64(val.(int32))))
	case FieldInt64:
		*buf = appendKey(*buf, num, 0)
		*buf = appendVarint(*buf, uint64(val.(int64)))
	case FieldUint32:
		*buf = appendKey(*buf, num, 0)
		*buf = appendVarint(*buf, uint64(val.(uint32)))
	case FieldUint64:
		*buf = appendKey(*buf, num, 0)
		*buf = appendVarint(*buf, val.(uint64))
	case FieldBool:
		*buf = appendKey(*buf, num, 0)
		if val.(bool) {
			*buf = appendVarint(*buf, 1)
		} else {
			*buf = appendVarint(*buf, 0)
		}
	case FieldFloat:
		*buf = appendKey(*buf, num, 5)
		*buf = appendLittleEndian32(*buf, math.Float32bits(val.(float32)))
	case FieldDouble:
		*buf = appendKey(*buf, num, 1)
		*buf = appendLittleEndian64(*buf, math.Float64bits(val.(float64)))
	case FieldString:
		s := val.(string)
		*buf = appendKey(*buf, num, 2)
		*buf = appendVarint(*buf, uint64(len(s)))
		*buf = append(*buf, s...)
	case FieldBytes:
		b := val.([]byte)
		*buf = appendKey(*buf, num, 2)
		*buf = appendVarint(*buf, uint64(len(b)))
		*buf = append(*buf, b...)
	case FieldMessage:
		msg, _ := val.(*Message)
		if msg == nil {
			return nil
		}
		inner, err := msg.EncodeProto()
		if err != nil {
			return err
		}
		*buf = appendKey(*buf, num, 2)
		*buf = appendVarint(*buf, uint64(len(inner)))
		*buf = append(*buf, inner...)
	}
	return nil
}

func (m *Message) DecodeProto(data []byte) error {
	m.clearAll()
	pos := 0
	for pos < len(data) {
		key, n, err := readVarint(data[pos:])
		if err != nil {
			return err
		}
		pos += n
		num := int(key >> 3)
		wt := int(key & 7)
		if num == 0 {
			return ErrMalformedData
		}
		if wt == 6 || wt == 7 {
			return ErrMalformedData
		}
		fi, ok := m.schema.fieldIndexByNum(num)
		if !ok {
			pos, err = skipUnknown(data, pos, wt)
			if err != nil {
				return err
			}
			continue
		}
		fs := &m.schema.Fields[fi]
		if isPackableScalar(fs.Type) && fs.Repeated {
			if wt == 2 {
				length, n, err := readVarint(data[pos:])
				if err != nil {
					return err
				}
				pos += n
				if uint64(len(data)-pos) < length {
					return ErrTruncated
				}
				if !m.set[fi] {
					m.vals[fi] = emptySlice(fs.Type)
					m.set[fi] = true
				}
				if err := m.decodePackedScalars(data[pos:pos+int(length)], fi, fs); err != nil {
					return err
				}
				pos += int(length)
			} else if wt == wireTypeFor(fs.Type) {
				pos, err = m.decodeField(data, pos, fi, fs)
				if err != nil {
					return err
				}
			} else {
				return ErrMalformedData
			}
		} else {
			expected := wireTypeFor(fs.Type)
			if wt != expected {
				return ErrMalformedData
			}
			pos, err = m.decodeField(data, pos, fi, fs)
			if err != nil {
				return err
			}
		}
	}
	return nil
}

func skipUnknown(data []byte, pos int, wt int) (int, error) {
	switch wt {
	case 0:
		_, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		return pos + n, nil
	case 1:
		if len(data)-pos < 8 {
			return 0, ErrTruncated
		}
		return pos + 8, nil
	case 2:
		length, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		pos += n
		if uint64(len(data)-pos) < length {
			return 0, ErrTruncated
		}
		return pos + int(length), nil
	case 5:
		if len(data)-pos < 4 {
			return 0, ErrTruncated
		}
		return pos + 4, nil
	}
	return 0, ErrMalformedData
}

func (m *Message) decodePackedScalars(payload []byte, fi int, fs *FieldSchema) error {
	pos := 0
	for pos < len(payload) {
		switch fs.Type {
		case FieldInt32:
			v, n, err := readVarint(payload[pos:])
			if err != nil {
				return err
			}
			m.appendFieldElement(fi, fs, int32(int64(v)))
			pos += n
		case FieldInt64:
			v, n, err := readVarint(payload[pos:])
			if err != nil {
				return err
			}
			m.appendFieldElement(fi, fs, int64(v))
			pos += n
		case FieldUint32:
			v, n, err := readVarint(payload[pos:])
			if err != nil {
				return err
			}
			m.appendFieldElement(fi, fs, uint32(v))
			pos += n
		case FieldUint64:
			v, n, err := readVarint(payload[pos:])
			if err != nil {
				return err
			}
			m.appendFieldElement(fi, fs, v)
			pos += n
		case FieldBool:
			v, n, err := readVarint(payload[pos:])
			if err != nil {
				return err
			}
			m.appendFieldElement(fi, fs, v != 0)
			pos += n
		case FieldFloat:
			if len(payload)-pos < 4 {
				return ErrTruncated
			}
			bits := binary.LittleEndian.Uint32(payload[pos:])
			m.appendFieldElement(fi, fs, math.Float32frombits(bits))
			pos += 4
		case FieldDouble:
			if len(payload)-pos < 8 {
				return ErrTruncated
			}
			bits := binary.LittleEndian.Uint64(payload[pos:])
			m.appendFieldElement(fi, fs, math.Float64frombits(bits))
			pos += 8
		}
	}
	return nil
}

func (m *Message) decodeField(data []byte, pos int, fi int, fs *FieldSchema) (int, error) {
	switch fs.Type {
	case FieldInt32:
		v, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		val := int32(int64(v))
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + n, nil
	case FieldInt64:
		v, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		val := int64(v)
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + n, nil
	case FieldUint32:
		v, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		val := uint32(v)
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + n, nil
	case FieldUint64:
		v, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		val := v
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + n, nil
	case FieldBool:
		v, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		val := v != 0
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + n, nil
	case FieldFloat:
		if len(data)-pos < 4 {
			return 0, ErrTruncated
		}
		val := math.Float32frombits(binary.LittleEndian.Uint32(data[pos:]))
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + 4, nil
	case FieldDouble:
		if len(data)-pos < 8 {
			return 0, ErrTruncated
		}
		val := math.Float64frombits(binary.LittleEndian.Uint64(data[pos:]))
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos + 8, nil
	case FieldString:
		length, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		pos += n
		if uint64(len(data)-pos) < length {
			return 0, ErrTruncated
		}
		val := string(data[pos : pos+int(length)])
		pos += int(length)
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos, nil
	case FieldBytes:
		length, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		pos += n
		if uint64(len(data)-pos) < length {
			return 0, ErrTruncated
		}
		val := append([]byte(nil), data[pos:pos+int(length)]...)
		pos += int(length)
		if fs.Repeated {
			m.appendFieldElement(fi, fs, val)
		} else {
			m.set[fi] = true
			m.vals[fi] = val
		}
		return pos, nil
	case FieldMessage:
		length, n, err := readVarint(data[pos:])
		if err != nil {
			return 0, err
		}
		pos += n
		if uint64(len(data)-pos) < length {
			return 0, ErrTruncated
		}
		sub := newMessage(&fs.Schema)
		if err := sub.DecodeProto(data[pos : pos+int(length)]); err != nil {
			return 0, err
		}
		pos += int(length)
		if fs.Repeated {
			m.appendFieldElement(fi, fs, sub)
		} else {
			m.set[fi] = true
			m.vals[fi] = sub
		}
		return pos, nil
	}
	return 0, ErrMalformedData
}

func (m *Message) appendFieldElement(fi int, fs *FieldSchema, val any) {
	if !m.set[fi] {
		m.vals[fi] = emptySlice(fs.Type)
		m.set[fi] = true
	}
	m.vals[fi] = appendToSlice(m.vals[fi], val)
}
