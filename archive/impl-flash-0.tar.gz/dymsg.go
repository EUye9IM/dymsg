package dymsg

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"math"
	"reflect"
	"strconv"
	"strings"
	"sync"
)

// FieldType is the dynamic field type.
type FieldType string

const (
	FieldInt32   FieldType = "int32"
	FieldInt64   FieldType = "int64"
	FieldUint32  FieldType = "uint32"
	FieldUint64  FieldType = "uint64"
	FieldFloat   FieldType = "float"
	FieldDouble  FieldType = "double"
	FieldBool    FieldType = "bool"
	FieldString  FieldType = "string"
	FieldBytes   FieldType = "bytes"
	FieldMessage FieldType = "message"
)

// Sentinel errors.
var (
	ErrDuplicateID     = errors.New("dymsg: duplicate type id with different schema")
	ErrUnknownTypeID   = errors.New("dymsg: unknown type id")
	ErrFieldNotFound   = errors.New("dymsg: field not found or invalid path")
	ErrIndexOutOfRange = errors.New("dymsg: index out of range")
	ErrTypeMismatch    = errors.New("dymsg: type mismatch")
	ErrMalformedData   = errors.New("dymsg: malformed data")
	ErrTruncated       = errors.New("dymsg: truncated data")
)

// FieldSchema describes a single field in a message schema.
type FieldSchema struct {
	Name     string
	Num      int
	Type     FieldType
	Repeated bool
	Schema   MessageSchema
}

// MessageSchema describes the structure of a message type.
type MessageSchema struct {
	TypeID uint16
	Fields []FieldSchema

	byName map[string]int
	byNum  map[int]int
}

func (s *MessageSchema) init() {
	if s.byName != nil {
		return
	}
	s.byName = make(map[string]int, len(s.Fields))
	s.byNum = make(map[int]int, len(s.Fields))
	for i := range s.Fields {
		f := &s.Fields[i]
		s.byName[f.Name] = i
		s.byNum[f.Num] = i
		if f.Type == FieldMessage {
			f.Schema.init()
		}
	}
}

func (s *MessageSchema) fieldIndexByName(name string) (int, bool) {
	if s == nil || s.byName == nil {
		return 0, false
	}
	i, ok := s.byName[name]
	return i, ok
}

func (s *MessageSchema) fieldIndexByNum(num int) (int, bool) {
	if s == nil || s.byNum == nil {
		return 0, false
	}
	i, ok := s.byNum[num]
	return i, ok
}

func cloneSchema(s *MessageSchema) *MessageSchema {
	c := &MessageSchema{
		TypeID: s.TypeID,
		Fields: make([]FieldSchema, len(s.Fields)),
	}
	for i, f := range s.Fields {
		c.Fields[i] = f
		if f.Type == FieldMessage {
			c.Fields[i].Schema = *cloneSchema(&f.Schema)
		}
	}
	c.init()
	return c
}

func schemaEquals(a, b *MessageSchema) bool {
	if a == nil || b == nil {
		return a == b
	}
	if len(a.Fields) != len(b.Fields) {
		return false
	}
	for i := range a.Fields {
		fa, fb := &a.Fields[i], &b.Fields[i]
		if fa.Name != fb.Name || fa.Num != fb.Num || fa.Type != fb.Type || fa.Repeated != fb.Repeated {
			return false
		}
		if fa.Type == FieldMessage {
			if !schemaEquals(&fa.Schema, &fb.Schema) {
				return false
			}
		}
	}
	return true
}

// Message is a structured message instance carrying a schema and field values.
type Message struct {
	schema *MessageSchema
	set    []bool
	vals   []any
}

func newMessage(schema *MessageSchema) *Message {
	n := len(schema.Fields)
	return &Message{
		schema: schema,
		set:    make([]bool, n),
		vals:   make([]any, n),
	}
}

func (m *Message) clearAll() {
	for i := range m.set {
		m.set[i] = false
		m.vals[i] = nil
	}
}

// Value is the result of a field read.
type Value struct {
	exists   bool
	isSet    bool
	err      error
	typ      FieldType
	repeated bool
	value    any
}

// Exists reports whether the path resolved to an existing field/element.
func (v Value) Exists() bool { return v.exists }

// IsSet reports whether the field/element has been explicitly set.
func (v Value) IsSet() bool { return v.isSet }

// Err returns the path-resolution or lookup error, nil on success.
func (v Value) Err() error { return v.err }

// Any returns the native Go value of the field.
func (v Value) Any() any {
	if !v.exists || !v.isSet {
		return nil
	}
	return v.value
}

func (v Value) String() string {
	if !v.exists || !v.isSet {
		return ""
	}
	s, _ := v.value.(string)
	return s
}

func (v Value) Int32() int32 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(int32)
	return x
}

func (v Value) Int64() int64 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(int64)
	return x
}

func (v Value) Uint32() uint32 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(uint32)
	return x
}

func (v Value) Uint64() uint64 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(uint64)
	return x
}

func (v Value) Float32() float32 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(float32)
	return x
}

func (v Value) Float64() float64 {
	if !v.exists || !v.isSet {
		return 0
	}
	x, _ := v.value.(float64)
	return x
}

func (v Value) Bool() bool {
	if !v.exists || !v.isSet {
		return false
	}
	x, _ := v.value.(bool)
	return x
}

func (v Value) Bytes() []byte {
	if !v.exists || !v.isSet {
		return nil
	}
	x, _ := v.value.([]byte)
	return x
}

func (v Value) Message() *Message {
	if !v.exists || !v.isSet {
		return nil
	}
	m, _ := v.value.(*Message)
	return m
}

func (v Value) Len() int {
	if !v.exists || !v.isSet {
		return 0
	}
	rv := reflect.ValueOf(v.value)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return 0
	}
	return rv.Len()
}

func (v Value) Index(i int) Value {
	if !v.exists || !v.isSet {
		return Value{err: ErrIndexOutOfRange}
	}
	rv := reflect.ValueOf(v.value)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return Value{err: ErrIndexOutOfRange}
	}
	if i < 0 || i >= rv.Len() {
		return Value{err: ErrIndexOutOfRange}
	}
	elem := rv.Index(i).Interface()
	if v.typ == FieldMessage {
		msg, _ := elem.(*Message)
		if msg == nil {
			return Value{exists: true, isSet: false, typ: FieldMessage}
		}
		return Value{exists: true, isSet: true, typ: FieldMessage, value: msg}
	}
	return Value{exists: true, isSet: true, typ: v.typ, value: elem}
}

func (v Value) Strings() []string {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]string)
	return s
}

func (v Value) Int32s() []int32 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]int32)
	return s
}

func (v Value) Int64s() []int64 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]int64)
	return s
}

func (v Value) Uint32s() []uint32 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]uint32)
	return s
}

func (v Value) Uint64s() []uint64 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]uint64)
	return s
}

func (v Value) Float32s() []float32 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]float32)
	return s
}

func (v Value) Float64s() []float64 {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]float64)
	return s
}

func (v Value) Bools() []bool {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]bool)
	return s
}

func (v Value) BytesSlice() [][]byte {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([][]byte)
	return s
}

func (v Value) Messages() []*Message {
	if !v.exists || !v.isSet {
		return nil
	}
	s, _ := v.value.([]*Message)
	return s
}

// --- path parsing ---

type pathStep struct {
	name     string
	index    int
	hasIndex bool
}

func parsePath(path string) ([]pathStep, error) {
	if path == "" {
		return nil, nil
	}
	parts := strings.Split(path, ".")
	steps := make([]pathStep, 0, len(parts))
	for _, part := range parts {
		if part == "" {
			return nil, ErrFieldNotFound
		}
		if idx := strings.IndexByte(part, '['); idx >= 0 {
			name := part[:idx]
			if name == "" {
				return nil, ErrFieldNotFound
			}
			end := strings.IndexByte(part, ']')
			if end < 0 {
				return nil, ErrFieldNotFound
			}
			if end != len(part)-1 {
				return nil, ErrFieldNotFound
			}
			inner := part[idx+1 : end]
			if inner == "" {
				return nil, ErrIndexOutOfRange
			}
			if inner[0] == '-' {
				return nil, ErrIndexOutOfRange
			}
			n := 0
			for _, c := range inner {
				if c < '0' || c > '9' {
					return nil, ErrIndexOutOfRange
				}
				n = n*10 + int(c-'0')
				if n > 1<<30 {
					return nil, ErrIndexOutOfRange
				}
			}
			steps = append(steps, pathStep{name: name, index: n, hasIndex: true})
		} else {
			steps = append(steps, pathStep{name: part})
		}
	}
	return steps, nil
}

// --- Get ---

func (m *Message) Get(path string) Value {
	steps, err := parsePath(path)
	if err != nil {
		return Value{err: err}
	}
	if len(steps) == 0 {
		return Value{exists: true, isSet: true, typ: FieldMessage, value: m}
	}
	cur := m
	for i, step := range steps {
		last := i == len(steps)-1
		fi, ok := cur.schema.fieldIndexByName(step.name)
		if !ok {
			return Value{err: ErrFieldNotFound}
		}
		fs := &cur.schema.Fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			if !cur.set[fi] {
				return Value{exists: false, isSet: false, typ: fs.Type, repeated: true, err: ErrIndexOutOfRange}
			}
			n := sliceLen(cur.vals[fi])
			if step.index < 0 || step.index >= n {
				return Value{exists: false, isSet: false, typ: fs.Type, repeated: true, err: ErrIndexOutOfRange}
			}
			elem := sliceGet(cur.vals[fi], step.index)
			if last {
				if fs.Type == FieldMessage {
					msg, _ := elem.(*Message)
					if msg == nil {
						return Value{exists: true, isSet: false, typ: FieldMessage}
					}
					return Value{exists: true, isSet: true, typ: FieldMessage, value: msg}
				}
				return Value{exists: true, isSet: true, typ: fs.Type, value: elem}
			}
			if fs.Type != FieldMessage {
				return Value{err: ErrFieldNotFound}
			}
			msg, _ := elem.(*Message)
			if msg == nil {
				return Value{err: ErrFieldNotFound}
			}
			cur = msg
		} else {
			if last {
				return cur.fieldValue(fi, fs)
			}
			if fs.Type != FieldMessage || fs.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			if !cur.set[fi] || cur.vals[fi] == nil {
				return Value{err: ErrFieldNotFound}
			}
			cur = cur.vals[fi].(*Message)
		}
	}
	return Value{err: ErrFieldNotFound}
}

func (m *Message) fieldValue(fi int, fs *FieldSchema) Value {
	if !m.set[fi] {
		return Value{exists: true, isSet: false, typ: fs.Type, repeated: fs.Repeated}
	}
	return Value{exists: true, isSet: true, typ: fs.Type, repeated: fs.Repeated, value: m.vals[fi]}
}

// --- Set / Append / Clear / Has / SetFields ---

func (m *Message) Set(path string, value any) error {
	if value == nil {
		return m.Clear(path)
	}
	steps, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(steps) == 0 {
		msg, ok := value.(*Message)
		if !ok {
			return ErrTypeMismatch
		}
		if msg == nil {
			return ErrTypeMismatch
		}
		if !schemaEquals(m.schema, msg.schema) {
			return ErrTypeMismatch
		}
		cp, err := deepCopyMessage(msg)
		if err != nil {
			return err
		}
		*m = *cp
		return nil
	}
	cur := m
	for i, step := range steps {
		last := i == len(steps)-1
		fi, ok := cur.schema.fieldIndexByName(step.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &cur.schema.Fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] {
				return ErrIndexOutOfRange
			}
			n := sliceLen(cur.vals[fi])
			if step.index < 0 || step.index >= n {
				return ErrIndexOutOfRange
			}
			if last {
				elem, err := convertElement(fs, value)
				if err != nil {
					return err
				}
				setSliceElement(cur.vals[fi], step.index, elem)
				return nil
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			msg := sliceMessageAt(cur.vals[fi], step.index)
			if msg == nil {
				sub := newMessage(&fs.Schema)
				setSliceElement(cur.vals[fi], step.index, sub)
				cur = sub
			} else {
				cur = msg
			}
		} else {
			if last {
				return cur.setField(fi, fs, value)
			}
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] || cur.vals[fi] == nil {
				sub := newMessage(&fs.Schema)
				cur.set[fi] = true
				cur.vals[fi] = sub
			}
			cur = cur.vals[fi].(*Message)
		}
	}
	return ErrFieldNotFound
}

func (m *Message) setField(fi int, fs *FieldSchema, value any) error {
	if fs.Repeated {
		rv := reflect.ValueOf(value)
		if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
			return ErrTypeMismatch
		}
		typed, err := convertRepeatedSlice(rv, fs)
		if err != nil {
			return err
		}
		m.set[fi] = true
		m.vals[fi] = typed
		return nil
	}
	if fs.Type == FieldMessage {
		msg, ok := value.(*Message)
		if !ok {
			return ErrTypeMismatch
		}
		if msg == nil {
			return ErrTypeMismatch
		}
		if !schemaEquals(&fs.Schema, msg.schema) {
			return ErrTypeMismatch
		}
		cp, err := deepCopyMessage(msg)
		if err != nil {
			return err
		}
		m.set[fi] = true
		m.vals[fi] = cp
		return nil
	}
	converted, err := convertScalar(value, fs.Type)
	if err != nil {
		return err
	}
	m.set[fi] = true
	m.vals[fi] = converted
	return nil
}

func (m *Message) Append(path string, value any) error {
	steps, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(steps) == 0 {
		return ErrTypeMismatch
	}
	cur := m
	for i, step := range steps {
		last := i == len(steps)-1
		fi, ok := cur.schema.fieldIndexByName(step.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &cur.schema.Fields[fi]
		if step.hasIndex {
			if last {
				return ErrFieldNotFound
			}
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] {
				return ErrIndexOutOfRange
			}
			n := sliceLen(cur.vals[fi])
			if step.index < 0 || step.index >= n {
				return ErrIndexOutOfRange
			}
			msg := sliceMessageAt(cur.vals[fi], step.index)
			if msg == nil {
				sub := newMessage(&fs.Schema)
				setSliceElement(cur.vals[fi], step.index, sub)
				cur = sub
			} else {
				cur = msg
			}
		} else {
			if last {
				if !fs.Repeated {
					return ErrTypeMismatch
				}
				elem, err := convertElement(fs, value)
				if err != nil {
					return err
				}
				appendElement(cur, fi, fs, elem)
				return nil
			}
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] || cur.vals[fi] == nil {
				sub := newMessage(&fs.Schema)
				cur.set[fi] = true
				cur.vals[fi] = sub
			}
			cur = cur.vals[fi].(*Message)
		}
	}
	return ErrFieldNotFound
}

func (m *Message) Clear(path string) error {
	steps, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(steps) == 0 {
		m.clearAll()
		return nil
	}
	cur := m
	for i, step := range steps {
		last := i == len(steps)-1
		fi, ok := cur.schema.fieldIndexByName(step.name)
		if !ok {
			return ErrFieldNotFound
		}
		fs := &cur.schema.Fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] {
				return nil
			}
			n := sliceLen(cur.vals[fi])
			if step.index < 0 || step.index >= n {
				return ErrIndexOutOfRange
			}
			if last {
				if fs.Type == FieldMessage {
					setSliceElement(cur.vals[fi], step.index, nil)
				} else {
					setSliceElement(cur.vals[fi], step.index, zeroValue(fs.Type))
				}
				return nil
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			msg := sliceMessageAt(cur.vals[fi], step.index)
			if msg == nil {
				return nil
			}
			cur = msg
		} else {
			if last {
				cur.set[fi] = false
				cur.vals[fi] = nil
				return nil
			}
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.set[fi] || cur.vals[fi] == nil {
				return nil
			}
			cur = cur.vals[fi].(*Message)
		}
	}
	return ErrFieldNotFound
}

func (m *Message) Has(path string) bool {
	v := m.Get(path)
	return v.Exists() && v.IsSet()
}

func (m *Message) SetFields() []string {
	out := make([]string, 0, len(m.set))
	for i, ok := range m.set {
		if ok {
			out = append(out, m.schema.Fields[i].Name)
		}
	}
	return out
}

// --- slice helpers ---

func sliceLen(slice any) int {
	if slice == nil {
		return 0
	}
	rv := reflect.ValueOf(slice)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return 0
	}
	return rv.Len()
}

func sliceGet(slice any, i int) any {
	if slice == nil {
		return nil
	}
	rv := reflect.ValueOf(slice)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return nil
	}
	if i < 0 || i >= rv.Len() {
		return nil
	}
	return rv.Index(i).Interface()
}

func sliceMessageAt(slice any, i int) *Message {
	if slice == nil {
		return nil
	}
	rv := reflect.ValueOf(slice)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return nil
	}
	if i < 0 || i >= rv.Len() {
		return nil
	}
	msg, _ := rv.Index(i).Interface().(*Message)
	return msg
}

func setSliceElement(slice any, i int, val any) {
	rv := reflect.ValueOf(slice)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return
	}
	if i < 0 || i >= rv.Len() {
		return
	}
	if val == nil {
		rv.Index(i).Set(reflect.Zero(rv.Type().Elem()))
		return
	}
	rv.Index(i).Set(reflect.ValueOf(val))
}

func appendElement(cur *Message, fi int, fs *FieldSchema, elem any) {
	if !cur.set[fi] {
		cur.vals[fi] = emptySlice(fs.Type)
		cur.set[fi] = true
	}
	cur.vals[fi] = appendToSlice(cur.vals[fi], elem)
}

func emptySlice(typ FieldType) any {
	switch typ {
	case FieldInt32:
		return []int32{}
	case FieldInt64:
		return []int64{}
	case FieldUint32:
		return []uint32{}
	case FieldUint64:
		return []uint64{}
	case FieldFloat:
		return []float32{}
	case FieldDouble:
		return []float64{}
	case FieldBool:
		return []bool{}
	case FieldString:
		return []string{}
	case FieldBytes:
		return [][]byte{}
	case FieldMessage:
		return []*Message{}
	}
	return nil
}

func appendToSlice(slice any, val any) any {
	switch s := slice.(type) {
	case []int32:
		return append(s, val.(int32))
	case []int64:
		return append(s, val.(int64))
	case []uint32:
		return append(s, val.(uint32))
	case []uint64:
		return append(s, val.(uint64))
	case []float32:
		return append(s, val.(float32))
	case []float64:
		return append(s, val.(float64))
	case []bool:
		return append(s, val.(bool))
	case []string:
		return append(s, val.(string))
	case [][]byte:
		return append(s, val.([]byte))
	case []*Message:
		if val == nil {
			return append(s, nil)
		}
		return append(s, val.(*Message))
	}
	return slice
}

func zeroValue(t FieldType) any {
	switch t {
	case FieldInt32:
		return int32(0)
	case FieldInt64:
		return int64(0)
	case FieldUint32:
		return uint32(0)
	case FieldUint64:
		return uint64(0)
	case FieldFloat:
		return float32(0)
	case FieldDouble:
		return float64(0)
	case FieldBool:
		return false
	case FieldString:
		return ""
	case FieldBytes:
		return []byte(nil)
	case FieldMessage:
		return (*Message)(nil)
	}
	return nil
}

// --- conversion ---

func convertScalar(v any, target FieldType) (any, error) {
	if v == nil {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch target {
	case FieldInt32:
		x, err := convertToInt64(rv, 32)
		if err != nil {
			return nil, err
		}
		return int32(x), nil
	case FieldInt64:
		x, err := convertToInt64(rv, 64)
		if err != nil {
			return nil, err
		}
		return x, nil
	case FieldUint32:
		x, err := convertToUint64(rv, 32)
		if err != nil {
			return nil, err
		}
		return uint32(x), nil
	case FieldUint64:
		x, err := convertToUint64(rv, 64)
		if err != nil {
			return nil, err
		}
		return x, nil
	case FieldFloat:
		x, err := convertToFloat64(rv, 32)
		if err != nil {
			return nil, err
		}
		f32 := float32(x)
		if math.IsInf(float64(f32), 0) && !math.IsInf(x, 0) {
			return nil, ErrTypeMismatch
		}
		return f32, nil
	case FieldDouble:
		x, err := convertToFloat64(rv, 64)
		if err != nil {
			return nil, err
		}
		return x, nil
	case FieldBool:
		return convertToBool(rv)
	case FieldString:
		return convertToString(rv)
	case FieldBytes:
		return convertToBytes(rv)
	}
	return nil, ErrTypeMismatch
}

func convertToInt64(rv reflect.Value, bits int) (int64, error) {
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		i := rv.Int()
		if bits == 32 && (i < math.MinInt32 || i > math.MaxInt32) {
			return 0, ErrTypeMismatch
		}
		return i, nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		u := rv.Uint()
		if u > math.MaxInt64 {
			return 0, ErrTypeMismatch
		}
		if bits == 32 && u > math.MaxInt32 {
			return 0, ErrTypeMismatch
		}
		return int64(u), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return 0, ErrTypeMismatch
		}
		if bits == 32 {
			if f < math.MinInt32 || f >= 2147483648.0 {
				return 0, ErrTypeMismatch
			}
			return int64(f), nil
		}
		if f < math.MinInt64 || f >= 9223372036854775808.0 {
			return 0, ErrTypeMismatch
		}
		return int64(f), nil
	case reflect.String:
		s := strings.TrimSpace(rv.String())
		i, err := strconv.ParseInt(s, 10, bits)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return i, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			s := strings.TrimSpace(string(rv.Bytes()))
			i, err := strconv.ParseInt(s, 10, bits)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return i, nil
		}
	}
	return 0, ErrTypeMismatch
}

func convertToUint64(rv reflect.Value, bits int) (uint64, error) {
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		i := rv.Int()
		if i < 0 {
			return 0, ErrTypeMismatch
		}
		if bits == 32 && i > math.MaxUint32 {
			return 0, ErrTypeMismatch
		}
		return uint64(i), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		u := rv.Uint()
		if bits == 32 && u > math.MaxUint32 {
			return 0, ErrTypeMismatch
		}
		return u, nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		if math.IsNaN(f) || math.IsInf(f, 0) {
			return 0, ErrTypeMismatch
		}
		if f < 0 {
			return 0, ErrTypeMismatch
		}
		if bits == 32 {
			if f >= 4294967296.0 {
				return 0, ErrTypeMismatch
			}
		} else {
			if f >= 18446744073709551616.0 {
				return 0, ErrTypeMismatch
			}
		}
		return uint64(f), nil
	case reflect.String:
		s := strings.TrimSpace(rv.String())
		u, err := strconv.ParseUint(s, 10, bits)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return u, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			s := strings.TrimSpace(string(rv.Bytes()))
			u, err := strconv.ParseUint(s, 10, bits)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return u, nil
		}
	}
	return 0, ErrTypeMismatch
}

func convertToFloat64(rv reflect.Value, bits int) (float64, error) {
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return float64(rv.Int()), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return float64(rv.Uint()), nil
	case reflect.Float32, reflect.Float64:
		return rv.Float(), nil
	case reflect.String:
		f, err := strconv.ParseFloat(strings.TrimSpace(rv.String()), bits)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return f, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			f, err := strconv.ParseFloat(strings.TrimSpace(string(rv.Bytes())), bits)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return f, nil
		}
	}
	return 0, ErrTypeMismatch
}

func convertToBool(rv reflect.Value) (bool, error) {
	if rv.Kind() == reflect.Bool {
		return rv.Bool(), nil
	}
	return false, ErrTypeMismatch
}

func convertToString(rv reflect.Value) (string, error) {
	switch rv.Kind() {
	case reflect.String:
		return rv.String(), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return string(rv.Bytes()), nil
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(rv.Int(), 10), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return strconv.FormatUint(rv.Uint(), 10), nil
	case reflect.Float32, reflect.Float64:
		return strconv.FormatFloat(rv.Float(), 'g', -1, 64), nil
	}
	return "", ErrTypeMismatch
}

func convertToBytes(rv reflect.Value) ([]byte, error) {
	switch rv.Kind() {
	case reflect.String:
		return []byte(rv.String()), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return append([]byte(nil), rv.Bytes()...), nil
		}
	}
	return nil, ErrTypeMismatch
}

func convertElement(fs *FieldSchema, value any) (any, error) {
	if fs.Type == FieldMessage {
		msg, ok := value.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if msg == nil {
			return (*Message)(nil), nil
		}
		if !schemaEquals(&fs.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		cp, err := deepCopyMessage(msg)
		if err != nil {
			return nil, err
		}
		return cp, nil
	}
	return convertScalar(value, fs.Type)
}

func convertRepeatedSlice(rv reflect.Value, fs *FieldSchema) (any, error) {
	n := rv.Len()
	switch fs.Type {
	case FieldInt32:
		out := make([]int32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldInt32)
			if err != nil {
				return nil, err
			}
			out[i] = v.(int32)
		}
		return out, nil
	case FieldInt64:
		out := make([]int64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldInt64)
			if err != nil {
				return nil, err
			}
			out[i] = v.(int64)
		}
		return out, nil
	case FieldUint32:
		out := make([]uint32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldUint32)
			if err != nil {
				return nil, err
			}
			out[i] = v.(uint32)
		}
		return out, nil
	case FieldUint64:
		out := make([]uint64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldUint64)
			if err != nil {
				return nil, err
			}
			out[i] = v.(uint64)
		}
		return out, nil
	case FieldFloat:
		out := make([]float32, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldFloat)
			if err != nil {
				return nil, err
			}
			out[i] = v.(float32)
		}
		return out, nil
	case FieldDouble:
		out := make([]float64, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldDouble)
			if err != nil {
				return nil, err
			}
			out[i] = v.(float64)
		}
		return out, nil
	case FieldBool:
		out := make([]bool, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldBool)
			if err != nil {
				return nil, err
			}
			out[i] = v.(bool)
		}
		return out, nil
	case FieldString:
		out := make([]string, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldString)
			if err != nil {
				return nil, err
			}
			out[i] = v.(string)
		}
		return out, nil
	case FieldBytes:
		out := make([][]byte, n)
		for i := 0; i < n; i++ {
			v, err := convertScalar(rv.Index(i).Interface(), FieldBytes)
			if err != nil {
				return nil, err
			}
			out[i] = v.([]byte)
		}
		return out, nil
	case FieldMessage:
		out := make([]*Message, n)
		for i := 0; i < n; i++ {
			iv := rv.Index(i).Interface()
			if iv == nil {
				continue
			}
			msg, ok := iv.(*Message)
			if !ok {
				return nil, ErrTypeMismatch
			}
			if msg == nil {
				continue
			}
			if !schemaEquals(&fs.Schema, msg.schema) {
				return nil, ErrTypeMismatch
			}
			cp, err := deepCopyMessage(msg)
			if err != nil {
				return nil, err
			}
			out[i] = cp
		}
		return out, nil
	}
	return nil, ErrTypeMismatch
}

// --- deep copy ---

func deepCopyMessage(src *Message) (*Message, error) {
	if src == nil {
		return nil, nil
	}
	dst := newMessage(src.schema)
	for i := range src.set {
		if !src.set[i] {
			continue
		}
		fs := &src.schema.Fields[i]
		if fs.Repeated {
			switch fs.Type {
			case FieldInt32:
				s := src.vals[i].([]int32)
				dst.vals[i] = append([]int32(nil), s...)
			case FieldInt64:
				s := src.vals[i].([]int64)
				dst.vals[i] = append([]int64(nil), s...)
			case FieldUint32:
				s := src.vals[i].([]uint32)
				dst.vals[i] = append([]uint32(nil), s...)
			case FieldUint64:
				s := src.vals[i].([]uint64)
				dst.vals[i] = append([]uint64(nil), s...)
			case FieldFloat:
				s := src.vals[i].([]float32)
				dst.vals[i] = append([]float32(nil), s...)
			case FieldDouble:
				s := src.vals[i].([]float64)
				dst.vals[i] = append([]float64(nil), s...)
			case FieldBool:
				s := src.vals[i].([]bool)
				dst.vals[i] = append([]bool(nil), s...)
			case FieldString:
				s := src.vals[i].([]string)
				dst.vals[i] = append([]string(nil), s...)
			case FieldBytes:
				s := src.vals[i].([][]byte)
				out := make([][]byte, len(s))
				for j, b := range s {
					if b != nil {
						out[j] = append([]byte(nil), b...)
					}
				}
				dst.vals[i] = out
			case FieldMessage:
				s := src.vals[i].([]*Message)
				out := make([]*Message, len(s))
				for j, msg := range s {
					if msg == nil {
						continue
					}
					cp, err := deepCopyMessage(msg)
					if err != nil {
						return nil, err
					}
					out[j] = cp
				}
				dst.vals[i] = out
			}
		} else if fs.Type == FieldMessage {
			if src.vals[i] == nil {
				dst.vals[i] = nil
			} else {
				cp, err := deepCopyMessage(src.vals[i].(*Message))
				if err != nil {
					return nil, err
				}
				dst.vals[i] = cp
			}
		} else if fs.Type == FieldBytes {
			b := src.vals[i].([]byte)
			dst.vals[i] = append([]byte(nil), b...)
		} else {
			dst.vals[i] = src.vals[i]
		}
		dst.set[i] = true
	}
	return dst, nil
}

// --- schema parsing / registration ---

type jsonConfig struct {
	Types []jsonType `json:"types"`
}

type jsonType struct {
	TypeID uint16          `json:"typeId"`
	Fields []jsonFieldDef  `json:"fields"`
}

type jsonFieldDef struct {
	Name     string        `json:"name"`
	Num      int           `json:"num"`
	Type     string        `json:"type"`
	Repeated bool          `json:"repeated"`
	Schema   *jsonMessage  `json:"schema"`
}

type jsonMessage struct {
	Fields []jsonFieldDef `json:"fields"`
}

func ParseSchema(data []byte) ([]MessageSchema, error) {
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var cfg jsonConfig
	if err := dec.Decode(&cfg); err != nil {
		return nil, ErrMalformedData
	}
	if _, err := dec.Token(); err != io.EOF {
		return nil, ErrMalformedData
	}
	if cfg.Types == nil {
		return nil, ErrMalformedData
	}
	seen := make(map[uint16]bool)
	result := make([]MessageSchema, 0, len(cfg.Types))
	for _, t := range cfg.Types {
		if t.TypeID == 0 || t.TypeID > 65535 {
			return nil, ErrMalformedData
		}
		if seen[t.TypeID] {
			return nil, ErrMalformedData
		}
		seen[t.TypeID] = true
		var schema MessageSchema
		schema.TypeID = t.TypeID
		if err := parseFields(t.Fields, &schema); err != nil {
			return nil, err
		}
		schema.init()
		result = append(result, schema)
	}
	return result, nil
}

func parseFields(defs []jsonFieldDef, schema *MessageSchema) error {
	nameSeen := make(map[string]bool)
	numSeen := make(map[int]bool)
	for _, jf := range defs {
		if jf.Name == "" {
			return ErrMalformedData
		}
		if strings.ContainsAny(jf.Name, ".[]") {
			return ErrMalformedData
		}
		if jf.Num < 1 || jf.Num > 65535 {
			return ErrMalformedData
		}
		ft := FieldType(jf.Type)
		switch ft {
		case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldFloat, FieldDouble, FieldBool, FieldString, FieldBytes:
			if jf.Schema != nil {
				return ErrMalformedData
			}
		case FieldMessage:
			if jf.Schema == nil {
				return ErrMalformedData
			}
		default:
			return ErrMalformedData
		}
		if nameSeen[jf.Name] {
			return ErrMalformedData
		}
		nameSeen[jf.Name] = true
		if numSeen[jf.Num] {
			return ErrMalformedData
		}
		numSeen[jf.Num] = true
		fs := FieldSchema{
			Name:     jf.Name,
			Num:      jf.Num,
			Type:     ft,
			Repeated: jf.Repeated,
		}
		if ft == FieldMessage {
			var nested MessageSchema
			if err := parseFields(jf.Schema.Fields, &nested); err != nil {
				return err
			}
			nested.init()
			fs.Schema = nested
		}
		schema.Fields = append(schema.Fields, fs)
	}
	return nil
}

var (
	registryMu sync.RWMutex
	registry   = make(map[uint16]*MessageSchema)
)

func Register(s MessageSchema) error {
	if s.TypeID == 0 || s.TypeID > 65535 {
		return ErrMalformedData
	}
	registryMu.Lock()
	defer registryMu.Unlock()
	if existing, ok := registry[s.TypeID]; ok {
		if schemaEquals(existing, &s) {
			return nil
		}
		return ErrDuplicateID
	}
	cp := cloneSchema(&s)
	registry[s.TypeID] = cp
	return nil
}

func New(typeID uint16) (*Message, error) {
	registryMu.RLock()
	s, ok := registry[typeID]
	registryMu.RUnlock()
	if !ok {
		return nil, ErrUnknownTypeID
	}
	return newMessage(s), nil
}
