package dymsg

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io"
	"strconv"
)

// This file implements JSON encoding and decoding.

// EncodeJSON encodes the message to compact JSON.
//
// Field order follows schema declaration order. Unset fields are omitted.
// Nested messages become objects, repeated fields become arrays, bytes become
// base64 strings, and nil elements in a repeated message array become null.
// NaN and Inf float values cause an error.
func (m *Message) EncodeJSON() ([]byte, error) {
	var buf bytes.Buffer
	buf.WriteByte('{')
	first := true
	for i, fs := range m.schema.fields {
		fv := m.fields[i]
		if !fv.set {
			continue
		}
		if fs.Type == FieldMessage && !fs.Repeated && fv.value == nil {
			continue
		}
		if !first {
			buf.WriteByte(',')
		}
		first = false
		key, _ := json.Marshal(fs.Name)
		buf.Write(key)
		buf.WriteByte(':')
		if err := writeJSONValue(&buf, fs, fv); err != nil {
			return nil, err
		}
	}
	buf.WriteByte('}')
	return buf.Bytes(), nil
}

func writeJSONValue(buf *bytes.Buffer, fs *FieldSchema, fv fieldValue) error {
	if fs.Repeated {
		return writeJSONArray(buf, fs, fv.value)
	}
	return writeJSONScalar(buf, fs.Type, fv.value)
}

func writeJSONScalar(buf *bytes.Buffer, ft FieldType, val any) error {
	if ft == FieldMessage {
		msg, _ := val.(*Message)
		if msg == nil {
			buf.WriteString("null")
			return nil
		}
		b, err := msg.EncodeJSON()
		if err != nil {
			return err
		}
		buf.Write(b)
		return nil
	}
	b, err := json.Marshal(val)
	if err != nil {
		return ErrMalformedData
	}
	buf.Write(b)
	return nil
}

func writeJSONArray(buf *bytes.Buffer, fs *FieldSchema, val any) error {
	buf.WriteByte('[')
	n := sliceLen(val)
	for i := 0; i < n; i++ {
		if i > 0 {
			buf.WriteByte(',')
		}
		elem := sliceIndex(val, i)
		if fs.Type == FieldMessage {
			msg, _ := elem.(*Message)
			if msg == nil {
				buf.WriteString("null")
				continue
			}
			b, err := msg.EncodeJSON()
			if err != nil {
				return err
			}
			buf.Write(b)
			continue
		}
		b, err := json.Marshal(elem)
		if err != nil {
			return ErrMalformedData
		}
		buf.Write(b)
	}
	buf.WriteByte(']')
	return nil
}

// DecodeJSON decodes JSON data into the message, replacing all current fields.
//
// The top-level input must be a JSON object (or null). Unknown keys are
// ignored. A field value of null clears that field. Null elements inside a
// repeated message array are preserved as nil elements; null elements inside a
// scalar repeated array are rejected.
func (m *Message) DecodeJSON(data []byte) error {
	if len(data) == 0 {
		return ErrTruncated
	}
	dec := json.NewDecoder(bytes.NewReader(data))
	dec.UseNumber()
	var root any
	if err := dec.Decode(&root); err != nil {
		return ErrMalformedData
	}
	// Reject trailing data.
	if err := dec.Decode(&struct{}{}); err != io.EOF {
		return ErrMalformedData
	}
	if root == nil {
		m.clearAll()
		return nil
	}
	obj, ok := root.(map[string]any)
	if !ok {
		return ErrMalformedData
	}
	m.clearAll()
	for key, val := range obj {
		fi, ok := m.schema.byName[key]
		if !ok {
			continue
		}
		fs := m.schema.fields[fi]
		if err := m.decodeJSONField(fi, fs, val); err != nil {
			return err
		}
	}
	return nil
}

func (m *Message) decodeJSONObject(obj map[string]any) error {
	m.clearAll()
	for key, val := range obj {
		fi, ok := m.schema.byName[key]
		if !ok {
			continue
		}
		fs := m.schema.fields[fi]
		if err := m.decodeJSONField(fi, fs, val); err != nil {
			return err
		}
	}
	return nil
}

func (m *Message) decodeJSONField(fi int, fs *FieldSchema, val any) error {
	if val == nil {
		// A field-level null clears the field regardless of type.
		m.fields[fi].set = false
		m.fields[fi].value = nil
		return nil
	}
	if fs.Repeated {
		arr, ok := val.([]any)
		if !ok {
			return ErrMalformedData
		}
		m.fields[fi].set = false
		m.fields[fi].value = nil
		for _, elem := range arr {
			if elem == nil {
				if fs.Type == FieldMessage {
					appendSlice(&m.fields[fi], (*Message)(nil))
				} else {
					return ErrMalformedData
				}
				continue
			}
			if fs.Type == FieldMessage {
				obj, ok := elem.(map[string]any)
				if !ok {
					return ErrMalformedData
				}
				sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
				if err := sub.decodeJSONObject(obj); err != nil {
					return err
				}
				appendSlice(&m.fields[fi], sub)
			} else {
				scalar, err := decodeJSONScalar(fs.Type, elem)
				if err != nil {
					return err
				}
				appendSlice(&m.fields[fi], scalar)
			}
		}
		if len(arr) == 0 {
			// An empty array still makes the field set.
			m.fields[fi].set = true
			m.fields[fi].value = makeEmptySlice(fs.Type)
		}
		return nil
	}

	// Non-repeated.
	if val == nil {
		m.fields[fi].set = false
		m.fields[fi].value = nil
		return nil
	}
	if fs.Type == FieldMessage {
		obj, ok := val.(map[string]any)
		if !ok {
			return ErrMalformedData
		}
		sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
		if err := sub.decodeJSONObject(obj); err != nil {
			return err
		}
		m.fields[fi].set = true
		m.fields[fi].value = sub
		return nil
	}
	scalar, err := decodeJSONScalar(fs.Type, val)
	if err != nil {
		return err
	}
	m.fields[fi].set = true
	m.fields[fi].value = scalar
	return nil
}

func decodeJSONScalar(ft FieldType, v any) (any, error) {
	switch ft {
	case FieldInt32:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		i, err := strconv.ParseInt(string(n), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return int32(i), nil
	case FieldInt64:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		i, err := strconv.ParseInt(string(n), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return i, nil
	case FieldUint32:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		u, err := strconv.ParseUint(string(n), 10, 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return uint32(u), nil
	case FieldUint64:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		u, err := strconv.ParseUint(string(n), 10, 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return u, nil
	case FieldFloat:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(string(n), 32)
		if err != nil {
			return nil, ErrMalformedData
		}
		return float32(f), nil
	case FieldDouble:
		n, ok := v.(json.Number)
		if !ok {
			return nil, ErrMalformedData
		}
		f, err := strconv.ParseFloat(string(n), 64)
		if err != nil {
			return nil, ErrMalformedData
		}
		return f, nil
	case FieldBool:
		b, ok := v.(bool)
		if !ok {
			return nil, ErrMalformedData
		}
		return b, nil
	case FieldString:
		s, ok := v.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		return s, nil
	case FieldBytes:
		s, ok := v.(string)
		if !ok {
			return nil, ErrMalformedData
		}
		b, err := base64.StdEncoding.DecodeString(s)
		if err != nil {
			return nil, ErrMalformedData
		}
		return b, nil
	}
	return nil, ErrMalformedData
}
