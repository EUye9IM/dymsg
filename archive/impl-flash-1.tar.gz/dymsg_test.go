package dymsg

import (
	"bytes"
	"math"
	"reflect"
	"strings"
	"testing"
)

const testConfig = `{
  "types": [
    {
      "typeId": 1001,
      "fields": [
        { "name": "name", "type": "string", "num": 1 },
        { "name": "age", "type": "int32", "num": 2 },
        { "name": "big", "type": "int64", "num": 3 },
        { "name": "cnt", "type": "uint32", "num": 4 },
        { "name": "huge", "type": "uint64", "num": 5 },
        { "name": "ratio", "type": "float", "num": 6 },
        { "name": "score", "type": "double", "num": 7 },
        { "name": "active", "type": "bool", "num": 8 },
        { "name": "data", "type": "bytes", "num": 9 },
        { "name": "addr", "type": "message", "num": 10, "schema": {
            "fields": [
              { "name": "city", "type": "string", "num": 1 },
              { "name": "zip", "type": "string", "num": 2 }
            ]
        }},
        { "name": "tags", "type": "string", "num": 11, "repeated": true },
        { "name": "scores", "type": "int32", "num": 12, "repeated": true },
        { "name": "contacts", "type": "message", "num": 13, "repeated": true, "schema": {
            "fields": [
              { "name": "phone", "type": "string", "num": 1 }
            ]
        }}
      ]
    }
  ]
}`

func resetRegistry() {
	registryMu.Lock()
	registry = make(map[uint16]*MessageSchema)
	registryMu.Unlock()
}

func registerTestSchema(t *testing.T) {
	t.Helper()
	schemas, err := ParseSchema([]byte(testConfig))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	for _, s := range schemas {
		if err := Register(s); err != nil {
			t.Fatalf("Register: %v", err)
		}
	}
}

func mustNew(t *testing.T) *Message {
	t.Helper()
	m, err := New(1001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	return m
}

// newMsgForField creates a Message matching the nested schema of a message
// field. It is used by tests to build messages that are structurally
// compatible with a nested field.
func newMsgForField(m *Message, fieldName string) *Message {
	fi, ok := m.schema.byName[fieldName]
	if !ok {
		panic("field not found: " + fieldName)
	}
	fs := m.schema.fields[fi]
	return &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
}

// ---------------------------------------------------------------------------
// ParseSchema and Register
// ---------------------------------------------------------------------------

func TestParseSchemaAndRegister(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m, err := New(1001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if m == nil {
		t.Fatal("nil message")
	}
}

func TestParseSchemaBadTypeID(t *testing.T) {
	resetRegistry()
	cases := []string{
		`{"types":[{"typeId":0,"fields":[{"name":"a","type":"string","num":1}]}]}`,
		`{"types":[{"typeId":65536,"fields":[{"name":"a","type":"string","num":1}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1}]},{"typeId":1,"fields":[{"name":"b","type":"string","num":1}]}]}`,
	}
	for _, c := range cases {
		if _, err := ParseSchema([]byte(c)); err != ErrMalformedData {
			t.Errorf("ParseSchema(%s) = %v, want ErrMalformedData", c, err)
		}
	}
}

func TestParseSchemaBadField(t *testing.T) {
	resetRegistry()
	cases := []string{
		`{"types":[{"typeId":1,"fields":[{"name":"a.b","type":"string","num":1}]}]}`,  // name with dot
		`{"types":[{"typeId":1,"fields":[{"name":"a[0]","type":"string","num":1}]}]}`, // name with bracket
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"nope","num":1}]}]}`,      // bad type
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":0}]}]}`,    // num out of range
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":65536}]}]}`,
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1},{"name":"a","type":"string","num":2}]}]}`, // dup name
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1},{"name":"b","type":"string","num":1}]}]}`, // dup num
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"string","num":1,"schema":{"fields":[]}}]}]}`,               // non-message with schema
		`{"types":[{"typeId":1,"fields":[{"name":"a","type":"message","num":1}]}]}`,                                     // message without schema
	}
	for _, c := range cases {
		if _, err := ParseSchema([]byte(c)); err != ErrMalformedData {
			t.Errorf("ParseSchema(%s) = %v, want ErrMalformedData", c, err)
		}
	}
}

func TestRegisterDuplicate(t *testing.T) {
	resetRegistry()
	s1, _ := ParseSchema([]byte(`{"types":[{"typeId":7,"fields":[{"name":"a","type":"string","num":1}]}]}`))
	s2, _ := ParseSchema([]byte(`{"types":[{"typeId":7,"fields":[{"name":"a","type":"string","num":1}]}]}`))
	s3, _ := ParseSchema([]byte(`{"types":[{"typeId":7,"fields":[{"name":"a","type":"string","num":1},{"name":"b","type":"int32","num":2}]}]}`))
	if err := Register(s1[0]); err != nil {
		t.Fatalf("Register s1: %v", err)
	}
	if err := Register(s2[0]); err != nil {
		t.Errorf("Register s2 (idempotent) = %v, want nil", err)
	}
	if err := Register(s3[0]); err != ErrDuplicateID {
		t.Errorf("Register s3 = %v, want ErrDuplicateID", err)
	}
}

func TestNewUnknownType(t *testing.T) {
	resetRegistry()
	if _, err := New(999); err != ErrUnknownTypeID {
		t.Errorf("New(999) = %v, want ErrUnknownTypeID", err)
	}
}

// ---------------------------------------------------------------------------
// Get and Value
// ---------------------------------------------------------------------------

func TestGetValueBasic(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	v := m.Get("name")
	if !v.Exists() || v.IsSet() || v.Err() != nil {
		t.Errorf("unset field: Exists=%v IsSet=%v Err=%v", v.Exists(), v.IsSet(), v.Err())
	}
	if v.String() != "" {
		t.Errorf("unset field String()=%q, want empty", v.String())
	}

	m.Set("name", "alice")
	v = m.Get("name")
	if !v.Exists() || !v.IsSet() || v.Err() != nil {
		t.Errorf("set field: Exists=%v IsSet=%v Err=%v", v.Exists(), v.IsSet(), v.Err())
	}
	if v.String() != "alice" {
		t.Errorf("String()=%q, want alice", v.String())
	}
	if v.Any() != "alice" {
		t.Errorf("Any()=%v, want alice", v.Any())
	}

	v = m.Get("unknown")
	if v.Exists() || v.Err() != ErrFieldNotFound {
		t.Errorf("unknown field: Exists=%v Err=%v", v.Exists(), v.Err())
	}
}

func TestGetValuePresence(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("age", 0) // set to zero value
	v := m.Get("age")
	if !v.Exists() || !v.IsSet() {
		t.Errorf("zero value should be set: Exists=%v IsSet=%v", v.Exists(), v.IsSet())
	}
	if v.Int32() != 0 {
		t.Errorf("Int32()=%d, want 0", v.Int32())
	}

	// type mismatch getter returns zero
	if v.String() != "" {
		t.Errorf("String() on int32 = %q, want empty", v.String())
	}
}

func TestGetPathErrors(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Append("tags", "a")

	cases := []struct {
		path string
		err  error
	}{
		{"unknown", ErrFieldNotFound},
		{"name[0]", ErrFieldNotFound},    // non-repeated with index
		{"tags[-1]", ErrIndexOutOfRange}, // negative index
		{"tags[abc]", ErrIndexOutOfRange},
		{"tags[]", ErrIndexOutOfRange},
		{"name.x", ErrFieldNotFound},
		{"addr.city.x", ErrFieldNotFound}, // city is string
	}
	for _, c := range cases {
		v := m.Get(c.path)
		if v.Err() != c.err {
			t.Errorf("Get(%q).Err() = %v, want %v", c.path, v.Err(), c.err)
		}
		if v.Exists() {
			t.Errorf("Get(%q).Exists() = true, want false", c.path)
		}
	}
}

func TestGetIndexOutOfRange(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Append("tags", "a")

	v := m.Get("tags[0]")
	if !v.Exists() || !v.IsSet() || v.String() != "a" {
		t.Errorf("tags[0] = Exists=%v IsSet=%v String=%q", v.Exists(), v.IsSet(), v.String())
	}
	v = m.Get("tags[1]")
	if v.Exists() || v.Err() != ErrIndexOutOfRange {
		t.Errorf("tags[1] = Exists=%v Err=%v", v.Exists(), v.Err())
	}
	v = m.Get("tags[5]")
	if v.Err() != ErrIndexOutOfRange {
		t.Errorf("tags[5] Err=%v", v.Err())
	}
}

func TestGetNested(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// unset nested message: path exists but field unset
	v := m.Get("addr.city")
	if !v.Exists() || v.IsSet() {
		t.Errorf("addr.city unset: Exists=%v IsSet=%v", v.Exists(), v.IsSet())
	}
	if v.Message() != nil {
		t.Errorf("addr.Message() should be nil when unset")
	}

	m.Set("addr.city", "beijing")
	v = m.Get("addr.city")
	if !v.Exists() || !v.IsSet() || v.String() != "beijing" {
		t.Errorf("addr.city = Exists=%v IsSet=%v String=%q", v.Exists(), v.IsSet(), v.String())
	}
	v = m.Get("addr")
	if !v.Exists() || !v.IsSet() || v.Message() == nil {
		t.Errorf("addr = Exists=%v IsSet=%v Message=%v", v.Exists(), v.IsSet(), v.Message())
	}
	if m.Get("addr.zip").IsSet() {
		t.Errorf("addr.zip should be unset")
	}
}

func TestGetSelf(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	v := m.Get("")
	if !v.Exists() || !v.IsSet() || v.Err() != nil {
		t.Errorf("Get(\"\") = Exists=%v IsSet=%v Err=%v", v.Exists(), v.IsSet(), v.Err())
	}
	if v.Message() != m {
		t.Errorf("Get(\"\").Message() should be the message itself")
	}
	if v.Any() != m {
		t.Errorf("Get(\"\").Any() should be the message itself")
	}
}

func TestGetRepeatedAccessors(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Append("tags", "a")
	m.Append("tags", "b")

	v := m.Get("tags")
	if v.Len() != 2 {
		t.Errorf("Len()=%d, want 2", v.Len())
	}
	if v.Index(0).String() != "a" || v.Index(1).String() != "b" {
		t.Errorf("Index elements wrong: %q %q", v.Index(0).String(), v.Index(1).String())
	}
	if !reflect.DeepEqual(v.Strings(), []string{"a", "b"}) {
		t.Errorf("Strings()=%v", v.Strings())
	}
	if v.Index(2).Err() != ErrIndexOutOfRange {
		t.Errorf("Index(2).Err()=%v", v.Index(2).Err())
	}

	// unset repeated
	m2 := mustNew(t)
	v2 := m2.Get("tags")
	if v2.Len() != 0 || v2.Strings() != nil {
		t.Errorf("unset repeated Len=%d Strings=%v", v2.Len(), v2.Strings())
	}
}

func TestGetRepeatedMessage(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	c1 := newMsgForField(m, "contacts")
	c1.Set("phone", "123")
	m.Append("contacts", c1)
	m.Append("contacts", (*Message)(nil)) // nil element

	v := m.Get("contacts")
	if v.Len() != 2 {
		t.Fatalf("contacts Len=%d, want 2", v.Len())
	}
	if v.Index(0).Message() == nil || v.Index(0).Message().Get("phone").String() != "123" {
		t.Errorf("contacts[0] phone wrong")
	}
	if !v.Index(1).Exists() || v.Index(1).IsSet() {
		t.Errorf("contacts[1] should be an existing but unset nil element: Exists=%v IsSet=%v", v.Index(1).Exists(), v.Index(1).IsSet())
	}
	if len(v.Messages()) != 2 || v.Messages()[0] == nil || v.Messages()[1] != nil {
		t.Errorf("Messages()=%v", v.Messages())
	}
}

// ---------------------------------------------------------------------------
// Set
// ---------------------------------------------------------------------------

func TestSetScalarConversions(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// string -> int32
	if err := m.Set("age", "18"); err != nil {
		t.Fatalf("Set(age, string): %v", err)
	}
	if m.Get("age").Int32() != 18 {
		t.Errorf("age=%d, want 18", m.Get("age").Int32())
	}

	// int64 -> int32
	if err := m.Set("age", int64(5)); err != nil {
		t.Fatalf("Set(age, int64): %v", err)
	}
	if m.Get("age").Int32() != 5 {
		t.Errorf("age=%d, want 5", m.Get("age").Int32())
	}

	// float -> int (truncate toward zero)
	if err := m.Set("age", 1.9); err != nil {
		t.Fatalf("Set(age, 1.9): %v", err)
	}
	if m.Get("age").Int32() != 1 {
		t.Errorf("age=%d, want 1", m.Get("age").Int32())
	}
	if err := m.Set("age", -1.9); err != nil {
		t.Fatalf("Set(age, -1.9): %v", err)
	}
	if m.Get("age").Int32() != -1 {
		t.Errorf("age=%d, want -1", m.Get("age").Int32())
	}

	// overflow
	if err := m.Set("age", int64(2147483648)); err != ErrTypeMismatch {
		t.Errorf("Set(age, overflow) = %v, want ErrTypeMismatch", err)
	}
	if err := m.Set("age", uint64(1<<40)); err != ErrTypeMismatch {
		t.Errorf("Set(age, uint overflow) = %v, want ErrTypeMismatch", err)
	}
	if err := m.Set("age", math.Inf(1)); err != ErrTypeMismatch {
		t.Errorf("Set(age, +Inf) = %v, want ErrTypeMismatch", err)
	}

	// bytes -> string
	if err := m.Set("name", []byte("hello")); err != nil {
		t.Fatalf("Set(name, bytes): %v", err)
	}
	if m.Get("name").String() != "hello" {
		t.Errorf("name=%q, want hello", m.Get("name").String())
	}

	// string -> bytes
	if err := m.Set("data", "world"); err != nil {
		t.Fatalf("Set(data, string): %v", err)
	}
	if string(m.Get("data").Bytes()) != "world" {
		t.Errorf("data=%q, want world", m.Get("data").Bytes())
	}

	// bool
	if err := m.Set("active", true); err != nil {
		t.Fatalf("Set(active, true): %v", err)
	}
	if !m.Get("active").Bool() {
		t.Errorf("active should be true")
	}

	// type mismatch
	if err := m.Set("active", "true"); err != ErrTypeMismatch {
		t.Errorf("Set(active, string) = %v, want ErrTypeMismatch", err)
	}
}

func TestSetAutoCreateNested(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if err := m.Set("addr.city", "beijing"); err != nil {
		t.Fatalf("Set(addr.city): %v", err)
	}
	if m.Get("addr.city").String() != "beijing" {
		t.Errorf("addr.city=%q", m.Get("addr.city").String())
	}
	if !m.Get("addr").IsSet() {
		t.Errorf("addr should be set after auto-create")
	}
}

func TestSetIndexed(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// unset array -> index out of range
	if err := m.Set("tags[0]", "x"); err != ErrIndexOutOfRange {
		t.Errorf("Set(tags[0]) on unset = %v, want ErrIndexOutOfRange", err)
	}

	m.Append("tags", "a")
	m.Append("tags", "b")
	if err := m.Set("tags[1]", "B"); err != nil {
		t.Fatalf("Set(tags[1]): %v", err)
	}
	if m.Get("tags").Index(1).String() != "B" {
		t.Errorf("tags[1]=%q", m.Get("tags").Index(1).String())
	}
	if err := m.Set("tags[5]", "x"); err != ErrIndexOutOfRange {
		t.Errorf("Set(tags[5]) = %v, want ErrIndexOutOfRange", err)
	}

	// non-repeated with index
	if err := m.Set("name[0]", "x"); err != ErrFieldNotFound {
		t.Errorf("Set(name[0]) = %v, want ErrFieldNotFound", err)
	}
}

func TestSetNilClears(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("name", "alice")
	if err := m.Set("name", nil); err != nil {
		t.Fatalf("Set(name, nil): %v", err)
	}
	if m.Get("name").IsSet() {
		t.Errorf("name should be unset after Set(name, nil)")
	}

	m.Set("name", "alice")
	m.Set("age", 3)
	if err := m.Set("", nil); err != nil {
		t.Fatalf("Set(\"\", nil): %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Errorf("SetFields() after Set(\"\", nil) = %v", m.SetFields())
	}
}

func TestSetErrors(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if err := m.Set("unknown", 1); err != ErrFieldNotFound {
		t.Errorf("Set(unknown) = %v, want ErrFieldNotFound", err)
	}
	if err := m.Set("name.x", 1); err != ErrFieldNotFound {
		t.Errorf("Set(name.x) = %v, want ErrFieldNotFound", err)
	}
	if err := m.Set("addr.city.x", 1); err != ErrFieldNotFound {
		t.Errorf("Set(addr.city.x) = %v, want ErrFieldNotFound", err)
	}
}

func TestSetRepeatedSlice(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if err := m.Set("tags", []string{"a", "b"}); err != nil {
		t.Fatalf("Set(tags, slice): %v", err)
	}
	if !reflect.DeepEqual(m.Get("tags").Strings(), []string{"a", "b"}) {
		t.Errorf("tags=%v", m.Get("tags").Strings())
	}

	if err := m.Set("scores", []int{1, 2, 3}); err != nil {
		t.Fatalf("Set(scores, []int): %v", err)
	}
	if !reflect.DeepEqual(m.Get("scores").Int32s(), []int32{1, 2, 3}) {
		t.Errorf("scores=%v", m.Get("scores").Int32s())
	}

	// int slice converts to string slice (numeric -> string allowed).
	if err := m.Set("tags", []int{1}); err != nil {
		t.Errorf("Set(tags, []int) = %v, want nil", err)
	}
	if !reflect.DeepEqual(m.Get("tags").Strings(), []string{"1"}) {
		t.Errorf("tags=%v", m.Get("tags").Strings())
	}
	// bool slice is not convertible to string slice.
	if err := m.Set("tags", []bool{true}); err != ErrTypeMismatch {
		t.Errorf("Set(tags, []bool) = %v, want ErrTypeMismatch", err)
	}
	if err := m.Set("name", []string{"a"}); err != ErrTypeMismatch {
		t.Errorf("Set(name, []string) = %v, want ErrTypeMismatch", err)
	}
}

func TestSetWholeMessageDeepCopy(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	src := mustNew(t)
	src.Set("name", "alice")
	src.Set("addr.city", "beijing")
	src.Append("tags", "a")

	if err := m.Set("", src); err != nil {
		t.Fatalf("Set(\"\", src): %v", err)
	}
	if m.Get("name").String() != "alice" || m.Get("addr.city").String() != "beijing" {
		t.Errorf("copy failed")
	}

	// Modify src, m should be unaffected.
	src.Set("name", "bob")
	src.Get("addr").Message().Set("city", "shanghai")
	src.Append("tags", "b")

	if m.Get("name").String() != "alice" {
		t.Errorf("deep copy broken: name=%q", m.Get("name").String())
	}
	if m.Get("addr.city").String() != "beijing" {
		t.Errorf("deep copy broken: city=%q", m.Get("addr.city").String())
	}
	if m.Get("tags").Len() != 1 {
		t.Errorf("deep copy broken: tags len=%d", m.Get("tags").Len())
	}
}

func TestSetWholeMessageMismatch(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// A message with a different schema.
	other, _ := ParseSchema([]byte(`{"types":[{"typeId":2002,"fields":[{"name":"x","type":"string","num":1}]}]}`))
	Register(other[0])
	otherMsg, _ := New(2002)
	if err := m.Set("", otherMsg); err != ErrTypeMismatch {
		t.Errorf("Set(\"\", different schema) = %v, want ErrTypeMismatch", err)
	}
	if err := m.Set("name", "x"); err != nil {
		t.Fatalf("Set(name, x): %v", err)
	}
	if err := m.Set("", "not a message"); err != ErrTypeMismatch {
		t.Errorf("Set(\"\", string) = %v, want ErrTypeMismatch", err)
	}
}

// ---------------------------------------------------------------------------
// Append
// ---------------------------------------------------------------------------

func TestAppend(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if err := m.Append("tags", "a"); err != nil {
		t.Fatalf("Append(tags, a): %v", err)
	}
	if err := m.Append("tags", "b"); err != nil {
		t.Fatalf("Append(tags, b): %v", err)
	}
	if m.Get("tags").Len() != 2 || m.Get("tags").Index(1).String() != "b" {
		t.Errorf("tags=%v", m.Get("tags").Strings())
	}

	if err := m.Append("scores", int64(7)); err != nil {
		t.Fatalf("Append(scores, int64): %v", err)
	}
	if m.Get("scores").Int32s()[0] != 7 {
		t.Errorf("scores[0]=%d", m.Get("scores").Int32s()[0])
	}

	// append to non-repeated -> ErrTypeMismatch
	if err := m.Append("name", "x"); err != ErrTypeMismatch {
		t.Errorf("Append(name) = %v, want ErrTypeMismatch", err)
	}
	// append to unknown -> ErrFieldNotFound
	if err := m.Append("unknown", "x"); err != ErrFieldNotFound {
		t.Errorf("Append(unknown) = %v, want ErrFieldNotFound", err)
	}
	// append to self -> ErrTypeMismatch
	if err := m.Append("", "x"); err != ErrTypeMismatch {
		t.Errorf("Append(\"\") = %v, want ErrTypeMismatch", err)
	}
}

func TestAppendMessage(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	c := newMsgForField(m, "contacts")
	c.Set("phone", "123")
	if err := m.Append("contacts", c); err != nil {
		t.Fatalf("Append(contacts, msg): %v", err)
	}
	if m.Get("contacts").Len() != 1 {
		t.Errorf("contacts len=%d", m.Get("contacts").Len())
	}
	// Modify original, message should be a deep copy.
	c.Set("phone", "999")
	if m.Get("contacts").Index(0).Message().Get("phone").String() != "123" {
		t.Errorf("Append did not deep copy")
	}
	// Append nil element is allowed.
	if err := m.Append("contacts", nil); err != nil {
		t.Fatalf("Append(contacts, nil): %v", err)
	}
	if m.Get("contacts").Len() != 2 || m.Get("contacts").Index(1).IsSet() {
		t.Errorf("contacts len/IsSet wrong")
	}
}

// ---------------------------------------------------------------------------
// Clear
// ---------------------------------------------------------------------------

func TestClear(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("name", "alice")
	m.Set("age", 3)
	if err := m.Clear("name"); err != nil {
		t.Fatalf("Clear(name): %v", err)
	}
	if m.Get("name").IsSet() {
		t.Errorf("name should be unset")
	}
	if !m.Get("age").IsSet() {
		t.Errorf("age should still be set")
	}

	// Clear unset field is idempotent
	if err := m.Clear("name"); err != nil {
		t.Errorf("Clear(name) again = %v, want nil", err)
	}

	// Clear unknown -> ErrFieldNotFound
	if err := m.Clear("unknown"); err != ErrFieldNotFound {
		t.Errorf("Clear(unknown) = %v, want ErrFieldNotFound", err)
	}

	// Clear all
	if err := m.Clear(""); err != nil {
		t.Fatalf("Clear(\"\"): %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Errorf("SetFields() after Clear(\"\") = %v", m.SetFields())
	}
}

func TestClearNested(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("addr.city", "beijing")
	if err := m.Clear("addr.city"); err != nil {
		t.Fatalf("Clear(addr.city): %v", err)
	}
	if m.Get("addr.city").IsSet() {
		t.Errorf("addr.city should be unset")
	}
	if !m.Get("addr").IsSet() {
		t.Errorf("addr should still be set")
	}
}

// ---------------------------------------------------------------------------
// Has and SetFields
// ---------------------------------------------------------------------------

func TestHas(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if m.Has("name") {
		t.Errorf("name should not be set initially")
	}
	m.Set("name", "alice")
	if !m.Has("name") {
		t.Errorf("name should be set")
	}
	if m.Has("unknown") {
		t.Errorf("unknown should be false")
	}
	if m.Has("addr.city") {
		t.Errorf("addr.city should be false")
	}
	m.Set("addr.city", "beijing")
	if !m.Has("addr.city") {
		t.Errorf("addr.city should be true")
	}
	if !m.Has("") {
		t.Errorf("Has(\"\") should be true")
	}
}

func TestSetFields(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	if len(m.SetFields()) != 0 {
		t.Errorf("SetFields() initial = %v", m.SetFields())
	}
	m.Set("age", 3)
	m.Set("name", "alice")
	got := m.SetFields()
	want := []string{"name", "age"} // schema order
	if !reflect.DeepEqual(got, want) {
		t.Errorf("SetFields()=%v, want %v", got, want)
	}
}

// ---------------------------------------------------------------------------
// JSON
// ---------------------------------------------------------------------------

func TestEncodeJSON(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("name", "alice")
	m.Set("age", 30)
	m.Set("score", 3.5)
	m.Set("active", true)
	m.Set("data", []byte("hello"))
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")
	m.Append("tags", "b")

	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	got := string(data)
	for _, want := range []string{`"name":"alice"`, `"age":30`, `"active":true`, `"data":"aGVsbG8="`, `"addr":{"city":"beijing"}`, `"tags":["a","b"]`} {
		if !strings.Contains(got, want) {
			t.Errorf("EncodeJSON() missing %s in %s", want, got)
		}
	}
}

func TestEncodeJSONOmitsUnset(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")

	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	if strings.Contains(string(data), "age") {
		t.Errorf("unset field age should be omitted: %s", data)
	}
	if strings.Contains(string(data), "addr") {
		t.Errorf("unset field addr should be omitted: %s", data)
	}
}

func TestEncodeJSONNaN(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("score", math.NaN())
	if _, err := m.EncodeJSON(); err == nil {
		t.Errorf("EncodeJSON with NaN should fail")
	}
}

func TestEncodeJSONRepeatedMessagesNull(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Append("contacts", (*Message)(nil))
	c := newMsgForField(m, "contacts")
	c.Set("phone", "123")
	m.Append("contacts", c)

	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	got := string(data)
	if !strings.Contains(got, `"contacts":[null,{"phone":"123"}]`) {
		t.Errorf("contacts encoding wrong: %s", got)
	}
}

func TestDecodeJSON(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	input := `{
		"name":"bob",
		"age":"notanumber",
		"unknown":123,
		"addr":{"city":"shanghai"},
		"tags":["x","y"]
	}`
	// age is a string for an int32 field -> malformed
	if err := m.DecodeJSON([]byte(input)); err != ErrMalformedData {
		t.Errorf("DecodeJSON with string age = %v, want ErrMalformedData", err)
	}
}

func TestDecodeJSONValid(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	input := `{
		"name":"bob",
		"age":25,
		"unknown":123,
		"addr":{"city":"shanghai","zip":"200000"},
		"tags":["x","y"],
		"scores":[1,2,3],
		"data":"aGVsbG8=",
		"active":true
	}`
	if err := m.DecodeJSON([]byte(input)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m.Get("name").String() != "bob" {
		t.Errorf("name=%q", m.Get("name").String())
	}
	if m.Get("age").Int32() != 25 {
		t.Errorf("age=%d", m.Get("age").Int32())
	}
	if m.Get("addr.city").String() != "shanghai" {
		t.Errorf("addr.city=%q", m.Get("addr.city").String())
	}
	if string(m.Get("data").Bytes()) != "hello" {
		t.Errorf("data=%q", m.Get("data").Bytes())
	}
	if !m.Get("active").Bool() {
		t.Errorf("active should be true")
	}
	if !reflect.DeepEqual(m.Get("scores").Int32s(), []int32{1, 2, 3}) {
		t.Errorf("scores=%v", m.Get("scores").Int32s())
	}
	if m.Has("unknown") {
		t.Errorf("unknown should be ignored")
	}
}

func TestDecodeJSONReplaces(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "old")
	m.Set("age", 99)

	// Decode replaces all fields; age absent -> unset.
	if err := m.DecodeJSON([]byte(`{"name":"new"}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m.Get("name").String() != "new" {
		t.Errorf("name=%q", m.Get("name").String())
	}
	if m.Get("age").IsSet() {
		t.Errorf("age should be unset after replace")
	}
}

func TestDecodeJSONNull(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	m.Set("name", "old")
	m.Set("age", 3)
	// top-level null clears everything.
	if err := m.DecodeJSON([]byte(`null`)); err != nil {
		t.Fatalf("DecodeJSON(null): %v", err)
	}
	if len(m.SetFields()) != 0 {
		t.Errorf("SetFields() after null = %v", m.SetFields())
	}

	// field-level null clears that field.
	m.Set("name", "x")
	m.Set("age", 3)
	if err := m.DecodeJSON([]byte(`{"name":null,"age":4}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m.Get("name").IsSet() {
		t.Errorf("name should be unset")
	}
	if m.Get("age").Int32() != 4 {
		t.Errorf("age=%d", m.Get("age").Int32())
	}
}

func TestDecodeJSONErrors(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	cases := []struct {
		input string
		err   error
	}{
		{"", ErrTruncated},
		{`[]`, ErrMalformedData},
		{`"x"`, ErrMalformedData},
		{`123`, ErrMalformedData},
		{`{`, ErrMalformedData},
		{`{"age":"18"}`, ErrMalformedData},
		{`{"age":2147483648}`, ErrMalformedData},
		{`{"age":1.5}`, ErrMalformedData},
		{`{"scores":[1,null]}`, ErrMalformedData},
		{`{"name":["a"]}`, ErrMalformedData},
		{`{"name":123}`, ErrMalformedData},
		{`{} trailing`, ErrMalformedData},
	}
	for _, c := range cases {
		if err := m.DecodeJSON([]byte(c.input)); err != c.err {
			t.Errorf("DecodeJSON(%q) = %v, want %v", c.input, err, c.err)
		}
	}
}

func TestDecodeJSONRepeatedMessageNull(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	if err := m.DecodeJSON([]byte(`{"contacts":[null,{"phone":"123"}]}`)); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	v := m.Get("contacts")
	if v.Len() != 2 {
		t.Fatalf("contacts len=%d", v.Len())
	}
	if v.Index(0).IsSet() {
		t.Errorf("contacts[0] should be nil element")
	}
	if v.Index(1).Message().Get("phone").String() != "123" {
		t.Errorf("contacts[1] phone wrong")
	}
}

func TestJSONRoundTrip(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", 30)
	m.Set("big", -1234567890123)
	m.Set("cnt", 4000000000)
	m.Set("huge", uint64(18446744073709551615))
	m.Set("ratio", 1.5)
	m.Set("score", 3.14159)
	m.Set("active", true)
	m.Set("data", []byte{0x01, 0x02, 0xff})
	m.Set("addr.city", "beijing")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Append("scores", -1)
	m.Append("scores", 42)

	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}

	m2 := mustNew(t)
	if err := m2.DecodeJSON(data); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m2.Get("name").String() != "alice" {
		t.Errorf("name=%q", m2.Get("name").String())
	}
	if m2.Get("age").Int32() != 30 {
		t.Errorf("age=%d", m2.Get("age").Int32())
	}
	if m2.Get("big").Int64() != -1234567890123 {
		t.Errorf("big=%d", m2.Get("big").Int64())
	}
	if m2.Get("cnt").Uint32() != 4000000000 {
		t.Errorf("cnt=%d", m2.Get("cnt").Uint32())
	}
	if m2.Get("huge").Uint64() != 18446744073709551615 {
		t.Errorf("huge=%d", m2.Get("huge").Uint64())
	}
	if m2.Get("ratio").Float32() != 1.5 {
		t.Errorf("ratio=%v", m2.Get("ratio").Float32())
	}
	if m2.Get("score").Float64() != 3.14159 {
		t.Errorf("score=%v", m2.Get("score").Float64())
	}
	if !m2.Get("active").Bool() {
		t.Errorf("active should be true")
	}
	if !reflect.DeepEqual(m2.Get("data").Bytes(), []byte{0x01, 0x02, 0xff}) {
		t.Errorf("data=%v", m2.Get("data").Bytes())
	}
	if m2.Get("addr.city").String() != "beijing" {
		t.Errorf("addr.city=%q", m2.Get("addr.city").String())
	}
	if !reflect.DeepEqual(m2.Get("tags").Strings(), []string{"a", "b"}) {
		t.Errorf("tags=%v", m2.Get("tags").Strings())
	}
	if !reflect.DeepEqual(m2.Get("scores").Int32s(), []int32{-1, 42}) {
		t.Errorf("scores=%v", m2.Get("scores").Int32s())
	}
}

// ---------------------------------------------------------------------------
// Proto
// ---------------------------------------------------------------------------

func TestProtoRoundTrip(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", -1)
	m.Set("big", -1234567890123)
	m.Set("cnt", 4000000000)
	m.Set("huge", uint64(18446744073709551615))
	m.Set("ratio", 1.5)
	m.Set("score", 2.71828)
	m.Set("active", true)
	m.Set("data", []byte{0x01, 0x02, 0xff})
	m.Set("addr.city", "beijing")
	m.Set("addr.zip", "100000")
	m.Append("tags", "a")
	m.Append("tags", "b")
	m.Append("scores", -1)
	m.Append("scores", 42)
	m.Append("scores", 0)

	proto, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}

	m2 := mustNew(t)
	if err := m2.DecodeProto(proto); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m2.Get("name").String() != "alice" {
		t.Errorf("name=%q", m2.Get("name").String())
	}
	if m2.Get("age").Int32() != -1 {
		t.Errorf("age=%d", m2.Get("age").Int32())
	}
	if m2.Get("big").Int64() != -1234567890123 {
		t.Errorf("big=%d", m2.Get("big").Int64())
	}
	if m2.Get("cnt").Uint32() != 4000000000 {
		t.Errorf("cnt=%d", m2.Get("cnt").Uint32())
	}
	if m2.Get("huge").Uint64() != 18446744073709551615 {
		t.Errorf("huge=%d", m2.Get("huge").Uint64())
	}
	if m2.Get("ratio").Float32() != 1.5 {
		t.Errorf("ratio=%v", m2.Get("ratio").Float32())
	}
	if m2.Get("score").Float64() != 2.71828 {
		t.Errorf("score=%v", m2.Get("score").Float64())
	}
	if !m2.Get("active").Bool() {
		t.Errorf("active should be true")
	}
	if !reflect.DeepEqual(m2.Get("data").Bytes(), []byte{0x01, 0x02, 0xff}) {
		t.Errorf("data=%v", m2.Get("data").Bytes())
	}
	if m2.Get("addr.city").String() != "beijing" || m2.Get("addr.zip").String() != "100000" {
		t.Errorf("addr wrong: %v %v", m2.Get("addr.city").String(), m2.Get("addr.zip").String())
	}
	if !reflect.DeepEqual(m2.Get("tags").Strings(), []string{"a", "b"}) {
		t.Errorf("tags=%v", m2.Get("tags").Strings())
	}
	if !reflect.DeepEqual(m2.Get("scores").Int32s(), []int32{-1, 42, 0}) {
		t.Errorf("scores=%v", m2.Get("scores").Int32s())
	}
}

func TestProtoEmptyInput(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	if err := m.DecodeProto([]byte{}); err != nil {
		t.Errorf("DecodeProto(empty) = %v, want nil", err)
	}
	if len(m.SetFields()) != 0 {
		t.Errorf("SetFields() = %v", m.SetFields())
	}
}

func TestProtoErrors(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	cases := []struct {
		data []byte
		err  error
	}{
		{[]byte{0x00}, ErrMalformedData},        // field number 0
		{[]byte{0x30}, ErrMalformedData},        // field 6 (float) with wire type 0
		{[]byte{0x3e}, ErrMalformedData},        // wire type 6 (0x3e = 7<<3|6)
		{[]byte{0x3f}, ErrMalformedData},        // wire type 7
		{[]byte{0x10, 0x80}, ErrTruncated},      // field 2 (int32) truncated varint
		{[]byte{0x0a, 0x05, 'a'}, ErrTruncated}, // length says 5 but only 1 byte
	}
	for _, c := range cases {
		if err := m.DecodeProto(c.data); err != c.err {
			t.Errorf("DecodeProto(%v) = %v, want %v", c.data, err, c.err)
		}
	}
}

func TestProtoUnknownFieldSkipped(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// field 99 (unknown) wire type 0 with value 123, then field 1 (name) wire 2 "alice"
	data := []byte{
		0x98, 0x06, 0x7b, // field 99 varint 123
		0x0a, 0x05, 'a', 'l', 'i', 'c', 'e', // field 1 length-delimited "alice"
	}
	if err := m.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m.Get("name").String() != "alice" {
		t.Errorf("name=%q", m.Get("name").String())
	}
}

func TestProtoPackedUnpackedMixed(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// Unpacked: field 12 (scores) wire type 0, values 1, 2
	// Packed: field 12 wire type 2, length 2, values 3, 4
	data := []byte{
		0x60, 0x01, // field 12 varint 1
		0x60, 0x02, // field 12 varint 2
		0x62, 0x02, 0x03, 0x04, // field 12 packed [3,4]
	}
	if err := m.DecodeProto(data); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if !reflect.DeepEqual(m.Get("scores").Int32s(), []int32{1, 2, 3, 4}) {
		t.Errorf("scores=%v", m.Get("scores").Int32s())
	}
}

func TestProtoRepeatedMessagesNilSkipped(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Append("contacts", (*Message)(nil))
	c := newMsgForField(m, "contacts")
	c.Set("phone", "123")
	m.Append("contacts", c)

	proto, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}

	m2 := mustNew(t)
	if err := m2.DecodeProto(proto); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m2.Get("contacts").Len() != 1 {
		t.Errorf("contacts len=%d, want 1 (nil skipped)", m2.Get("contacts").Len())
	}
	if m2.Get("contacts").Index(0).Message().Get("phone").String() != "123" {
		t.Errorf("contacts[0] phone wrong")
	}
}

func TestProtoDecodeReplaces(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "old")
	m.Set("age", 99)

	// Encode a fresh message with only name set.
	m2 := mustNew(t)
	m2.Set("name", "new")
	proto, _ := m2.EncodeProto()

	if err := m.DecodeProto(proto); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if m.Get("name").String() != "new" {
		t.Errorf("name=%q", m.Get("name").String())
	}
	if m.Get("age").IsSet() {
		t.Errorf("age should be unset after replace")
	}
}

// ---------------------------------------------------------------------------
// Deep copy
// ---------------------------------------------------------------------------

func TestDeepCopyNested(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	src := mustNew(t)
	src.Set("addr.city", "beijing")
	if err := m.Set("addr", src.Get("addr").Message()); err != nil {
		t.Fatalf("Set(addr): %v", err)
	}

	// Modify source addr, m should be unaffected.
	src.Get("addr").Message().Set("city", "shanghai")
	if m.Get("addr.city").String() != "beijing" {
		t.Errorf("deep copy broken: %q", m.Get("addr.city").String())
	}
}

func TestDeepCopyRepeatedMessages(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	c1 := newMsgForField(m, "contacts")
	c1.Set("phone", "111")
	c2 := newMsgForField(m, "contacts")
	c2.Set("phone", "222")
	if err := m.Set("contacts", []*Message{c1, c2}); err != nil {
		t.Fatalf("Set(contacts): %v", err)
	}

	c1.Set("phone", "999")
	c2.Set("phone", "888")
	if m.Get("contacts").Index(0).Message().Get("phone").String() != "111" {
		t.Errorf("deep copy broken for contacts[0]")
	}
	if m.Get("contacts").Index(1).Message().Get("phone").String() != "222" {
		t.Errorf("deep copy broken for contacts[1]")
	}
}

func TestDeepCopyBytes(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	b := []byte("hello")
	m.Set("data", b)
	b[0] = 'X'
	if string(m.Get("data").Bytes()) != "hello" {
		t.Errorf("deep copy broken for bytes: %q", m.Get("data").Bytes())
	}
}

// ---------------------------------------------------------------------------
// Additional edge cases
// ---------------------------------------------------------------------------

func TestSetSelfCopy(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", 3)
	if err := m.Set("", m); err != nil {
		t.Fatalf("Set(\"\", self): %v", err)
	}
	if m.Get("name").String() != "alice" || m.Get("age").Int32() != 3 {
		t.Errorf("self-copy should be a no-op: %v", m.SetFields())
	}
}

func TestClearUnsetNestedIdempotent(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	// addr unset; clearing a path under it is idempotent.
	if err := m.Clear("addr.city"); err != nil {
		t.Errorf("Clear(addr.city) on unset addr = %v, want nil", err)
	}
	// addr set, city unset; clearing city is idempotent.
	m.Set("addr.city", "beijing")
	if err := m.Clear("addr.zip"); err != nil {
		t.Errorf("Clear(addr.zip) on unset zip = %v, want nil", err)
	}
	if m.Get("addr.city").String() != "beijing" {
		t.Errorf("addr.city should still be set")
	}
}

func TestRepeatedBytes(t *testing.T) {
	resetRegistry()
	cfg := `{"types":[{"typeId":3001,"fields":[{"name":"chunks","type":"bytes","num":1,"repeated":true}]}]}`
	schemas, err := ParseSchema([]byte(cfg))
	if err != nil {
		t.Fatalf("ParseSchema: %v", err)
	}
	if err := Register(schemas[0]); err != nil {
		t.Fatalf("Register: %v", err)
	}
	m, err := New(3001)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	if err := m.Append("chunks", []byte("hello")); err != nil {
		t.Fatalf("Append: %v", err)
	}
	if err := m.Append("chunks", []byte("world")); err != nil {
		t.Fatalf("Append: %v", err)
	}
	if got := m.Get("chunks").BytesSlice(); len(got) != 2 || string(got[0]) != "hello" || string(got[1]) != "world" {
		t.Errorf("chunks=%v", got)
	}

	// JSON round-trip
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	m2, _ := New(3001)
	if err := m2.DecodeJSON(data); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if got := m2.Get("chunks").BytesSlice(); len(got) != 2 || string(got[0]) != "hello" {
		t.Errorf("chunks after JSON=%v", got)
	}

	// Proto round-trip
	pdata, err := m.EncodeProto()
	if err != nil {
		t.Fatalf("EncodeProto: %v", err)
	}
	m3, _ := New(3001)
	if err := m3.DecodeProto(pdata); err != nil {
		t.Fatalf("DecodeProto: %v", err)
	}
	if got := m3.Get("chunks").BytesSlice(); len(got) != 2 || string(got[1]) != "world" {
		t.Errorf("chunks after proto=%v", got)
	}
}

func TestSetNestedAutoCreateDeeper(t *testing.T) {
	resetRegistry()
	cfg := `{"types":[{"typeId":4001,"fields":[
		{"name":"a","type":"message","num":1,"schema":{"fields":[
			{"name":"b","type":"message","num":1,"schema":{"fields":[
				{"name":"c","type":"string","num":1}
			]}}
		]}}
	]}]}`
	schemas, _ := ParseSchema([]byte(cfg))
	Register(schemas[0])
	m, _ := New(4001)
	if err := m.Set("a.b.c", "deep"); err != nil {
		t.Fatalf("Set(a.b.c): %v", err)
	}
	if m.Get("a.b.c").String() != "deep" {
		t.Errorf("a.b.c=%q", m.Get("a.b.c").String())
	}
	if !m.Get("a").IsSet() || !m.Get("a.b").IsSet() {
		t.Errorf("intermediate messages not auto-created")
	}
}

func TestSetNestedMessageField(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	addr := newMsgForField(m, "addr")
	addr.Set("city", "beijing")
	if err := m.Set("addr", addr); err != nil {
		t.Fatalf("Set(addr): %v", err)
	}
	// Mutating source after Set must not affect m.
	addr.Set("city", "shanghai")
	if m.Get("addr.city").String() != "beijing" {
		t.Errorf("addr.city=%q, want beijing", m.Get("addr.city").String())
	}
}

func TestAppendToNestedRepeated(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	c := newMsgForField(m, "contacts")
	c.Set("phone", "123")
	m.Append("contacts", c)
	if m.Get("contacts[0].phone").String() != "123" {
		t.Errorf("contacts[0].phone=%q", m.Get("contacts[0].phone").String())
	}
}

func TestSetIndexedNestedMessage(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// Appending a nil element creates the array slot; Set can then fill it.
	if err := m.Append("contacts", (*Message)(nil)); err != nil {
		t.Fatalf("Append(contacts, nil): %v", err)
	}
	if err := m.Set("contacts[0].phone", "123"); err != nil {
		t.Fatalf("Set(contacts[0].phone): %v", err)
	}
	if m.Get("contacts[0].phone").String() != "123" {
		t.Errorf("contacts[0].phone=%q", m.Get("contacts[0].phone").String())
	}
	if !m.Get("contacts[0]").IsSet() {
		t.Errorf("contacts[0] should be set")
	}

	// Unset array with indexed path -> ErrIndexOutOfRange.
	m2 := mustNew(t)
	if err := m2.Set("contacts[0].phone", "123"); err != ErrIndexOutOfRange {
		t.Errorf("Set(contacts[0].phone) on unset array = %v, want ErrIndexOutOfRange", err)
	}
}

func TestRepeatedFieldWithoutIndexPath(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Append("contacts", (*Message)(nil))

	// A repeated message field must be accessed with an index before descending.
	if v := m.Get("contacts.phone"); v.Err() != ErrFieldNotFound {
		t.Errorf("Get(contacts.phone).Err() = %v, want ErrFieldNotFound", v.Err())
	}
	if err := m.Set("contacts.phone", "123"); err != ErrFieldNotFound {
		t.Errorf("Set(contacts.phone) = %v, want ErrFieldNotFound", err)
	}
	if err := m.Clear("contacts.phone"); err != ErrFieldNotFound {
		t.Errorf("Clear(contacts.phone) = %v, want ErrFieldNotFound", err)
	}
}

func TestAnyNativeTypes(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "alice")
	m.Set("age", 30)
	m.Set("score", 1.5)
	m.Set("active", true)
	m.Set("data", []byte("x"))
	m.Append("tags", "a")

	if m.Get("name").Any() != "alice" {
		t.Errorf("Any(name)=%v", m.Get("name").Any())
	}
	if m.Get("age").Any() != int32(30) {
		t.Errorf("Any(age)=%v", m.Get("age").Any())
	}
	if m.Get("score").Any() != 1.5 {
		t.Errorf("Any(score)=%v", m.Get("score").Any())
	}
	if m.Get("active").Any() != true {
		t.Errorf("Any(active)=%v", m.Get("active").Any())
	}
	if !reflect.DeepEqual(m.Get("data").Any(), []byte("x")) {
		t.Errorf("Any(data)=%v", m.Get("data").Any())
	}
	if !reflect.DeepEqual(m.Get("tags").Any(), []string{"a"}) {
		t.Errorf("Any(tags)=%v", m.Get("tags").Any())
	}
}

func TestAliasTypeConversion(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	type MyInt32 int32
	type MyString string
	type MyBytes []byte

	if err := m.Set("age", MyInt32(42)); err != nil {
		t.Fatalf("Set(age, MyInt32): %v", err)
	}
	if m.Get("age").Int32() != 42 {
		t.Errorf("age=%d", m.Get("age").Int32())
	}
	if err := m.Set("name", MyString("hello")); err != nil {
		t.Fatalf("Set(name, MyString): %v", err)
	}
	if m.Get("name").String() != "hello" {
		t.Errorf("name=%q", m.Get("name").String())
	}
	if err := m.Set("data", MyBytes("raw")); err != nil {
		t.Fatalf("Set(data, MyBytes): %v", err)
	}
	if string(m.Get("data").Bytes()) != "raw" {
		t.Errorf("data=%q", m.Get("data").Bytes())
	}
}

func TestSetNestedNilClears(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("addr.city", "beijing")
	if err := m.Set("addr", nil); err != nil {
		t.Fatalf("Set(addr, nil): %v", err)
	}
	if m.Get("addr").IsSet() {
		t.Errorf("addr should be unset after Set(addr, nil)")
	}
	if m.Has("addr.city") {
		t.Errorf("addr.city should be unset after Set(addr, nil)")
	}
}

func TestAppendWrongSchemaMessage(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	// A top-level message is not isomorphic to the contacts nested schema.
	if err := m.Append("contacts", m); err != ErrTypeMismatch {
		t.Errorf("Append(contacts, top-level msg) = %v, want ErrTypeMismatch", err)
	}
}

func TestProtoWireTypeMismatch(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// Field 1 (name, string) with wire type 0 (varint) -> mismatch.
	if err := m.DecodeProto([]byte{0x08, 0x01}); err != ErrMalformedData {
		t.Errorf("DecodeProto string-as-varint = %v, want ErrMalformedData", err)
	}
	// Field 6 (ratio, float) with wire type 0 -> mismatch.
	if err := m.DecodeProto([]byte{0x30, 0x01}); err != ErrMalformedData {
		t.Errorf("DecodeProto float-as-varint = %v, want ErrMalformedData", err)
	}
	// Field 7 (score, double) with wire type 5 (fixed32) -> mismatch.
	if err := m.DecodeProto([]byte{0x3d, 0x00, 0x00, 0x00, 0x00}); err != ErrMalformedData {
		t.Errorf("DecodeProto double-as-fixed32 = %v, want ErrMalformedData", err)
	}
}

// ---------------------------------------------------------------------------
// Concurrency
// ---------------------------------------------------------------------------

func TestConcurrentRegisterNew(t *testing.T) {
	resetRegistry()
	schemas, _ := ParseSchema([]byte(testConfig))
	done := make(chan bool)
	for i := 0; i < 20; i++ {
		go func() {
			for j := 0; j < 50; j++ {
				Register(schemas[0])
				New(1001)
			}
			done <- true
		}()
	}
	for i := 0; i < 20; i++ {
		<-done
	}
}

// ---------------------------------------------------------------------------
// JSON string escaping and bytes
// ---------------------------------------------------------------------------

func TestJSONStringEscaping(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	m.Set("name", "a\"b\\c\n")
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	m2 := mustNew(t)
	if err := m2.DecodeJSON(data); err != nil {
		t.Fatalf("DecodeJSON: %v", err)
	}
	if m2.Get("name").String() != "a\"b\\c\n" {
		t.Errorf("name=%q", m2.Get("name").String())
	}
}

// ---------------------------------------------------------------------------
// Numeric conversion edge cases
// ---------------------------------------------------------------------------

func TestSetNumericConversions(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)

	// int32 from various
	if err := m.Set("age", uint32(10)); err != nil {
		t.Fatalf("Set(age, uint32): %v", err)
	}
	if m.Get("age").Int32() != 10 {
		t.Errorf("age=%d", m.Get("age").Int32())
	}

	if err := m.Set("age", "0x1F"); err != ErrTypeMismatch {
		t.Errorf("Set(age, hex string) = %v, want ErrTypeMismatch (only base-10)", err)
	}

	// string numeric for float
	if err := m.Set("score", "3.14"); err != nil {
		t.Fatalf("Set(score, string): %v", err)
	}
	if math.Abs(m.Get("score").Float64()-3.14) > 1e-9 {
		t.Errorf("score=%v", m.Get("score").Float64())
	}

	// uint64 max
	if err := m.Set("huge", "18446744073709551615"); err != nil {
		t.Fatalf("Set(huge, max string): %v", err)
	}
	if m.Get("huge").Uint64() != 18446744073709551615 {
		t.Errorf("huge=%d", m.Get("huge").Uint64())
	}
	if err := m.Set("huge", "18446744073709551616"); err != ErrTypeMismatch {
		t.Errorf("Set(huge, overflow string) = %v, want ErrTypeMismatch", err)
	}
}

// ---------------------------------------------------------------------------
// Helpers / sanity
// ---------------------------------------------------------------------------

func TestAppendAutoCreate(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	if m.Get("tags").IsSet() {
		t.Fatal("tags should be unset initially")
	}
	if err := m.Append("tags", "a"); err != nil {
		t.Fatalf("Append: %v", err)
	}
	if !m.Get("tags").IsSet() || m.Get("tags").Len() != 1 {
		t.Errorf("tags after append: IsSet=%v Len=%d", m.Get("tags").IsSet(), m.Get("tags").Len())
	}
}

func TestSetEmptyRepeated(t *testing.T) {
	resetRegistry()
	registerTestSchema(t)
	m := mustNew(t)
	if err := m.Set("tags", []string{}); err != nil {
		t.Fatalf("Set(tags, empty): %v", err)
	}
	if !m.Get("tags").IsSet() || m.Get("tags").Len() != 0 {
		t.Errorf("tags after empty set: IsSet=%v Len=%d", m.Get("tags").IsSet(), m.Get("tags").Len())
	}
	data, err := m.EncodeJSON()
	if err != nil {
		t.Fatalf("EncodeJSON: %v", err)
	}
	if !bytes.Contains(data, []byte(`"tags":[]`)) {
		t.Errorf("EncodeJSON should include empty tags: %s", data)
	}
}
