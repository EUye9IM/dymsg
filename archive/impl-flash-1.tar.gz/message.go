package dymsg

// This file implements the field-access API: Message.Get/Set/Append/Clear/Has/
// SetFields and the Value type's accessors.

// ---------------------------------------------------------------------------
// Get
// ---------------------------------------------------------------------------

// Get returns the value at the given path.
//
// The empty path refers to the message itself. A path is a dot-separated list
// of field names, optionally with a bracketed index for repeated fields, e.g.
// "addr.city" or "items[0].name". Errors are carried in the returned Value
// rather than returned directly.
func (m *Message) Get(path string) Value {
	steps, err := parsePath(path)
	if err != nil {
		return Value{err: err}
	}
	if len(steps) == 0 {
		return Value{exists: true, isSet: true, value: m}
	}

	curSchema := m.schema
	curMsg := m

	for i, step := range steps {
		fi, ok := curSchema.byName[step.name]
		if !ok {
			return Value{err: ErrFieldNotFound}
		}
		fs := curSchema.fields[fi]
		fv := getFieldValue(curMsg, fi)
		last := i == len(steps)-1

		if step.hasIndex {
			if !fs.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			if !fv.set {
				return Value{err: ErrIndexOutOfRange}
			}
			n := sliceLen(fv.value)
			if step.index < 0 || step.index >= n {
				return Value{err: ErrIndexOutOfRange}
			}
			elem := sliceIndex(fv.value, step.index)
			if last {
				return valueForElement(fs, elem)
			}
			if fs.Type != FieldMessage {
				return Value{err: ErrFieldNotFound}
			}
			em, _ := elem.(*Message)
			if em == nil {
				curMsg = nil
			} else {
				curMsg = em
			}
			curSchema = &fs.Schema
		} else {
			if last {
				return valueForField(fs, fv)
			}
			if fs.Type != FieldMessage || fs.Repeated {
				return Value{err: ErrFieldNotFound}
			}
			if !fv.set || fv.value == nil {
				curMsg = nil
			} else {
				curMsg = fv.value.(*Message)
			}
			curSchema = &fs.Schema
		}
	}
	return Value{}
}

func valueForField(fs *FieldSchema, fv fieldValue) Value {
	if !fv.set {
		return Value{exists: true, isSet: false}
	}
	if fs.Type == FieldMessage && fv.value == nil {
		return Value{exists: true, isSet: false}
	}
	return Value{exists: true, isSet: true, value: fv.value}
}

func valueForElement(fs *FieldSchema, elem any) Value {
	if fs.Type == FieldMessage {
		if m, ok := elem.(*Message); ok && m == nil {
			return Value{exists: true, isSet: false}
		}
	}
	return Value{exists: true, isSet: true, value: elem}
}

// ---------------------------------------------------------------------------
// Set
// ---------------------------------------------------------------------------

// Set assigns value to the field at path.
//
// Set("", m) overwrites the whole message with a deep copy of m. Set(path,
// nil) clears the field. Intermediate message fields are created
// automatically when they are unset.
func (m *Message) Set(path string, value any) error {
	if path == "" {
		if value == nil {
			m.clearAll()
			return nil
		}
		src, ok := value.(*Message)
		if !ok || !schemaIsomorphic(m.schema, src.schema) {
			return ErrTypeMismatch
		}
		if src == m {
			return nil
		}
		copyMessageInto(m, src)
		return nil
	}

	steps, err := parsePath(path)
	if err != nil {
		return err
	}

	cur := m
	for i := 0; i < len(steps)-1; i++ {
		step := steps[i]
		fi, ok := cur.schema.byName[step.name]
		if !ok {
			return ErrFieldNotFound
		}
		fs := cur.schema.fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set {
				return ErrIndexOutOfRange
			}
			arr := cur.fields[fi].value.([]*Message)
			if step.index < 0 || step.index >= len(arr) {
				return ErrIndexOutOfRange
			}
			elem := arr[step.index]
			if elem == nil {
				elem = &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
				arr[step.index] = elem
			}
			cur = elem
		} else {
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set || cur.fields[fi].value == nil {
				sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
				cur.fields[fi].set = true
				cur.fields[fi].value = sub
			}
			cur = cur.fields[fi].value.(*Message)
		}
	}

	last := steps[len(steps)-1]
	fi, ok := cur.schema.byName[last.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := cur.schema.fields[fi]

	if last.hasIndex {
		if !fs.Repeated {
			return ErrFieldNotFound
		}
		if !cur.fields[fi].set {
			return ErrIndexOutOfRange
		}
		n := sliceLen(cur.fields[fi].value)
		if last.index < 0 || last.index >= n {
			return ErrIndexOutOfRange
		}
		var elemVal any
		if value == nil {
			elemVal = zeroElement(fs.Type)
		} else {
			var err error
			elemVal, err = convertElement(fs, value)
			if err != nil {
				return err
			}
		}
		setSliceIndex(&cur.fields[fi], last.index, elemVal)
		return nil
	}

	if value == nil {
		cur.fields[fi].set = false
		cur.fields[fi].value = nil
		return nil
	}

	if fs.Repeated {
		converted, err := convertRepeatedValue(fs, value)
		if err != nil {
			return err
		}
		cur.fields[fi].set = true
		cur.fields[fi].value = converted
		return nil
	}

	converted, err := convertScalarToField(fs, value)
	if err != nil {
		return err
	}
	if fs.Type == FieldMessage {
		if msg, ok := converted.(*Message); ok && msg == nil {
			cur.fields[fi].set = false
			cur.fields[fi].value = nil
			return nil
		}
	}
	cur.fields[fi].set = true
	cur.fields[fi].value = converted
	return nil
}

// ---------------------------------------------------------------------------
// Append
// ---------------------------------------------------------------------------

// Append appends a single element to the repeated field at path.
//
// If the repeated field is unset, an empty array is created first. The path
// must point to a repeated field (no trailing index).
func (m *Message) Append(path string, value any) error {
	steps, err := parsePath(path)
	if err != nil {
		return err
	}
	if len(steps) == 0 {
		return ErrTypeMismatch
	}

	cur := m
	for i := 0; i < len(steps)-1; i++ {
		step := steps[i]
		fi, ok := cur.schema.byName[step.name]
		if !ok {
			return ErrFieldNotFound
		}
		fs := cur.schema.fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set {
				return ErrIndexOutOfRange
			}
			arr := cur.fields[fi].value.([]*Message)
			if step.index < 0 || step.index >= len(arr) {
				return ErrIndexOutOfRange
			}
			elem := arr[step.index]
			if elem == nil {
				elem = &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
				arr[step.index] = elem
			}
			cur = elem
		} else {
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set || cur.fields[fi].value == nil {
				sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
				cur.fields[fi].set = true
				cur.fields[fi].value = sub
			}
			cur = cur.fields[fi].value.(*Message)
		}
	}

	last := steps[len(steps)-1]
	if last.hasIndex {
		return ErrTypeMismatch
	}
	fi, ok := cur.schema.byName[last.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := cur.schema.fields[fi]
	if !fs.Repeated {
		return ErrTypeMismatch
	}
	elemVal, err := convertElement(fs, value)
	if err != nil {
		return err
	}
	appendSlice(&cur.fields[fi], elemVal)
	return nil
}

// ---------------------------------------------------------------------------
// Clear
// ---------------------------------------------------------------------------

// Clear sets the field at path to unset.
//
// Clear("") clears all fields. Clearing an already-unset field is idempotent.
// For an indexed path the element is reset to its zero value (nil for message
// elements).
func (m *Message) Clear(path string) error {
	if path == "" {
		m.clearAll()
		return nil
	}

	steps, err := parsePath(path)
	if err != nil {
		return err
	}

	cur := m
	for i := 0; i < len(steps)-1; i++ {
		step := steps[i]
		fi, ok := cur.schema.byName[step.name]
		if !ok {
			return ErrFieldNotFound
		}
		fs := cur.schema.fields[fi]
		if step.hasIndex {
			if !fs.Repeated {
				return ErrFieldNotFound
			}
			if fs.Type != FieldMessage {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set {
				return ErrIndexOutOfRange
			}
			arr := cur.fields[fi].value.([]*Message)
			if step.index < 0 || step.index >= len(arr) {
				return ErrIndexOutOfRange
			}
			elem := arr[step.index]
			if elem == nil {
				return nil // idempotent
			}
			cur = elem
		} else {
			if fs.Type != FieldMessage || fs.Repeated {
				return ErrFieldNotFound
			}
			if !cur.fields[fi].set || cur.fields[fi].value == nil {
				return nil // idempotent
			}
			cur = cur.fields[fi].value.(*Message)
		}
	}

	last := steps[len(steps)-1]
	fi, ok := cur.schema.byName[last.name]
	if !ok {
		return ErrFieldNotFound
	}
	fs := cur.schema.fields[fi]
	if last.hasIndex {
		if !fs.Repeated {
			return ErrFieldNotFound
		}
		if !cur.fields[fi].set {
			return ErrIndexOutOfRange
		}
		n := sliceLen(cur.fields[fi].value)
		if last.index < 0 || last.index >= n {
			return ErrIndexOutOfRange
		}
		setSliceIndex(&cur.fields[fi], last.index, zeroElement(fs.Type))
		return nil
	}
	cur.fields[fi].set = false
	cur.fields[fi].value = nil
	return nil
}

// ---------------------------------------------------------------------------
// Presence
// ---------------------------------------------------------------------------

// Has reports whether the field at path exists and is set.
func (m *Message) Has(path string) bool {
	if path == "" {
		return true
	}
	v := m.Get(path)
	return v.Exists() && v.IsSet()
}

// SetFields returns the names of all currently set fields in schema order.
// It returns an empty (non-nil) slice when no fields are set.
func (m *Message) SetFields() []string {
	res := make([]string, 0)
	for i, fv := range m.fields {
		if fv.set {
			res = append(res, m.schema.fields[i].Name)
		}
	}
	return res
}

// ---------------------------------------------------------------------------
// Value
// ---------------------------------------------------------------------------

// Exists reports whether the path was valid and the field/element exists in
// the schema.
func (v Value) Exists() bool { return v.exists }

// IsSet reports whether the field/element is set (presence).
func (v Value) IsSet() bool { return v.isSet }

// Err returns the path-resolution error, or nil on success.
func (v Value) Err() error { return v.err }

// Any returns the native Go value. For scalars it is the native type; for
// nested messages it is *Message; for repeated fields it is the corresponding
// slice. It returns nil when the value is unset or does not exist.
func (v Value) Any() any {
	if !v.exists || !v.isSet {
		return nil
	}
	return v.value
}

// String returns the string value, or "" when unset/nonexistent/type mismatch.
func (v Value) String() string {
	if v.exists && v.isSet {
		if s, ok := v.value.(string); ok {
			return s
		}
	}
	return ""
}

// Int32 returns the int32 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Int32() int32 {
	if v.exists && v.isSet {
		if n, ok := v.value.(int32); ok {
			return n
		}
	}
	return 0
}

// Int64 returns the int64 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Int64() int64 {
	if v.exists && v.isSet {
		if n, ok := v.value.(int64); ok {
			return n
		}
	}
	return 0
}

// Uint32 returns the uint32 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Uint32() uint32 {
	if v.exists && v.isSet {
		if n, ok := v.value.(uint32); ok {
			return n
		}
	}
	return 0
}

// Uint64 returns the uint64 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Uint64() uint64 {
	if v.exists && v.isSet {
		if n, ok := v.value.(uint64); ok {
			return n
		}
	}
	return 0
}

// Float32 returns the float32 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Float32() float32 {
	if v.exists && v.isSet {
		if f, ok := v.value.(float32); ok {
			return f
		}
	}
	return 0
}

// Float64 returns the float64 value, or 0 when unset/nonexistent/type mismatch.
func (v Value) Float64() float64 {
	if v.exists && v.isSet {
		if f, ok := v.value.(float64); ok {
			return f
		}
	}
	return 0
}

// Bool returns the bool value, or false when unset/nonexistent/type mismatch.
func (v Value) Bool() bool {
	if v.exists && v.isSet {
		if b, ok := v.value.(bool); ok {
			return b
		}
	}
	return false
}

// Bytes returns the []byte value, or nil when unset/nonexistent/type mismatch.
func (v Value) Bytes() []byte {
	if v.exists && v.isSet {
		if b, ok := v.value.([]byte); ok {
			return b
		}
	}
	return nil
}

// Message returns the nested *Message, or nil when the value is not a set
// message.
func (v Value) Message() *Message {
	if v.exists && v.isSet {
		if m, ok := v.value.(*Message); ok {
			return m
		}
	}
	return nil
}

// Len returns the length of a repeated field; 0 for non-repeated, unset, or
// nonexistent values.
func (v Value) Len() int {
	if !v.exists || !v.isSet {
		return 0
	}
	return sliceLen(v.value)
}

// Index returns the i-th element of a repeated field as a Value.
func (v Value) Index(i int) Value {
	if !v.exists || !v.isSet {
		return Value{err: ErrIndexOutOfRange}
	}
	n := sliceLen(v.value)
	if i < 0 || i >= n {
		return Value{err: ErrIndexOutOfRange}
	}
	elem := sliceIndex(v.value, i)
	if m, ok := elem.(*Message); ok && m == nil {
		return Value{exists: true, isSet: false}
	}
	return Value{exists: true, isSet: true, value: elem}
}

// Strings returns the []string value, or nil when unset/nonexistent/mismatch.
func (v Value) Strings() []string {
	if v.exists && v.isSet {
		if s, ok := v.value.([]string); ok {
			return s
		}
	}
	return nil
}

// Int32s returns the []int32 value, or nil when unset/nonexistent/mismatch.
func (v Value) Int32s() []int32 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]int32); ok {
			return s
		}
	}
	return nil
}

// Int64s returns the []int64 value, or nil when unset/nonexistent/mismatch.
func (v Value) Int64s() []int64 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]int64); ok {
			return s
		}
	}
	return nil
}

// Uint32s returns the []uint32 value, or nil when unset/nonexistent/mismatch.
func (v Value) Uint32s() []uint32 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]uint32); ok {
			return s
		}
	}
	return nil
}

// Uint64s returns the []uint64 value, or nil when unset/nonexistent/mismatch.
func (v Value) Uint64s() []uint64 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]uint64); ok {
			return s
		}
	}
	return nil
}

// Float32s returns the []float32 value, or nil when unset/nonexistent/mismatch.
func (v Value) Float32s() []float32 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]float32); ok {
			return s
		}
	}
	return nil
}

// Float64s returns the []float64 value, or nil when unset/nonexistent/mismatch.
func (v Value) Float64s() []float64 {
	if v.exists && v.isSet {
		if s, ok := v.value.([]float64); ok {
			return s
		}
	}
	return nil
}

// Bools returns the []bool value, or nil when unset/nonexistent/mismatch.
func (v Value) Bools() []bool {
	if v.exists && v.isSet {
		if s, ok := v.value.([]bool); ok {
			return s
		}
	}
	return nil
}

// BytesSlice returns the [][]byte value, or nil when unset/nonexistent/mismatch.
func (v Value) BytesSlice() [][]byte {
	if v.exists && v.isSet {
		if s, ok := v.value.([][]byte); ok {
			return s
		}
	}
	return nil
}

// Messages returns the []*Message value, or nil when unset/nonexistent/mismatch.
func (v Value) Messages() []*Message {
	if v.exists && v.isSet {
		if s, ok := v.value.([]*Message); ok {
			return s
		}
	}
	return nil
}
