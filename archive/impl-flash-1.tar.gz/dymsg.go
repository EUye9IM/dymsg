// Package dymsg implements a dynamic message encoding/decoding library.
//
// Message schemas are defined at runtime from JSON configuration files and
// registered by type ID. Messages can be read and written field-by-field using
// path expressions, and can be encoded/decoded to either JSON or a
// self-implemented subset of the Protobuf wire format.
package dymsg

import (
	"encoding/json"
	"errors"
	"math"
	"reflect"
	"strconv"
	"strings"
	"sync"
)

// FieldType is the type of a field.
type FieldType string

// Supported field types.
const (
	FieldInt32   FieldType = "int32"
	FieldInt64   FieldType = "int64"
	FieldUint32  FieldType = "uint32"
	FieldUint64  FieldType = "uint64"
	FieldFloat   FieldType = "float"
	FieldDouble  FieldType = "double"
	FieldBool    FieldType = "bool"
	FieldString  FieldType = "string"
	FieldBytes   FieldType = "bytes"
	FieldMessage FieldType = "message"
)

// Sentinel errors.
var (
	ErrDuplicateID     = errors.New("dymsg: duplicate type id")
	ErrUnknownTypeID   = errors.New("dymsg: unknown type id")
	ErrFieldNotFound   = errors.New("dymsg: field not found")
	ErrIndexOutOfRange = errors.New("dymsg: index out of range")
	ErrTypeMismatch    = errors.New("dymsg: type mismatch")
	ErrMalformedData   = errors.New("dymsg: malformed data")
	ErrTruncated       = errors.New("dymsg: truncated data")
)

// FieldSchema describes a single field within a message schema.
type FieldSchema struct {
	Name     string        // field name, also used as the JSON key
	Num      int           // proto field number, in [1, 65535]
	Type     FieldType     // field type
	Repeated bool          // whether the field is an array
	Schema   MessageSchema // inline nested schema when Type == FieldMessage
}

// MessageSchema describes the structure of a message type.
//
// The internal representation is implementation-defined. A MessageSchema
// returned by ParseSchema represents one top-level message type. Nested
// schemas are embedded inside FieldSchema.Schema and carry no type ID.
type MessageSchema struct {
	typeID uint16
	fields []*FieldSchema
	byName map[string]int // field name -> index in fields
	byNum  map[int]int    // proto field number -> index in fields
}

// fieldValue stores the runtime value of a single field inside a Message.
type fieldValue struct {
	set   bool
	value any
}

// Message represents one structured message instance.
//
// A Message is not safe for concurrent use by multiple goroutines; callers
// must synchronize access to a single Message themselves. Register and New are
// concurrency safe.
type Message struct {
	schema *MessageSchema
	fields []fieldValue
}

// Value is the result of a Get call. It carries the existence, presence and
// value of the field (or element) addressed by a path.
type Value struct {
	exists bool
	isSet  bool
	err    error
	value  any
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------

var (
	registryMu sync.RWMutex
	registry   = make(map[uint16]*MessageSchema)
)

// Register registers a message schema by its type ID.
//
// Registering the same type ID with an identical schema is idempotent and
// returns nil. Registering the same type ID with a different schema returns
// ErrDuplicateID.
func Register(s MessageSchema) error {
	if s.typeID == 0 {
		return ErrMalformedData
	}
	registryMu.Lock()
	defer registryMu.Unlock()
	if existing, ok := registry[s.typeID]; ok {
		if schemaIsomorphic(existing, &s) {
			return nil
		}
		return ErrDuplicateID
	}
	cp := s
	registry[s.typeID] = &cp
	return nil
}

// New creates a new empty Message for a registered type ID.
func New(typeID uint16) (*Message, error) {
	registryMu.RLock()
	s, ok := registry[typeID]
	registryMu.RUnlock()
	if !ok {
		return nil, ErrUnknownTypeID
	}
	return &Message{schema: s, fields: make([]fieldValue, len(s.fields))}, nil
}

// ---------------------------------------------------------------------------
// Schema parsing
// ---------------------------------------------------------------------------

// configType mirrors a top-level type entry in the config JSON.
type configType struct {
	TypeID *uint16           `json:"typeId"`
	Fields []json.RawMessage `json:"fields"`
}

// configField mirrors a single field entry in the config JSON.
type configField struct {
	Name     *string         `json:"name"`
	Type     *string         `json:"type"`
	Num      *int            `json:"num"`
	Repeated *bool           `json:"repeated"`
	Schema   json.RawMessage `json:"schema"`
}

// ParseSchema parses a JSON configuration file into a list of message schemas.
//
// The schemas must be registered with Register before they can be used with
// New. The returned schemas contain unexported state; they should be treated
// as immutable values.
func ParseSchema(data []byte) ([]MessageSchema, error) {
	var cfg struct {
		Types []json.RawMessage `json:"types"`
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, ErrMalformedData
	}
	if len(cfg.Types) == 0 {
		return []MessageSchema{}, nil
	}
	seen := make(map[uint16]bool, len(cfg.Types))
	result := make([]MessageSchema, 0, len(cfg.Types))
	for _, raw := range cfg.Types {
		var t configType
		if err := json.Unmarshal(raw, &t); err != nil {
			return nil, ErrMalformedData
		}
		if t.TypeID == nil {
			return nil, ErrMalformedData
		}
		id := *t.TypeID
		if id == 0 || id > 65535 {
			return nil, ErrMalformedData
		}
		if seen[id] {
			return nil, ErrMalformedData
		}
		seen[id] = true
		s, err := parseMessageSchema(id, t.Fields)
		if err != nil {
			return nil, err
		}
		result = append(result, s)
	}
	return result, nil
}

func parseMessageSchema(typeID uint16, rawFields []json.RawMessage) (MessageSchema, error) {
	s := MessageSchema{
		typeID: typeID,
		fields: make([]*FieldSchema, 0, len(rawFields)),
		byName: make(map[string]int),
		byNum:  make(map[int]int),
	}
	for _, raw := range rawFields {
		var cf configField
		if err := json.Unmarshal(raw, &cf); err != nil {
			return MessageSchema{}, ErrMalformedData
		}
		if cf.Name == nil || cf.Type == nil || cf.Num == nil {
			return MessageSchema{}, ErrMalformedData
		}
		name := *cf.Name
		if name == "" || strings.ContainsAny(name, ".[]") {
			return MessageSchema{}, ErrMalformedData
		}
		ft := FieldType(*cf.Type)
		switch ft {
		case FieldInt32, FieldInt64, FieldUint32, FieldUint64,
			FieldFloat, FieldDouble, FieldBool, FieldString, FieldBytes, FieldMessage:
		default:
			return MessageSchema{}, ErrMalformedData
		}
		num := *cf.Num
		if num < 1 || num > 65535 {
			return MessageSchema{}, ErrMalformedData
		}
		if _, ok := s.byName[name]; ok {
			return MessageSchema{}, ErrMalformedData
		}
		if _, ok := s.byNum[num]; ok {
			return MessageSchema{}, ErrMalformedData
		}
		fs := &FieldSchema{
			Name:     name,
			Num:      num,
			Type:     ft,
			Repeated: cf.Repeated != nil && *cf.Repeated,
		}
		hasSchema := len(cf.Schema) > 0
		if ft == FieldMessage {
			if !hasSchema {
				return MessageSchema{}, ErrMalformedData
			}
			var nested struct {
				Fields []json.RawMessage `json:"fields"`
			}
			if err := json.Unmarshal(cf.Schema, &nested); err != nil {
				return MessageSchema{}, ErrMalformedData
			}
			ns, err := parseMessageSchema(0, nested.Fields)
			if err != nil {
				return MessageSchema{}, err
			}
			fs.Schema = ns
		} else {
			if hasSchema {
				return MessageSchema{}, ErrMalformedData
			}
		}
		idx := len(s.fields)
		s.fields = append(s.fields, fs)
		s.byName[name] = idx
		s.byNum[num] = idx
	}
	return s, nil
}

// schemaIsomorphic reports whether two schemas describe the same message
// structure (same fields with same names, numbers, types, repeated flags, and
// isomorphic nested schemas). Field order is not significant.
func schemaIsomorphic(a, b *MessageSchema) bool {
	if a == nil || b == nil {
		return a == b
	}
	if len(a.fields) != len(b.fields) {
		return false
	}
	for _, fa := range a.fields {
		fi, ok := b.byName[fa.Name]
		if !ok {
			return false
		}
		fb := b.fields[fi]
		if fa.Num != fb.Num || fa.Type != fb.Type || fa.Repeated != fb.Repeated {
			return false
		}
		if fa.Type == FieldMessage {
			if !schemaIsomorphic(&fa.Schema, &fb.Schema) {
				return false
			}
		}
	}
	return true
}

// ---------------------------------------------------------------------------
// Path parsing
// ---------------------------------------------------------------------------

// pathStep is one component of a field path.
type pathStep struct {
	name     string
	index    int
	hasIndex bool
}

// parsePath parses a field path expression into a sequence of steps.
//
// The empty path yields no steps (referring to the message itself). A step is
// a field name optionally followed by a single non-negative decimal index in
// square brackets, e.g. "addr.city" or "items[0].name".
func parsePath(path string) ([]pathStep, error) {
	if path == "" {
		return nil, nil
	}
	parts := strings.Split(path, ".")
	steps := make([]pathStep, 0, len(parts))
	for _, part := range parts {
		step, err := parseSegment(part)
		if err != nil {
			return nil, err
		}
		steps = append(steps, step)
	}
	return steps, nil
}

func parseSegment(seg string) (pathStep, error) {
	idx := strings.IndexByte(seg, '[')
	if idx == -1 {
		if seg == "" {
			return pathStep{}, ErrFieldNotFound
		}
		return pathStep{name: seg, index: -1}, nil
	}
	name := seg[:idx]
	if name == "" {
		return pathStep{}, ErrFieldNotFound
	}
	if seg[len(seg)-1] != ']' {
		// e.g. "tags[0" or "tags[0]x"
		return pathStep{}, ErrFieldNotFound
	}
	inside := seg[idx+1 : len(seg)-1]
	if inside == "" {
		return pathStep{}, ErrIndexOutOfRange
	}
	for _, c := range inside {
		if c < '0' || c > '9' {
			return pathStep{}, ErrIndexOutOfRange
		}
	}
	n, err := strconv.ParseUint(inside, 10, 31)
	if err != nil {
		return pathStep{}, ErrIndexOutOfRange
	}
	return pathStep{name: name, index: int(n), hasIndex: true}, nil
}

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

// getFieldValue returns the runtime value of field fi from msg.
// If msg is nil, the field is treated as unset.
func getFieldValue(msg *Message, fi int) fieldValue {
	if msg == nil {
		return fieldValue{}
	}
	return msg.fields[fi]
}

func (m *Message) clearAll() {
	for i := range m.fields {
		m.fields[i].set = false
		m.fields[i].value = nil
	}
}

// deepCopyMessage returns a deep copy of src. The returned message shares the
// schema with src but owns all of its field data.
func deepCopyMessage(src *Message) *Message {
	if src == nil {
		return nil
	}
	dst := &Message{
		schema: src.schema,
		fields: make([]fieldValue, len(src.fields)),
	}
	for i, fv := range src.fields {
		if !fv.set {
			continue
		}
		dst.fields[i].set = true
		dst.fields[i].value = deepCopyValue(fv.value)
	}
	return dst
}

func deepCopyValue(v any) any {
	switch val := v.(type) {
	case *Message:
		return deepCopyMessage(val)
	case []*Message:
		res := make([]*Message, len(val))
		for i, m := range val {
			res[i] = deepCopyMessage(m)
		}
		return res
	case []byte:
		return append([]byte(nil), val...)
	case [][]byte:
		res := make([][]byte, len(val))
		for i, b := range val {
			res[i] = append([]byte(nil), b...)
		}
		return res
	case []int32:
		return append([]int32(nil), val...)
	case []int64:
		return append([]int64(nil), val...)
	case []uint32:
		return append([]uint32(nil), val...)
	case []uint64:
		return append([]uint64(nil), val...)
	case []float32:
		return append([]float32(nil), val...)
	case []float64:
		return append([]float64(nil), val...)
	case []bool:
		return append([]bool(nil), val...)
	case []string:
		return append([]string(nil), val...)
	default:
		return val
	}
}

// copyMessageInto copies all set field values from src into dst by field name.
// The schemas of dst and src must be isomorphic.
func copyMessageInto(dst, src *Message) {
	for i := range dst.fields {
		dst.fields[i].set = false
		dst.fields[i].value = nil
	}
	for i, fs := range dst.schema.fields {
		fi, ok := src.schema.byName[fs.Name]
		if !ok || !src.fields[fi].set {
			continue
		}
		dst.fields[i].set = true
		dst.fields[i].value = deepCopyValue(src.fields[fi].value)
	}
}

func sliceLen(v any) int {
	switch s := v.(type) {
	case []int32:
		return len(s)
	case []int64:
		return len(s)
	case []uint32:
		return len(s)
	case []uint64:
		return len(s)
	case []float32:
		return len(s)
	case []float64:
		return len(s)
	case []bool:
		return len(s)
	case []string:
		return len(s)
	case [][]byte:
		return len(s)
	case []*Message:
		return len(s)
	}
	return 0
}

func sliceIndex(v any, i int) any {
	switch s := v.(type) {
	case []int32:
		return s[i]
	case []int64:
		return s[i]
	case []uint32:
		return s[i]
	case []uint64:
		return s[i]
	case []float32:
		return s[i]
	case []float64:
		return s[i]
	case []bool:
		return s[i]
	case []string:
		return s[i]
	case [][]byte:
		return s[i]
	case []*Message:
		return s[i]
	}
	return nil
}

func setSliceIndex(fv *fieldValue, i int, elem any) {
	switch s := fv.value.(type) {
	case []int32:
		s[i] = elem.(int32)
	case []int64:
		s[i] = elem.(int64)
	case []uint32:
		s[i] = elem.(uint32)
	case []uint64:
		s[i] = elem.(uint64)
	case []float32:
		s[i] = elem.(float32)
	case []float64:
		s[i] = elem.(float64)
	case []bool:
		s[i] = elem.(bool)
	case []string:
		s[i] = elem.(string)
	case [][]byte:
		s[i] = elem.([]byte)
	case []*Message:
		s[i] = elem.(*Message)
	}
}

func appendSlice(fv *fieldValue, elem any) {
	switch s := fv.value.(type) {
	case []int32:
		fv.value = append(s, elem.(int32))
	case []int64:
		fv.value = append(s, elem.(int64))
	case []uint32:
		fv.value = append(s, elem.(uint32))
	case []uint64:
		fv.value = append(s, elem.(uint64))
	case []float32:
		fv.value = append(s, elem.(float32))
	case []float64:
		fv.value = append(s, elem.(float64))
	case []bool:
		fv.value = append(s, elem.(bool))
	case []string:
		fv.value = append(s, elem.(string))
	case [][]byte:
		fv.value = append(s, elem.([]byte))
	case []*Message:
		fv.value = append(s, elem.(*Message))
	case nil:
		switch e := elem.(type) {
		case int32:
			fv.value = []int32{e}
		case int64:
			fv.value = []int64{e}
		case uint32:
			fv.value = []uint32{e}
		case uint64:
			fv.value = []uint64{e}
		case float32:
			fv.value = []float32{e}
		case float64:
			fv.value = []float64{e}
		case bool:
			fv.value = []bool{e}
		case string:
			fv.value = []string{e}
		case []byte:
			fv.value = [][]byte{e}
		case *Message:
			fv.value = []*Message{e}
		}
	}
	fv.set = true
}

// makeEmptySlice returns a non-nil empty slice for the given field type.
func makeEmptySlice(ft FieldType) any {
	switch ft {
	case FieldInt32:
		return []int32{}
	case FieldInt64:
		return []int64{}
	case FieldUint32:
		return []uint32{}
	case FieldUint64:
		return []uint64{}
	case FieldFloat:
		return []float32{}
	case FieldDouble:
		return []float64{}
	case FieldBool:
		return []bool{}
	case FieldString:
		return []string{}
	case FieldBytes:
		return [][]byte{}
	case FieldMessage:
		return []*Message{}
	}
	return nil
}

// zeroElement returns the zero value for a single element of the given field
// type. For messages it returns a typed nil *Message.
func zeroElement(ft FieldType) any {
	switch ft {
	case FieldInt32:
		return int32(0)
	case FieldInt64:
		return int64(0)
	case FieldUint32:
		return uint32(0)
	case FieldUint64:
		return uint64(0)
	case FieldFloat:
		return float32(0)
	case FieldDouble:
		return float64(0)
	case FieldBool:
		return false
	case FieldString:
		return ""
	case FieldBytes:
		return []byte(nil)
	case FieldMessage:
		return (*Message)(nil)
	}
	return nil
}

// ---------------------------------------------------------------------------
// Scalar conversion (Set / Append)
// ---------------------------------------------------------------------------

func toInt32(v any) (int32, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		n := rv.Int()
		if n < mathMinInt32 || n > mathMaxInt32 {
			return 0, ErrTypeMismatch
		}
		return int32(n), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		u := rv.Uint()
		if u > uint64(mathMaxInt32) {
			return 0, ErrTypeMismatch
		}
		return int32(u), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		t := math.Trunc(f)
		if math.IsNaN(f) || math.IsInf(f, 0) || t >= 2147483648.0 || t <= -2147483649.0 {
			return 0, ErrTypeMismatch
		}
		return int32(t), nil
	case reflect.String:
		n, err := strconv.ParseInt(rv.String(), 10, 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return int32(n), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			n, err := strconv.ParseInt(string(rv.Bytes()), 10, 32)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return int32(n), nil
		}
	}
	return 0, ErrTypeMismatch
}

func toInt64(v any) (int64, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return rv.Int(), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		u := rv.Uint()
		if u > uint64(mathMaxInt64) {
			return 0, ErrTypeMismatch
		}
		return int64(u), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		t := math.Trunc(f)
		if math.IsNaN(f) || math.IsInf(f, 0) || t >= 9223372036854775808.0 || t < -9223372036854775808.0 {
			return 0, ErrTypeMismatch
		}
		return int64(t), nil
	case reflect.String:
		n, err := strconv.ParseInt(rv.String(), 10, 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return n, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			n, err := strconv.ParseInt(string(rv.Bytes()), 10, 64)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return n, nil
		}
	}
	return 0, ErrTypeMismatch
}

func toUint32(v any) (uint32, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		n := rv.Int()
		if n < 0 || uint64(n) > mathMaxUint32 {
			return 0, ErrTypeMismatch
		}
		return uint32(n), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		u := rv.Uint()
		if u > mathMaxUint32 {
			return 0, ErrTypeMismatch
		}
		return uint32(u), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		t := math.Trunc(f)
		if math.IsNaN(f) || math.IsInf(f, 0) || t < 0 || t >= 4294967296.0 {
			return 0, ErrTypeMismatch
		}
		return uint32(t), nil
	case reflect.String:
		n, err := strconv.ParseUint(rv.String(), 10, 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return uint32(n), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			n, err := strconv.ParseUint(string(rv.Bytes()), 10, 32)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return uint32(n), nil
		}
	}
	return 0, ErrTypeMismatch
}

func toUint64(v any) (uint64, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		n := rv.Int()
		if n < 0 {
			return 0, ErrTypeMismatch
		}
		return uint64(n), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return rv.Uint(), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		t := math.Trunc(f)
		if math.IsNaN(f) || math.IsInf(f, 0) || t < 0 || t >= 18446744073709551616.0 {
			return 0, ErrTypeMismatch
		}
		return uint64(t), nil
	case reflect.String:
		n, err := strconv.ParseUint(rv.String(), 10, 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return n, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			n, err := strconv.ParseUint(string(rv.Bytes()), 10, 64)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return n, nil
		}
	}
	return 0, ErrTypeMismatch
}

func toFloat32(v any) (float32, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return float32(rv.Int()), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return float32(rv.Uint()), nil
	case reflect.Float32, reflect.Float64:
		f := rv.Float()
		f32 := float32(f)
		if math.IsInf(float64(f32), 0) && !math.IsInf(f, 0) {
			return 0, ErrTypeMismatch
		}
		return f32, nil
	case reflect.String:
		f, err := strconv.ParseFloat(rv.String(), 32)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return float32(f), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			f, err := strconv.ParseFloat(string(rv.Bytes()), 32)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return float32(f), nil
		}
	}
	return 0, ErrTypeMismatch
}

func toFloat64(v any) (float64, error) {
	if v == nil {
		return 0, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return float64(rv.Int()), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return float64(rv.Uint()), nil
	case reflect.Float32, reflect.Float64:
		return rv.Float(), nil
	case reflect.String:
		f, err := strconv.ParseFloat(rv.String(), 64)
		if err != nil {
			return 0, ErrTypeMismatch
		}
		return f, nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			f, err := strconv.ParseFloat(string(rv.Bytes()), 64)
			if err != nil {
				return 0, ErrTypeMismatch
			}
			return f, nil
		}
	}
	return 0, ErrTypeMismatch
}

func toBool(v any) (bool, error) {
	if v == nil {
		return false, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	if rv.Kind() == reflect.Bool {
		return rv.Bool(), nil
	}
	return false, ErrTypeMismatch
}

func toString(v any) (string, error) {
	if v == nil {
		return "", ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.String:
		return rv.String(), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			return string(rv.Bytes()), nil
		}
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(rv.Int(), 10), nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return strconv.FormatUint(rv.Uint(), 10), nil
	case reflect.Float32, reflect.Float64:
		return strconv.FormatFloat(rv.Float(), 'g', -1, rv.Type().Bits()), nil
	}
	return "", ErrTypeMismatch
}

func toBytes(v any) ([]byte, error) {
	if v == nil {
		return nil, ErrTypeMismatch
	}
	rv := reflect.ValueOf(v)
	switch rv.Kind() {
	case reflect.String:
		return []byte(rv.String()), nil
	case reflect.Slice:
		if rv.Type().Elem().Kind() == reflect.Uint8 {
			b := rv.Bytes()
			return append([]byte(nil), b...), nil
		}
	}
	return nil, ErrTypeMismatch
}

func convertScalarByType(ft FieldType, v any) (any, error) {
	switch ft {
	case FieldInt32:
		return toInt32(v)
	case FieldInt64:
		return toInt64(v)
	case FieldUint32:
		return toUint32(v)
	case FieldUint64:
		return toUint64(v)
	case FieldFloat:
		return toFloat32(v)
	case FieldDouble:
		return toFloat64(v)
	case FieldBool:
		return toBool(v)
	case FieldString:
		return toString(v)
	case FieldBytes:
		return toBytes(v)
	}
	return nil, ErrTypeMismatch
}

// convertElement converts a single element value for the field type. Message
// elements must be *Message values with an isomorphic schema and are deep
// copied.
func convertElement(fs *FieldSchema, v any) (any, error) {
	if fs.Type == FieldMessage {
		if v == nil {
			return (*Message)(nil), nil
		}
		msg, ok := v.(*Message)
		if !ok {
			return nil, ErrTypeMismatch
		}
		if msg == nil {
			return (*Message)(nil), nil
		}
		if !schemaIsomorphic(&fs.Schema, msg.schema) {
			return nil, ErrTypeMismatch
		}
		return deepCopyMessage(msg), nil
	}
	return convertScalarByType(fs.Type, v)
}

// convertScalarToField converts a value to the field's native type. For
// message fields it deep copies the message.
func convertScalarToField(fs *FieldSchema, v any) (any, error) {
	if fs.Type == FieldMessage {
		return convertElement(fs, v)
	}
	return convertScalarByType(fs.Type, v)
}

// convertRepeatedValue converts a slice value into the field's native slice
// type, converting and deep copying each element.
func convertRepeatedValue(fs *FieldSchema, v any) (any, error) {
	rv := reflect.ValueOf(v)
	if rv.Kind() != reflect.Slice && rv.Kind() != reflect.Array {
		return nil, ErrTypeMismatch
	}
	n := rv.Len()
	switch fs.Type {
	case FieldMessage:
		out := make([]*Message, n)
		for i := 0; i < n; i++ {
			iv := rv.Index(i).Interface()
			if iv == nil {
				out[i] = nil
				continue
			}
			msg, ok := iv.(*Message)
			if !ok {
				return nil, ErrTypeMismatch
			}
			if msg == nil {
				out[i] = nil
				continue
			}
			if !schemaIsomorphic(&fs.Schema, msg.schema) {
				return nil, ErrTypeMismatch
			}
			out[i] = deepCopyMessage(msg)
		}
		return out, nil
	case FieldInt32:
		out := make([]int32, n)
		for i := range out {
			v, err := toInt32(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldInt64:
		out := make([]int64, n)
		for i := range out {
			v, err := toInt64(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldUint32:
		out := make([]uint32, n)
		for i := range out {
			v, err := toUint32(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldUint64:
		out := make([]uint64, n)
		for i := range out {
			v, err := toUint64(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldFloat:
		out := make([]float32, n)
		for i := range out {
			v, err := toFloat32(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldDouble:
		out := make([]float64, n)
		for i := range out {
			v, err := toFloat64(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldBool:
		out := make([]bool, n)
		for i := range out {
			v, err := toBool(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldString:
		out := make([]string, n)
		for i := range out {
			v, err := toString(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	case FieldBytes:
		out := make([][]byte, n)
		for i := range out {
			v, err := toBytes(rv.Index(i).Interface())
			if err != nil {
				return nil, err
			}
			out[i] = v
		}
		return out, nil
	}
	return nil, ErrTypeMismatch
}

const (
	mathMinInt32  = int64(-1) << 31
	mathMaxInt32  = int64(1<<31 - 1)
	mathMaxUint32 = uint64(1<<32 - 1)
	mathMaxInt64  = int64(1<<63 - 1)
)
