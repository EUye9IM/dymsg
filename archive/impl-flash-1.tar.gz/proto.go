package dymsg

import (
	"bytes"
	"encoding/binary"
	"math"
)

// This file implements a self-contained subset of the Protobuf wire format.
// It does not depend on google.golang.org/protobuf.

// EncodeProto encodes the message to Protobuf wire format.
//
// Unset fields are omitted; set fields are encoded even when they hold zero
// values. Scalar repeated fields use packed encoding. Nil elements in a
// repeated message array are skipped.
func (m *Message) EncodeProto() ([]byte, error) {
	var buf bytes.Buffer
	for i, fs := range m.schema.fields {
		fv := m.fields[i]
		if !fv.set {
			continue
		}
		if err := encodeProtoField(&buf, fs, fv.value); err != nil {
			return nil, err
		}
	}
	return buf.Bytes(), nil
}

func encodeProtoField(buf *bytes.Buffer, fs *FieldSchema, val any) error {
	if fs.Repeated {
		return encodeProtoRepeated(buf, fs, val)
	}
	switch fs.Type {
	case FieldMessage:
		msg, _ := val.(*Message)
		if msg == nil {
			return nil
		}
		inner, err := msg.EncodeProto()
		if err != nil {
			return err
		}
		appendKey(buf, fs.Num, 2)
		appendVarint(buf, uint64(len(inner)))
		buf.Write(inner)
	case FieldString:
		s := val.(string)
		appendKey(buf, fs.Num, 2)
		appendVarint(buf, uint64(len(s)))
		buf.WriteString(s)
	case FieldBytes:
		b := val.([]byte)
		appendKey(buf, fs.Num, 2)
		appendVarint(buf, uint64(len(b)))
		buf.Write(b)
	case FieldInt32:
		appendKey(buf, fs.Num, 0)
		appendVarint(buf, uint64(int64(val.(int32))))
	case FieldInt64:
		appendKey(buf, fs.Num, 0)
		appendVarint(buf, uint64(val.(int64)))
	case FieldUint32:
		appendKey(buf, fs.Num, 0)
		appendVarint(buf, uint64(val.(uint32)))
	case FieldUint64:
		appendKey(buf, fs.Num, 0)
		appendVarint(buf, val.(uint64))
	case FieldBool:
		appendKey(buf, fs.Num, 0)
		if val.(bool) {
			appendVarint(buf, 1)
		} else {
			appendVarint(buf, 0)
		}
	case FieldFloat:
		appendKey(buf, fs.Num, 5)
		bits := math.Float32bits(val.(float32))
		var tmp [4]byte
		binary.LittleEndian.PutUint32(tmp[:], bits)
		buf.Write(tmp[:])
	case FieldDouble:
		appendKey(buf, fs.Num, 1)
		bits := math.Float64bits(val.(float64))
		var tmp [8]byte
		binary.LittleEndian.PutUint64(tmp[:], bits)
		buf.Write(tmp[:])
	}
	return nil
}

func encodeProtoRepeated(buf *bytes.Buffer, fs *FieldSchema, val any) error {
	n := sliceLen(val)
	if n == 0 {
		return nil
	}
	switch fs.Type {
	case FieldString, FieldBytes, FieldMessage:
		for i := 0; i < n; i++ {
			elem := sliceIndex(val, i)
			switch fs.Type {
			case FieldMessage:
				msg, _ := elem.(*Message)
				if msg == nil {
					continue
				}
				inner, err := msg.EncodeProto()
				if err != nil {
					return err
				}
				appendKey(buf, fs.Num, 2)
				appendVarint(buf, uint64(len(inner)))
				buf.Write(inner)
			case FieldString:
				s := elem.(string)
				appendKey(buf, fs.Num, 2)
				appendVarint(buf, uint64(len(s)))
				buf.WriteString(s)
			case FieldBytes:
				b := elem.([]byte)
				appendKey(buf, fs.Num, 2)
				appendVarint(buf, uint64(len(b)))
				buf.Write(b)
			}
		}
		return nil
	default:
		var sub bytes.Buffer
		for i := 0; i < n; i++ {
			elem := sliceIndex(val, i)
			if err := appendPackedElement(&sub, fs.Type, elem); err != nil {
				return err
			}
		}
		appendKey(buf, fs.Num, 2)
		appendVarint(buf, uint64(sub.Len()))
		buf.Write(sub.Bytes())
		return nil
	}
}

func appendPackedElement(buf *bytes.Buffer, ft FieldType, elem any) error {
	switch ft {
	case FieldInt32:
		appendVarint(buf, uint64(int64(elem.(int32))))
	case FieldInt64:
		appendVarint(buf, uint64(elem.(int64)))
	case FieldUint32:
		appendVarint(buf, uint64(elem.(uint32)))
	case FieldUint64:
		appendVarint(buf, elem.(uint64))
	case FieldBool:
		if elem.(bool) {
			appendVarint(buf, 1)
		} else {
			appendVarint(buf, 0)
		}
	case FieldFloat:
		bits := math.Float32bits(elem.(float32))
		var tmp [4]byte
		binary.LittleEndian.PutUint32(tmp[:], bits)
		buf.Write(tmp[:])
	case FieldDouble:
		bits := math.Float64bits(elem.(float64))
		var tmp [8]byte
		binary.LittleEndian.PutUint64(tmp[:], bits)
		buf.Write(tmp[:])
	}
	return nil
}

func appendKey(buf *bytes.Buffer, num int, wire int) {
	appendVarint(buf, uint64(num)<<3|uint64(wire))
}

func appendVarint(buf *bytes.Buffer, v uint64) {
	for v >= 0x80 {
		buf.WriteByte(byte(v) | 0x80)
		v >>= 7
	}
	buf.WriteByte(byte(v))
}

// ---------------------------------------------------------------------------
// Proto decoding
// ---------------------------------------------------------------------------

type protoReader struct {
	data []byte
	pos  int
}

func (r *protoReader) remaining() int {
	return len(r.data) - r.pos
}

func (r *protoReader) readVarint() (uint64, error) {
	var v uint64
	for i := 0; i < 10; i++ {
		if r.pos >= len(r.data) {
			return 0, ErrTruncated
		}
		b := r.data[r.pos]
		r.pos++
		if i == 9 && b > 1 {
			return 0, ErrMalformedData
		}
		v |= uint64(b&0x7f) << (7 * i)
		if b&0x80 == 0 {
			return v, nil
		}
	}
	return 0, ErrMalformedData
}

func (r *protoReader) readBytes(n int) ([]byte, error) {
	if n < 0 || n > r.remaining() {
		return nil, ErrTruncated
	}
	b := r.data[r.pos : r.pos+n]
	r.pos += n
	return b, nil
}

// DecodeProto decodes Protobuf wire-format data into the message, replacing
// all current fields. A zero-length input is a valid empty message.
func (m *Message) DecodeProto(data []byte) error {
	m.clearAll()
	r := &protoReader{data: data}
	for r.pos < len(r.data) {
		key, err := r.readVarint()
		if err != nil {
			return err
		}
		fieldNum := int(key >> 3)
		wireType := int(key & 7)
		if fieldNum == 0 {
			return ErrMalformedData
		}
		if wireType == 6 || wireType == 7 {
			return ErrMalformedData
		}
		fi, ok := m.schema.byNum[fieldNum]
		if !ok {
			if err := skipField(r, wireType); err != nil {
				return err
			}
			continue
		}
		fs := m.schema.fields[fi]
		if err := m.decodeProtoField(fi, fs, r, wireType); err != nil {
			return err
		}
	}
	return nil
}

func skipField(r *protoReader, wireType int) error {
	switch wireType {
	case 0:
		_, err := r.readVarint()
		return err
	case 1:
		_, err := r.readBytes(8)
		return err
	case 2:
		l, err := r.readVarint()
		if err != nil {
			return err
		}
		_, err = r.readBytes(int(l))
		return err
	case 5:
		_, err := r.readBytes(4)
		return err
	}
	return ErrMalformedData
}

func (m *Message) decodeProtoField(fi int, fs *FieldSchema, r *protoReader, wireType int) error {
	if fs.Repeated {
		return m.decodeProtoRepeated(fi, fs, r, wireType)
	}
	switch fs.Type {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		if wireType != 0 {
			return ErrMalformedData
		}
		v, err := r.readVarint()
		if err != nil {
			return err
		}
		m.fields[fi].set = true
		m.fields[fi].value = convertVarintToField(fs.Type, v)
	case FieldFloat:
		if wireType != 5 {
			return ErrMalformedData
		}
		b, err := r.readBytes(4)
		if err != nil {
			return err
		}
		bits := binary.LittleEndian.Uint32(b)
		m.fields[fi].set = true
		m.fields[fi].value = math.Float32frombits(bits)
	case FieldDouble:
		if wireType != 1 {
			return ErrMalformedData
		}
		b, err := r.readBytes(8)
		if err != nil {
			return err
		}
		bits := binary.LittleEndian.Uint64(b)
		m.fields[fi].set = true
		m.fields[fi].value = math.Float64frombits(bits)
	case FieldString:
		if wireType != 2 {
			return ErrMalformedData
		}
		l, err := r.readVarint()
		if err != nil {
			return err
		}
		b, err := r.readBytes(int(l))
		if err != nil {
			return err
		}
		m.fields[fi].set = true
		m.fields[fi].value = string(b)
	case FieldBytes:
		if wireType != 2 {
			return ErrMalformedData
		}
		l, err := r.readVarint()
		if err != nil {
			return err
		}
		b, err := r.readBytes(int(l))
		if err != nil {
			return err
		}
		cp := append([]byte(nil), b...)
		m.fields[fi].set = true
		m.fields[fi].value = cp
	case FieldMessage:
		if wireType != 2 {
			return ErrMalformedData
		}
		l, err := r.readVarint()
		if err != nil {
			return err
		}
		b, err := r.readBytes(int(l))
		if err != nil {
			return err
		}
		sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
		if err := sub.DecodeProto(b); err != nil {
			return err
		}
		m.fields[fi].set = true
		m.fields[fi].value = sub
	}
	return nil
}

func (m *Message) decodeProtoRepeated(fi int, fs *FieldSchema, r *protoReader, wireType int) error {
	switch fs.Type {
	case FieldString, FieldBytes, FieldMessage:
		if wireType != 2 {
			return ErrMalformedData
		}
		l, err := r.readVarint()
		if err != nil {
			return err
		}
		b, err := r.readBytes(int(l))
		if err != nil {
			return err
		}
		switch fs.Type {
		case FieldString:
			appendSlice(&m.fields[fi], string(b))
		case FieldBytes:
			cp := append([]byte(nil), b...)
			appendSlice(&m.fields[fi], cp)
		case FieldMessage:
			sub := &Message{schema: &fs.Schema, fields: make([]fieldValue, len(fs.Schema.fields))}
			if err := sub.DecodeProto(b); err != nil {
				return err
			}
			appendSlice(&m.fields[fi], sub)
		}
		return nil
	default:
		// Scalar repeated: accept packed (wire type 2) and unpacked forms.
		if wireType == 2 {
			l, err := r.readVarint()
			if err != nil {
				return err
			}
			if int(l) > r.remaining() {
				return ErrTruncated
			}
			end := r.pos + int(l)
			subR := &protoReader{data: r.data[r.pos:end]}
			for subR.pos < len(subR.data) {
				elem, err := readPackedElement(subR, fs.Type)
				if err != nil {
					return err
				}
				appendSlice(&m.fields[fi], elem)
			}
			r.pos = end
			if !m.fields[fi].set {
				m.fields[fi].set = true
				m.fields[fi].value = makeEmptySlice(fs.Type)
			}
			return nil
		}
		if !isNativeWireType(fs.Type, wireType) {
			return ErrMalformedData
		}
		elem, err := readUnpackedScalar(r, fs.Type)
		if err != nil {
			return err
		}
		appendSlice(&m.fields[fi], elem)
		return nil
	}
}

func readPackedElement(r *protoReader, ft FieldType) (any, error) {
	switch ft {
	case FieldInt32:
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		return int32(int64(v)), nil
	case FieldInt64:
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		return int64(v), nil
	case FieldUint32:
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		return uint32(v), nil
	case FieldUint64:
		return r.readVarint()
	case FieldBool:
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		return v != 0, nil
	case FieldFloat:
		b, err := r.readBytes(4)
		if err != nil {
			return nil, err
		}
		return math.Float32frombits(binary.LittleEndian.Uint32(b)), nil
	case FieldDouble:
		b, err := r.readBytes(8)
		if err != nil {
			return nil, err
		}
		return math.Float64frombits(binary.LittleEndian.Uint64(b)), nil
	}
	return nil, ErrMalformedData
}

func readUnpackedScalar(r *protoReader, ft FieldType) (any, error) {
	switch ft {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		v, err := r.readVarint()
		if err != nil {
			return nil, err
		}
		return convertVarintToField(ft, v), nil
	case FieldFloat:
		b, err := r.readBytes(4)
		if err != nil {
			return nil, err
		}
		return math.Float32frombits(binary.LittleEndian.Uint32(b)), nil
	case FieldDouble:
		b, err := r.readBytes(8)
		if err != nil {
			return nil, err
		}
		return math.Float64frombits(binary.LittleEndian.Uint64(b)), nil
	}
	return nil, ErrMalformedData
}

func isNativeWireType(ft FieldType, wireType int) bool {
	switch ft {
	case FieldInt32, FieldInt64, FieldUint32, FieldUint64, FieldBool:
		return wireType == 0
	case FieldFloat:
		return wireType == 5
	case FieldDouble:
		return wireType == 1
	}
	return false
}

func convertVarintToField(ft FieldType, v uint64) any {
	switch ft {
	case FieldInt32:
		return int32(int64(v))
	case FieldInt64:
		return int64(v)
	case FieldUint32:
		return uint32(v)
	case FieldUint64:
		return v
	case FieldBool:
		return v != 0
	}
	return nil
}
